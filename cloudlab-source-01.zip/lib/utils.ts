import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
export const cn = (...inputs: ClassValue[]) => twMerge(clsx(inputs));
export function shuffle<T>(items: T[]): T[] {
  const a = [...items];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
export function localDay(d = new Date()) {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Bahrain",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(d);
}
export function studyStreak(days: string[], now = new Date()) {
  let n = 0;
  const day = new Date(localDay(now) + "T12:00:00Z");
  if (!days.includes(localDay(day))) day.setUTCDate(day.getUTCDate() - 1);
  while (days.includes(localDay(day))) {
    n++;
    day.setUTCDate(day.getUTCDate() - 1);
  }
  return n;
}
