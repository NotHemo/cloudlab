import JSON5 from "json5";
type Doc = Record<string, any>;
export type MongoState = {
  collections: Record<string, Doc[]>;
  indexes: Record<string, Doc[]>;
  nextId: number;
};
export function mongoSeed(): MongoState {
  return {
    nextId: 20,
    indexes: {},
    collections: {
      customers: [
        {
          _id: 1,
          first_name: "Ahmed",
          age: 30,
          address: { city: "Manama" },
          account: [
            { currency: "USD", balance: 50 },
            { currency: "GEL", balance: 200 },
          ],
        },
        {
          _id: 2,
          first_name: "Hassan",
          last_name: "Abdullah",
          age: 45,
          address: { city: "Manama" },
          account: [
            { currency: "USD", balance: 123.45 },
            { currency: "GEL", balance: 1000 },
          ],
        },
        {
          _id: 3,
          first_name: "Mariam",
          age: 28,
          address: { city: "Riffa" },
          account: [{ currency: "USD", balance: 300 }],
        },
      ],
      articles: [
        { _id: 1, subject: "coffee and databases", author: "Mariam" },
        { _id: 2, subject: "tea in Manama", author: "Ahmed" },
      ],
      purchase_orders: [
        { _id: 1, product: "Book", total: 12 },
        { _id: 2, product: "Book", total: 8 },
        { _id: 3, product: "Pen", total: 3 },
      ],
      clients: [
        { _id: 1, name: "Ahmed" },
        { _id: 2, name: "Mariam" },
      ],
      orders: [
        { _id: 1, user_id: 1, total: 12 },
        { _id: 2, user_id: 1, total: 8 },
        { _id: 3, user_id: 99, total: 5 },
      ],
      salaries: [
        { _id: 1, fiscal_year: 2026, dept: "IT", salary: 100 },
        { _id: 2, fiscal_year: 2026, dept: "IT", salary: 200 },
      ],
    },
  };
}
const clone = <T>(v: T): T => structuredClone(v);
function safeKey(k: string) {
  if (
    k
      .split(".")
      .some((p) => ["__proto__", "prototype", "constructor"].includes(p))
  )
    throw new Error("Unsafe field path.");
}
export function getPath(obj: any, path: string): any {
  safeKey(path);
  if (!path) return obj;
  const [head, ...tail] = path.split(".");
  if (Array.isArray(obj) && !/^\d+$/.test(head))
    return obj.flatMap((v) => {
      const x = getPath(v, path);
      return Array.isArray(x) ? x : [x];
    });
  return tail.length ? getPath(obj?.[head], tail.join(".")) : obj?.[head];
}
function setPath(obj: Doc, path: string, value: any) {
  safeKey(path);
  const bits = path.split(".");
  let o = obj;
  bits.slice(0, -1).forEach((k) => {
    if (!o[k] || typeof o[k] !== "object") o[k] = {};
    o = o[k];
  });
  o[bits.at(-1)!] = clone(value);
}
function unsetPath(obj: Doc, path: string) {
  safeKey(path);
  const a = path.split(".");
  const p = a.slice(0, -1).reduce((o, k) => o?.[k], obj);
  if (p) delete p[a.at(-1)!];
}
const eq = (a: any, b: any) => JSON.stringify(a) === JSON.stringify(b);
function expr(d: Doc, x: any): any {
  if (typeof x === "string" && x.startsWith("$")) return getPath(d, x.slice(1));
  if (x && typeof x === "object" && !Array.isArray(x)) {
    const keys = Object.keys(x);
    if (keys[0]?.startsWith("$")) {
      const [op, args] = Object.entries(x)[0] as [string, any];
      const [a, b] = Array.isArray(args)
        ? args.map((v) => expr(d, v))
        : [expr(d, args), null];
      if (op === "$gt") return a > b;
      if (op === "$gte") return a >= b;
      if (op === "$lt") return a < b;
      if (op === "$eq") return eq(a, b);
      throw new Error(
        `Expression ${op} is outside this simulator’s supported subset.`,
      );
    }
    return Object.fromEntries(
      Object.entries(x).map(([k, v]) => [k, expr(d, v)]),
    );
  }
  return x;
}
function testValue(actual: any, expected: any): boolean {
  if (
    expected &&
    typeof expected === "object" &&
    !Array.isArray(expected) &&
    Object.keys(expected).some((k) => k.startsWith("$"))
  ) {
    return Object.entries(expected).every(([op, b]: [string, any]) => {
      const values = Array.isArray(actual) ? actual : [actual];
      switch (op) {
        case "$eq":
          return eq(actual, b) || values.some((v) => eq(v, b));
        case "$ne":
          return !testValue(actual, { $eq: b });
        case "$gt":
          return values.some((v) => v > b);
        case "$gte":
          return values.some((v) => v >= b);
        case "$lt":
          return values.some((v) => v < b);
        case "$lte":
          return values.some((v) => v <= b);
        case "$in":
          return values.some((v) => b.some((x: any) => eq(v, x)));
        case "$nin":
          return !testValue(actual, { $in: b });
        case "$exists":
          return b ? actual !== undefined : actual === undefined;
        case "$size":
          return Array.isArray(actual) && actual.length === b;
        case "$all":
          return (
            Array.isArray(actual) &&
            b.every((v: any) => actual.some((x) => eq(x, v)))
          );
        case "$elemMatch":
          return Array.isArray(actual) && actual.some((v) => matches(v, b));
        case "$not":
          return !testValue(actual, b);
        case "$regex":
          if (typeof b !== "string" || b.length > 200)
            throw new Error("Use a short string regex pattern.");
          return values.some((v) =>
            new RegExp(b, String(expected.$options || "")).test(String(v)),
          );
        case "$options":
          return true;
        default:
          throw new Error(`Unsupported filter operator ${op}.`);
      }
    });
  }
  return (
    eq(actual, expected) ||
    (expected === null && actual === undefined) ||
    (Array.isArray(actual) && actual.some((v) => eq(v, expected)))
  );
}
export function matches(d: Doc, f: Doc = {}): boolean {
  return Object.entries(f).every(([k, v]) => {
    if (k === "$and") return (v as Doc[]).every((x) => matches(d, x));
    if (k === "$or") return (v as Doc[]).some((x) => matches(d, x));
    if (k === "$nor") return !(v as Doc[]).some((x) => matches(d, x));
    if (k === "$expr") return !!expr(d, v);
    if (k === "$text")
      return JSON.stringify(d)
        .toLowerCase()
        .includes(String((v as Doc).$search).toLowerCase());
    if (k.startsWith("$")) throw new Error(`Unsupported filter operator ${k}.`);
    return testValue(getPath(d, k), v);
  });
}
function projection(d: Doc, p?: Doc) {
  if (!p || !Object.keys(p).length) return clone(d);
  const include = Object.entries(p).some(([k, v]) => k !== "_id" && !!v);
  let out: Doc = include ? {} : clone(d);
  if (include && p._id !== 0 && d._id !== undefined) out._id = d._id;
  for (const [k, v] of Object.entries(p)) {
    if (v) {
      if (v?.$meta) {
        out[k] = 1;
        continue;
      }
      const val = getPath(d, k);
      if (val !== undefined) setPath(out, k, val);
    } else unsetPath(out, k);
  }
  return out;
}
function sortDocs(docs: Doc[], spec: Doc) {
  return docs.sort((a, b) => {
    for (const [k, direction] of Object.entries(spec)) {
      const x = getPath(a, k),
        y = getPath(b, k);
      const dir = typeof direction === "number" ? direction : -1;
      if (x < y) return -dir;
      if (x > y) return dir;
    }
    return 0;
  });
}
function updateDoc(d: Doc, u: Doc) {
  if (!Object.keys(u).every((k) => k.startsWith("$")))
    throw new Error(
      "Use update operators ($set, $inc…), or replaceOne for replacement.",
    );
  for (const [op, fields] of Object.entries(u)) {
    for (const [k, v] of Object.entries(fields as Doc)) {
      if (k === "_id") throw new Error("_id is immutable.");
      const old = getPath(d, k);
      switch (op) {
        case "$set":
          setPath(d, k, v);
          break;
        case "$unset":
          unsetPath(d, k);
          break;
        case "$inc":
          if (old !== undefined && typeof old !== "number")
            throw new Error("$inc requires a number.");
          setPath(d, k, (old ?? 0) + Number(v));
          break;
        case "$mul":
          setPath(d, k, (old ?? 0) * Number(v));
          break;
        case "$rename":
          if (old !== undefined) {
            setPath(d, String(v), old);
            unsetPath(d, k);
          }
          break;
        case "$push":
          setPath(d, k, [...(old || []), v]);
          break;
        case "$addToSet":
          setPath(
            d,
            k,
            (old || []).some((a: any) => eq(a, v)) ? old : [...(old || []), v],
          );
          break;
        default:
          throw new Error(`Unsupported update operator ${op}.`);
      }
    }
  }
}
function readCall(source: string): { name: string; args: any[]; rest: string } {
  const m = source.match(/^([\w$]+)\s*\(/);
  if (!m) throw new Error("Expected method(arguments).");
  let depth = 1,
    quote = "",
    escaped = false,
    i = m[0].length;
  const start = i;
  for (; i < source.length; i++) {
    const ch = source[i];
    if (quote) {
      if (escaped) escaped = false;
      else if (ch === "\\") escaped = true;
      else if (ch === quote) quote = "";
    } else if (ch === '"' || ch === "'") quote = ch;
    else if (ch === "(") depth++;
    else if (ch === ")" && !--depth) break;
  }
  if (depth) throw new Error("Missing closing parenthesis.");
  let args;
  try {
    args = JSON5.parse(`[${source.slice(start, i)}]`);
  } catch {
    throw new Error(
      "Arguments must be JSON/JSON5 data. No JavaScript is evaluated. Use quoted strings and balanced brackets.",
    );
  }
  return {
    name: m[1],
    args,
    rest: source
      .slice(i + 1)
      .trim()
      .replace(/;$/, ""),
  };
}
function aggregate(state: MongoState, docs: Doc[], pipeline: Doc[]): Doc[] {
  let out = clone(docs);
  for (let n = 0; n < pipeline.length; n++) {
    const stage = pipeline[n];
    if (Object.keys(stage).length !== 1)
      throw new Error("Each pipeline stage needs exactly one operator.");
    const [op, spec] = Object.entries(stage)[0];
    switch (op) {
      case "$match":
        out = out.filter((d) => matches(d, spec));
        break;
      case "$sort":
        out = sortDocs(out, spec);
        break;
      case "$limit":
        out = out.slice(0, spec);
        break;
      case "$skip":
        out = out.slice(spec);
        break;
      case "$project":
        out = out.map((d) => projection(d, spec));
        break;
      case "$unwind": {
        const path = (typeof spec === "string" ? spec : spec.path).replace(
          /^\$/,
          "",
        );
        const preserve =
          typeof spec === "object" && spec.preserveNullAndEmptyArrays;
        out = out.flatMap((d) => {
          const arr = getPath(d, path);
          if (!Array.isArray(arr))
            return arr !== undefined && arr !== null
              ? [d]
              : preserve
                ? [d]
                : [];
          return arr.length
            ? arr.map((v) => {
                const row = clone(d);
                setPath(row, path, v);
                return row;
              })
            : preserve
              ? [d]
              : [];
        });
        break;
      }
      case "$group": {
        const groups = new Map<string, { key: any; rows: Doc[] }>();
        for (const d of out) {
          const key = expr(d, spec._id);
          const str = JSON.stringify(key);
          if (!groups.has(str)) groups.set(str, { key, rows: [] });
          groups.get(str)!.rows.push(d);
        }
        out = [...groups.values()].map(({ key, rows }) => {
          const d: Doc = { _id: key };
          for (const [field, acc] of Object.entries(spec)) {
            if (field === "_id") continue;
            const [kind, value] = Object.entries(acc as Doc)[0];
            if (kind === "$sum")
              d[field] = rows.reduce((sum, r) => {
                const v = expr(r, value);
                return sum + (typeof v === "number" ? v : 0);
              }, 0);
            else if (kind === "$push")
              d[field] = rows.map((r) => expr(r, value));
            else if (kind === "$avg") {
              const vals = rows
                .map((r) => expr(r, value))
                .filter((v) => typeof v === "number");
              d[field] = vals.reduce((a, b) => a + b, 0) / vals.length;
            } else throw new Error(`Unsupported accumulator ${kind}.`);
          }
          return d;
        });
        break;
      }
      case "$lookup": {
        if (spec.pipeline)
          throw new Error(
            "This simulator supports the localField/foreignField lookup form.",
          );
        const foreign = state.collections[spec.from] || [];
        out = out.map((d) => ({
          ...d,
          [spec.as]: foreign
            .filter((f) =>
              eq(getPath(d, spec.localField), getPath(f, spec.foreignField)),
            )
            .map(clone),
        }));
        break;
      }
      case "$out":
      case "$merge": {
        if (n !== pipeline.length - 1)
          throw new Error(`${op} must be the last stage.`);
        const name = typeof spec === "string" ? spec : spec.into;
        if (typeof name !== "string")
          throw new Error("Use a local collection name.");
        safeKey(name);
        if (op === "$out") state.collections[name] = clone(out);
        else {
          if (spec.whenMatched && spec.whenMatched !== "replace")
            throw new Error('This simulator supports whenMatched:"replace".');
          if (spec.whenNotMatched && spec.whenNotMatched !== "insert")
            throw new Error('This simulator supports whenNotMatched:"insert".');
          const target = state.collections[name] || [];
          const on = spec.on || "_id";
          for (const row of out) {
            const i = target.findIndex((d) =>
              eq(getPath(d, on), getPath(row, on)),
            );
            if (i < 0) target.push(clone(row));
            else target[i] = clone(row);
          }
          state.collections[name] = target;
        }
        out = [];
        break;
      }
      default:
        throw new Error(`Unsupported aggregation stage ${op}.`);
    }
  }
  return out;
}
export function runMongo(
  previous: MongoState,
  command: string,
): { state: MongoState; output: any } {
  const state = clone(previous);
  const cmd = command.trim().replace(/;$/, "");
  const match = cmd.match(/^db\.([a-zA-Z_]\w*)\.(.*)$/s);
  if (!match)
    throw new Error(
      "Use one db.collection.method(...) command. This is a local JSON/JSON5 simulator, not mongosh.",
    );
  const [, name, chain] = match;
  safeKey(name);
  const { name: method, args, rest } = readCall(chain);
  const docs = state.collections[name] || [];
  let output: any;
  const filter = args[0] || {};
  if (JSON.stringify(args).includes('"__proto__"'))
    throw new Error("Unsafe input.");
  switch (method) {
    case "find":
    case "findOne": {
      if (
        filter.$text &&
        !state.indexes[name]?.some((i) => Object.values(i).includes("text"))
      )
        throw new Error("text index required for $text query");
      output = docs
        .filter((d) => matches(d, filter))
        .map((d) => projection(d, args[1]));
      let tail = rest;
      while (tail) {
        if (!tail.startsWith("."))
          throw new Error("Unexpected text after command.");
        const next = readCall(tail.slice(1));
        if (next.name === "sort") output = sortDocs(output, next.args[0]);
        else if (next.name === "limit") output = output.slice(0, next.args[0]);
        else if (next.name === "skip") output = output.slice(next.args[0]);
        else throw new Error(`Unsupported cursor method ${next.name}.`);
        tail = next.rest;
      }
      if (method === "findOne") output = output[0] || null;
      break;
    }
    case "insertOne":
    case "insertMany": {
      const incoming = method === "insertOne" ? [args[0]] : args[0];
      if (
        !Array.isArray(incoming) ||
        incoming.some((d) => !d || Array.isArray(d) || typeof d !== "object")
      )
        throw new Error("Insert documents as objects.");
      const added = incoming.map((d) => ({
        ...d,
        _id: d._id ?? state.nextId++,
      }));
      const ids = [...docs, ...added].map((d) => JSON.stringify(d._id));
      if (new Set(ids).size !== ids.length)
        throw new Error("Duplicate _id rejected.");
      state.collections[name] = [...docs, ...added];
      output = {
        acknowledged: true,
        insertedCount: added.length,
        insertedIds: added.map((d) => d._id),
      };
      break;
    }
    case "updateOne":
    case "updateMany":
    case "replaceOne": {
      let count = 0,
        modified = 0;
      for (let i = 0; i < docs.length; i++) {
        if (!matches(docs[i], filter) || (count > 0 && method !== "updateMany"))
          continue;
        count++;
        const before = JSON.stringify(docs[i]);
        if (method === "replaceOne") {
          if (args[1]._id !== undefined && !eq(args[1]._id, docs[i]._id))
            throw new Error("_id is immutable.");
          docs[i] = { ...args[1], _id: docs[i]._id };
        } else updateDoc(docs[i], args[1]);
        if (JSON.stringify(docs[i]) !== before) modified++;
      }
      if (!count && args[2]?.upsert) {
        const row: Doc = {};
        for (const [k, v] of Object.entries(filter))
          if (!k.startsWith("$") && (v === null || typeof v !== "object"))
            setPath(row, k, v);
        if (method === "replaceOne") Object.assign(row, args[1]);
        else updateDoc(row, args[1]);
        row._id ??= state.nextId++;
        if (docs.some((d) => eq(d._id, row._id)))
          throw new Error("Duplicate _id rejected.");
        docs.push(row);
        output = { matchedCount: 0, modifiedCount: 0, upsertedId: row._id };
      } else output = { matchedCount: count, modifiedCount: modified };
      state.collections[name] = docs;
      break;
    }
    case "deleteOne":
    case "deleteMany": {
      let deleted = 0;
      state.collections[name] = docs.filter((d) => {
        if (matches(d, filter) && (method === "deleteMany" || !deleted)) {
          deleted++;
          return false;
        }
        return true;
      });
      output = { deletedCount: deleted };
      break;
    }
    case "countDocuments":
      output = docs.filter((d) => matches(d, filter)).length;
      break;
    case "distinct":
      output = [
        ...new Map(
          docs
            .filter((d) => matches(d, args[1] || {}))
            .flatMap((d) => {
              const v = getPath(d, args[0]);
              return Array.isArray(v) ? v : [v];
            })
            .filter((v) => v !== undefined)
            .map((v) => [JSON.stringify(v), v]),
        ).values(),
      ];
      break;
    case "createIndex":
      state.indexes[name] = [...(state.indexes[name] || []), args[0]];
      output = Object.keys(args[0]).join("_") + "_index";
      break;
    case "aggregate":
      output = aggregate(state, docs, args[0]);
      break;
    case "bulkWrite": {
      let working = state;
      const results = [];
      for (const op of args[0]) {
        const [kind, body] = Object.entries(op)[0] as [string, any];
        let a;
        if (kind === "insertOne") a = [body.document];
        else if (kind === "updateOne" || kind === "updateMany")
          a = [body.filter, body.update, { upsert: !!body.upsert }];
        else if (kind === "deleteOne" || kind === "deleteMany")
          a = [body.filter];
        else throw new Error(`Unsupported bulk operation ${kind}.`);
        const r = runMongo(
          working,
          `db.${name}.${kind}(${a.map((x) => JSON.stringify(x)).join(",")})`,
        );
        working = r.state;
        results.push(r.output);
      }
      return { state: working, output: results };
    }
    default:
      throw new Error(
        `Unsupported method ${method}. See the supported examples; no command is sent to Atlas.`,
      );
  }
  if (rest && !["find", "findOne"].includes(method))
    throw new Error("Unexpected trailing text. Run one command at a time.");
  return { state, output };
}
