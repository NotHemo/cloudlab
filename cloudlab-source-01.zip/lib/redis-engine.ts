export type RedisEntry = {
  type: "string" | "hash" | "list" | "set" | "zset" | "json";
  value: any;
  expiresAt?: number;
};
export type RedisState = {
  keys: Record<string, RedisEntry>;
  indexes: Record<string, { prefix: string; fields: Record<string, string> }>;
};
export const redisSeed = (): RedisState => ({
  keys: {
    course: { type: "string", value: "IT8417" },
    "customer:khalid": {
      type: "hash",
      value: { name: "Khalid Al-Amin", city: "Riffa" },
    },
    leaderboard: {
      type: "zset",
      value: { ahmed: 420, yousef: 500, omar: 275 },
    },
  },
  indexes: {},
});
export function liveRedis(s: RedisState, now = Date.now()): RedisState {
  return {
    ...s,
    keys: Object.fromEntries(
      Object.entries(s.keys).filter(
        ([, v]) => !v.expiresAt || v.expiresAt > now,
      ),
    ),
  };
}
function tokenize(command: string) {
  const matches = command.match(/'(?:[^'\\]|\\.)*'|"(?:[^"\\]|\\.)*"|\S+/g);
  if (!matches) return [];
  return matches.map((t) => {
    if (t.startsWith("'")) return t.slice(1, -1).replace(/\\'/g, "'");
    if (t.startsWith('"')) {
      try {
        return JSON.parse(t);
      } catch {
        throw new Error("Invalid quoted string.");
      }
    }
    return t;
  });
}
function glob(s: string, pattern: string) {
  const escaped = pattern
    .replace(/[.+?^${}()|[\]\\]/g, "\\$&")
    .replace(/\*/g, ".*");
  return new RegExp(`^${escaped}$`).test(s);
}
function jsonBits(path: string) {
  if (!/^\$(?:\.[a-zA-Z_]\w*|\[\d+\])*$/.test(path))
    throw new Error("Supported JSONPath: $, $.field and [numeric] indexes.");
  const bits = path.slice(1).match(/[a-zA-Z_]\w*|\d+/g) || [];
  if (bits.some((b) => ["__proto__", "constructor", "prototype"].includes(b)))
    throw new Error("Unsafe JSON path.");
  return bits;
}
function pathGet(obj: any, path: string) {
  return jsonBits(path).reduce((o, k) => o?.[k], obj);
}
export function runRedis(
  previous: RedisState,
  command: string,
  now = Date.now(),
): { state: RedisState; output: any } {
  const state = structuredClone(liveRedis(previous, now));
  const args = tokenize(command.trim());
  const cmd = (args.shift() || "").toUpperCase();
  const key = args[0];
  if (["__proto__", "constructor", "prototype"].includes(key))
    throw new Error("Reserved key in this teaching simulator.");
  const fixedArity: Record<string, number> = {
    GET: 1,
    GETDEL: 1,
    INCR: 1,
    DECR: 1,
    INCRBY: 2,
    TYPE: 1,
    DBSIZE: 0,
    TTL: 1,
    PTTL: 1,
    EXPIRE: 2,
    PEXPIRE: 2,
    PERSIST: 1,
    KEYS: 1,
    HGET: 2,
    HGETALL: 1,
    HINCRBY: 3,
    LPOP: 1,
    RPOP: 1,
    LLEN: 1,
    LRANGE: 3,
    LPOS: 2,
    SMEMBERS: 1,
    SCARD: 1,
    SISMEMBER: 2,
    ZINCRBY: 3,
    ZRANK: 2,
    ZREVRANK: 2,
    "JSON.SET": 3,
    "JSON.NUMINCRBY": 3,
    "FT.SEARCH": 2,
  };
  if (
    (cmd in fixedArity && args.length !== fixedArity[cmd]) ||
    (cmd === "PING" && args.length > 1) ||
    (cmd === "JSON.GET" && (args.length < 1 || args.length > 2))
  )
    throw new Error(`Wrong number of arguments for ${cmd}.`);
  const keys = state.keys;
  const entry = keys[key];
  let output: any;
  const need = (n: number) => {
    if (args.length < n)
      throw new Error(`Wrong number of arguments for ${cmd}.`);
  };
  const integer = (x: string) => {
    if (!/^-?\d+$/.test(x)) throw new Error("Expected an integer.");
    const n = Number(x);
    if (!Number.isSafeInteger(n))
      throw new Error("Integer outside this simulator’s safe numeric range.");
    return n;
  };
  const numeric = (x: string) => {
    const n = Number(x);
    if (!Number.isFinite(n)) throw new Error("Expected a finite number.");
    return n;
  };
  const typed = (type: RedisEntry["type"], create: any) => {
    if (entry && entry.type !== type)
      throw new Error(
        "WRONGTYPE Operation against a key holding the wrong kind of value",
      );
    if (!keys[key]) keys[key] = { type, value: structuredClone(create) };
    return keys[key];
  };
  const only = (...supported: string[]) => {
    if (args.slice(2).some((a) => !supported.includes(a.toUpperCase())))
      throw new Error(`Unsupported options for ${cmd}.`);
  };
  switch (cmd) {
    case "PING":
      output = args[0] ?? "PONG";
      break;
    case "SET": {
      need(2);
      let expiry: number | undefined,
        keep = false,
        nx = false,
        xx = false;
      for (let i = 2; i < args.length; i++) {
        const a = args[i].toUpperCase();
        if (a === "NX") nx = true;
        else if (a === "XX") xx = true;
        else if (a === "KEEPTTL") keep = true;
        else if (a === "EX" || a === "PX") {
          const v = integer(args[++i] || "");
          if (v <= 0) throw new Error("Invalid expire time.");
          expiry = now + v * (a === "EX" ? 1000 : 1);
        } else throw new Error(`Unsupported SET option ${a}.`);
      }
      if (nx && xx) throw new Error("NX and XX cannot be combined.");
      if (keep && expiry)
        throw new Error("KEEPTTL and a new expiry cannot be combined.");
      if ((nx && entry) || (xx && !entry)) output = null;
      else {
        keys[key] = {
          type: "string",
          value: args[1],
          expiresAt: expiry ?? (keep ? entry?.expiresAt : undefined),
        };
        output = "OK";
      }
      break;
    }
    case "GET":
    case "GETDEL":
      need(1);
      if (entry && entry.type !== "string") throw new Error("WRONGTYPE");
      output = entry?.value ?? null;
      if (cmd === "GETDEL") delete keys[key];
      break;
    case "INCR":
    case "DECR":
    case "INCRBY": {
      need(cmd === "INCRBY" ? 2 : 1);
      const e = typed("string", "0");
      const n =
        integer(String(e.value)) +
        (cmd === "INCRBY" ? integer(args[1]) : cmd === "DECR" ? -1 : 1);
      if (!Number.isSafeInteger(n))
        throw new Error("Result outside safe integer range.");
      e.value = String(n);
      output = n;
      break;
    }
    case "DEL":
      need(1);
      output = args.reduce((sum, k) => {
        if (keys[k]) {
          delete keys[k];
          return sum + 1;
        }
        return sum;
      }, 0);
      break;
    case "EXISTS":
      output = args.filter((k) => !!keys[k]).length;
      break;
    case "TYPE":
      need(1);
      output = entry?.type ?? "none";
      break;
    case "DBSIZE":
      output = Object.keys(keys).length;
      break;
    case "TTL":
    case "PTTL":
      need(1);
      output = !entry
        ? -2
        : !entry.expiresAt
          ? -1
          : cmd === "TTL"
            ? Math.ceil((entry.expiresAt - now) / 1000)
            : entry.expiresAt - now;
      break;
    case "EXPIRE":
    case "PEXPIRE":
      need(2);
      if (!entry) output = 0;
      else {
        const delay = integer(args[1]) * (cmd === "EXPIRE" ? 1000 : 1);
        if (delay <= 0) delete keys[key];
        else entry.expiresAt = now + delay;
        output = 1;
      }
      break;
    case "PERSIST":
      need(1);
      output = entry?.expiresAt ? 1 : 0;
      if (entry) delete entry.expiresAt;
      break;
    case "KEYS":
      need(1);
      output = Object.keys(keys).filter((k) => glob(k, key));
      break;
    case "SCAN": {
      need(1);
      const cursor = integer(key);
      let pattern = "*",
        count = 10;
      for (let i = 1; i < args.length; i += 2) {
        if (args[i].toUpperCase() === "MATCH") pattern = args[i + 1];
        else if (args[i].toUpperCase() === "COUNT")
          count = integer(args[i + 1]);
        else throw new Error("Supported SCAN options: MATCH, COUNT.");
      }
      if (count < 1 || cursor < 0) throw new Error("Invalid cursor or count.");
      const all = Object.keys(keys);
      const end = Math.min(all.length, cursor + count);
      output = [
        end >= all.length ? "0" : String(end),
        all.slice(cursor, end).filter((k) => glob(k, pattern)),
      ];
      break;
    }
    case "HSET": {
      need(3);
      if (args.length % 2 !== 1)
        throw new Error("HSET needs field/value pairs.");
      const e = typed("hash", {});
      output = 0;
      for (let i = 1; i < args.length; i += 2) {
        if (["__proto__", "constructor", "prototype"].includes(args[i]))
          throw new Error("Reserved field.");
        if (!(args[i] in e.value)) output++;
        e.value[args[i]] = args[i + 1];
      }
      break;
    }
    case "HGET":
    case "HGETALL":
    case "HINCRBY": {
      need(cmd === "HGETALL" ? 1 : cmd === "HGET" ? 2 : 3);
      if (entry && entry.type !== "hash") throw new Error("WRONGTYPE");
      if (cmd === "HGETALL") output = entry?.value || {};
      else if (cmd === "HGET") output = entry?.value[args[1]] ?? null;
      else {
        const e = typed("hash", {});
        if (["__proto__", "constructor", "prototype"].includes(args[1]))
          throw new Error("Reserved field.");
        const n = integer(e.value[args[1]] ?? "0") + integer(args[2]);
        e.value[args[1]] = String(n);
        output = n;
      }
      break;
    }
    case "LPUSH":
    case "RPUSH": {
      need(2);
      const e = typed("list", []);
      for (const v of args.slice(1))
        cmd === "LPUSH" ? e.value.unshift(v) : e.value.push(v);
      output = e.value.length;
      break;
    }
    case "LPOP":
    case "RPOP": {
      need(1);
      if (entry && entry.type !== "list") throw new Error("WRONGTYPE");
      output =
        cmd === "LPOP"
          ? (entry?.value.shift() ?? null)
          : (entry?.value.pop() ?? null);
      if (entry && !entry.value.length) delete keys[key];
      break;
    }
    case "LLEN":
    case "LRANGE":
    case "LPOS": {
      need(cmd === "LLEN" ? 1 : cmd === "LPOS" ? 2 : 3);
      if (entry && entry.type !== "list") throw new Error("WRONGTYPE");
      const a = entry?.value || [];
      if (cmd === "LLEN") output = a.length;
      else if (cmd === "LPOS") {
        const i = a.indexOf(args[1]);
        output = i < 0 ? null : i;
      } else {
        const start = integer(args[1]),
          end = integer(args[2]);
        output = a.slice(
          start,
          end === -1 ? undefined : end < 0 ? a.length + end + 1 : end + 1,
        );
      }
      break;
    }
    case "SADD": {
      need(2);
      const e = typed("set", []);
      output = 0;
      for (const v of args.slice(1))
        if (!e.value.includes(v)) {
          e.value.push(v);
          output++;
        }
      break;
    }
    case "SMEMBERS":
    case "SCARD":
    case "SISMEMBER":
    case "SINTER": {
      need(cmd === "SISMEMBER" ? 2 : 1);
      if (entry && entry.type !== "set") throw new Error("WRONGTYPE");
      const a = entry?.value || [];
      if (cmd === "SCARD") output = a.length;
      else if (cmd === "SISMEMBER") output = a.includes(args[1]) ? 1 : 0;
      else if (cmd === "SMEMBERS") output = a;
      else {
        for (const k of args)
          if (keys[k] && keys[k].type !== "set") throw new Error("WRONGTYPE");
        output = a.filter((v: string) =>
          args.slice(1).every((k) => keys[k]?.value.includes(v)),
        );
      }
      break;
    }
    case "ZADD":
    case "ZINCRBY": {
      need(3);
      const e = typed("zset", {});
      if (cmd === "ZINCRBY") {
        const member = args[2];
        if (["__proto__", "constructor", "prototype"].includes(member))
          throw new Error("Reserved member.");
        e.value[member] = (e.value[member] ?? 0) + numeric(args[1]);
        output = String(e.value[member]);
      } else {
        if (args.length % 2 !== 1)
          throw new Error("ZADD needs score/member pairs.");
        output = 0;
        for (let i = 1; i < args.length; i += 2) {
          const member = args[i + 1];
          if (["__proto__", "constructor", "prototype"].includes(member))
            throw new Error("Reserved member.");
          if (!(member in e.value)) output++;
          e.value[member] = numeric(args[i]);
        }
      }
      break;
    }
    case "ZRANK":
    case "ZREVRANK":
    case "ZRANGE":
    case "ZREVRANGE": {
      need(cmd.endsWith("RANK") ? 2 : 3);
      if (entry && entry.type !== "zset") throw new Error("WRONGTYPE");
      let a = Object.entries(entry?.value || {}).sort(
        ([a, x], [b, y]) => Number(x) - Number(y) || a.localeCompare(b),
      );
      if (cmd.includes("REV")) a.reverse();
      if (cmd.endsWith("RANK")) {
        const i = a.findIndex(([m]) => m === args[1]);
        output = i < 0 ? null : i;
      } else {
        const start = integer(args[1]),
          end = integer(args[2]);
        a = a.slice(
          start,
          end === -1 ? undefined : end < 0 ? a.length + end + 1 : end + 1,
        );
        if (args[3] && args[3].toUpperCase() !== "WITHSCORES")
          throw new Error("Supported range option: WITHSCORES.");
        output = args[3]
          ? a.flatMap(([m, v]) => [m, String(v)])
          : a.map(([m]) => m);
      }
      break;
    }
    case "JSON.SET": {
      need(3);
      if (entry && entry.type !== "json") throw new Error("WRONGTYPE");
      const path = args[1],
        value = JSON.parse(args[2]);
      if (path === "$") {
        keys[key] = { type: "json", value, expiresAt: entry?.expiresAt };
      } else {
        if (!entry) throw new Error("JSON key does not exist.");
        const bits = jsonBits(path);
        const field = bits.pop()!;
        const parent = bits.reduce((o, k) => o?.[k], entry.value);
        if (!parent || typeof parent !== "object")
          throw new Error("JSON path parent not found.");
        parent[field] = value;
      }
      output = "OK";
      break;
    }
    case "JSON.GET":
    case "JSON.NUMINCRBY": {
      need(cmd === "JSON.GET" ? 1 : 3);
      if (!entry) output = null;
      else {
        if (entry.type !== "json") throw new Error("WRONGTYPE");
        const path = args[1] || "$";
        if (cmd === "JSON.GET") {
          const val = pathGet(entry.value, path);
          output = val === undefined ? [] : args[1] ? [val] : val;
        } else {
          const bits = jsonBits(path),
            field = bits.pop()!;
          const parent = bits.reduce((o, k) => o?.[k], entry.value);
          if (typeof parent?.[field] !== "number")
            throw new Error("JSON path is not numeric.");
          parent[field] += numeric(args[2]);
          output = [parent[field]];
        }
      }
      break;
    }
    case "FT.CREATE": {
      need(8);
      if (state.indexes[key]) throw new Error("Index already exists.");
      if (args[1].toUpperCase() !== "ON" || args[2].toUpperCase() !== "JSON")
        throw new Error("Teaching subset supports ON JSON.");
      const p = args.findIndex((x) => x.toUpperCase() === "PREFIX"),
        schema = args.findIndex((x) => x.toUpperCase() === "SCHEMA");
      if (p < 0 || args[p + 1] !== "1" || schema < 0)
        throw new Error("Use PREFIX 1 prefix: SCHEMA path AS alias TAG|TEXT.");
      const fields: Record<string, string> = {};
      for (let i = schema + 1; i < args.length; i += 4) {
        if (
          args[i + 1]?.toUpperCase() !== "AS" ||
          !["TAG", "TEXT"].includes(args[i + 3]?.toUpperCase())
        )
          throw new Error("Use path AS alias TAG or TEXT.");
        jsonBits(args[i]);
        fields[args[i + 2]] = args[i];
      }
      state.indexes[key] = { prefix: args[p + 2], fields };
      output = "OK";
      break;
    }
    case "FT.SEARCH": {
      need(2);
      const index = state.indexes[key];
      if (!index)
        throw new Error("Unknown Index name. Create the index first.");
      const m = args[1].match(/^@(\w+):\{([^}]+)\}$/);
      if (!m)
        throw new Error(
          "Teaching subset: @field:{ExactTag}. Full Redis Search syntax is outside this simulator.",
        );
      const path = index.fields[m[1]];
      if (!path) throw new Error("Field is not indexed.");
      const found = Object.entries(keys).filter(
        ([k, v]) =>
          k.startsWith(index.prefix) &&
          v.type === "json" &&
          String(pathGet(v.value, path)) === m[2],
      );
      output = {
        total: found.length,
        documents: found.map(([key, v]) => ({ key, value: v.value })),
      };
      break;
    }
    case "INFO":
      throw new Error(
        "This browser simulation has no Redis server memory or persistence configuration. Run INFO against your real service.",
      );
    default:
      throw new Error(
        `Unsupported command ${cmd || "(empty)"}. No command was sent to Redis Cloud. See supported examples.`,
      );
  }
  return { state, output };
}
