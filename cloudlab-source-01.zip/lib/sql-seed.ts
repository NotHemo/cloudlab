export const sqlSeed = `
CREATE TABLE authors(id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,name text NOT NULL);
INSERT INTO authors(name) VALUES ('Ada Lovelace'),('Grace Hopper');
CREATE TABLE books(id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,title text NOT NULL,published int,author_id bigint REFERENCES authors(id));
INSERT INTO books(title,published,author_id) VALUES ('Notes on the Analytical Engine',1843,1),('The First Computer Program',1843,1),('A Compiler for the A-0 System',1952,2),('Unassigned book',2026,NULL);
CREATE TABLE stg_customer(customer_id int,first_name text,last_name text,email text);
INSERT INTO stg_customer VALUES (1,'Mary','Smith','mary@example.test'),(2,'Ahmed','Ali','ahmed@example.test');
CREATE TABLE stg_staff(staff_id int,first_name text,last_name text);
INSERT INTO stg_staff VALUES (1,'Mariam','Hasan'),(2,'Omar','Khalid');
CREATE TABLE stg_film(film_id int,title text,rental_rate double precision,rating text);
INSERT INTO stg_film VALUES (25,'Cloud Journey',4.99,'G'),(44,'Data Stories',2.99,'PG');
CREATE TABLE stg_inventory(inventory_id int,film_id int);
INSERT INTO stg_inventory VALUES (10,25),(11,44);
CREATE TABLE stg_rental(rental_id int,rental_date timestamp,inventory_id int,customer_id int,staff_id int);
INSERT INTO stg_rental VALUES (500,'2026-03-01 10:00',10,1,1),(501,'2026-03-01 11:00',11,2,2),(502,'2026-04-02 10:00',10,1,1),(503,'2026-04-03 09:00',11,2,1);
CREATE TABLE stg_payment(payment_id int,rental_id int,customer_id int,staff_id int,amount double precision,payment_date timestamp);
INSERT INTO stg_payment VALUES (1,500,1,1,4.99,'2026-03-01'),(2,501,2,2,2.99,'2026-03-01'),(3,502,1,1,4.99,'2026-04-02');
CREATE TABLE dim_customer AS SELECT * FROM stg_customer;
CREATE TABLE dim_staff AS SELECT * FROM stg_staff;
CREATE TABLE dim_film AS SELECT * FROM stg_film;
CREATE TABLE dim_date AS SELECT ROW_NUMBER() OVER(ORDER BY full_date) AS date_id,full_date,EXTRACT(YEAR FROM full_date)::int AS year,EXTRACT(MONTH FROM full_date)::int AS month FROM (SELECT DISTINCT rental_date::date AS full_date FROM stg_rental) d;
CREATE TABLE fact_rental AS SELECT r.rental_id,r.customer_id,r.staff_id,i.film_id,d.date_id,p.amount FROM stg_rental r JOIN stg_inventory i ON r.inventory_id=i.inventory_id JOIN dim_date d ON r.rental_date::date=d.full_date LEFT JOIN stg_payment p ON p.rental_id=r.rental_id;
SET statement_timeout='3s';
`;
export const sqlExamples = [
  { title: "Read books", code: "SELECT * FROM books ORDER BY id;" },
  {
    title: "INNER JOIN",
    code: "SELECT b.title,a.name FROM books b JOIN authors a ON b.author_id=a.id ORDER BY b.id;",
  },
  {
    title: "LEFT JOIN",
    code: "SELECT b.title,a.name FROM books b LEFT JOIN authors a ON b.author_id=a.id ORDER BY b.id;",
  },
  {
    title: "Try an invalid reference",
    code: "INSERT INTO books(title,author_id) VALUES ('Invalid author',999);",
  },
  {
    title: "Create and insert",
    code: "CREATE TABLE students(student_id int PRIMARY KEY,name text NOT NULL);\nINSERT INTO students VALUES (1,'Mariam');\nSELECT * FROM students;",
  },
  {
    title: "Test duplicate primary key",
    code: "CREATE TABLE IF NOT EXISTS students(student_id int PRIMARY KEY,name text NOT NULL);\nINSERT INTO students VALUES (1,'Mariam');\nINSERT INTO students VALUES (1,'Ahmed');",
  },
  {
    title: "Revenue by film",
    code: "SELECT f.title,COUNT(*) AS times_rented,SUM(fr.amount) AS total_revenue\nFROM fact_rental fr JOIN dim_film f ON fr.film_id=f.film_id\nGROUP BY f.title ORDER BY total_revenue DESC;",
  },
  {
    title: "Revenue by month",
    code: "SELECT d.year,d.month,SUM(fr.amount) AS revenue\nFROM fact_rental fr JOIN dim_date d ON fr.date_id=d.date_id\nGROUP BY d.year,d.month ORDER BY d.year,d.month;",
  },
  {
    title: "Validate grain",
    code: "SELECT COUNT(*),COUNT(DISTINCT rental_id) FROM fact_rental;\nSELECT COUNT(*) FROM stg_rental;\nSELECT * FROM fact_rental WHERE amount IS NULL;",
  },
];
