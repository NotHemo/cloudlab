/** Next Link handles basePath; native asset URLs need the same deployment prefix. */
export function assetPath(path: string) {
  return path.startsWith('/') ? `${process.env.NEXT_PUBLIC_BASE_PATH || ''}${path}` : path;
}
