export type Theme = "light" | "dark";
export const DEFAULT_THEME: Theme = "dark";
export function savedTheme(value: unknown): Theme {
  if (value && typeof value === "object" && "theme" in value) {
    if (value.theme === "light" || value.theme === "dark") return value.theme;
  }
  return DEFAULT_THEME;
}
// Read the existing preference before paint without writing or migrating study data.
export const themeBootstrapScript = `(function(){try{var p=JSON.parse(localStorage.getItem('it8417-progress-v1')||'null');if(p&&(p.theme==='light'||p.theme==='dark'))document.documentElement.dataset.theme=p.theme;}catch(e){}})();`;
