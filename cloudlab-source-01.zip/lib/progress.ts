import type { Progress } from "./types";
import { lessons } from "@/content/course";
const ids = new Set(lessons.map((l) => l.id));
export function parseProgressBackup(text: string): Partial<Progress> {
  const raw = JSON.parse(text);
  const p = raw.progress ?? raw;
  if (!p || typeof p !== "object") throw new Error("Not a progress backup.");
  if (
    !Array.isArray(p.completed) ||
    !p.completed.every(
      (v: unknown) => typeof v === "string" && ids.has(v as string),
    )
  )
    throw new Error("Invalid completed-lesson list.");
  for (const key of ["bookmarks", "labSteps", "days"])
    if (
      p[key] !== undefined &&
      (!Array.isArray(p[key]) ||
        !p[key].every((x: unknown) => typeof x === "string"))
    )
      throw new Error(`Invalid ${key}.`);
  for (const key of ["notes", "mastery", "answers"])
    if (
      p[key] !== undefined &&
      (!p[key] || typeof p[key] !== "object" || Array.isArray(p[key]))
    )
      throw new Error(`Invalid ${key}.`);
  if (p.notes && Object.values(p.notes).some((v) => typeof v !== "string"))
    throw new Error("Notes must be text.");
  if (
    p.mastery &&
    Object.values(p.mastery).some(
      (v) => !["know", "practice"].includes(v as string),
    )
  )
    throw new Error("Invalid flashcard mastery.");
  if (
    p.answers &&
    Object.values(p.answers).some(
      (v: any) =>
        !v || typeof v.answer !== "string" || typeof v.correct !== "boolean",
    )
  )
    throw new Error("Invalid question results.");
  return {
    completed: p.completed,
    bookmarks: (p.bookmarks || []).filter((v: string) => ids.has(v)),
    labSteps: p.labSteps || [],
    days: (p.days || []).filter((x: string) => /^\d{4}-\d{2}-\d{2}$/.test(x)),
    notes: p.notes || {},
    mastery: p.mastery || {},
    answers: p.answers || {},
  };
}
