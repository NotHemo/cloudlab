const redis: Record<string, string> = {
  PING: "Check that the Redis connection is alive; without an argument the reply is PONG.",
  SET: "Write a string value at this key. EX adds a seconds-based expiry; NX requires the key to be absent; KEEPTTL preserves an existing expiry.",
  GET: "Read the string stored at this key; a missing or expired key returns nil.",
  GETDEL: "Read the string and delete its key in one atomic command.",
  INCR: "Add one to the integer string; a missing key starts at 1.",
  HSET: "Set the following field/value pairs inside one hash key.",
  HGETALL: "Return every field and value from this hash.",
  HGET: "Return one field from this hash.",
  HINCRBY: "Add the integer increment to the named hash field.",
  RPUSH: "Append these values to the end of the list, keeping their order.",
  LPUSH: "Insert values at the front of the list.",
  LRANGE: "Read an inclusive list index range; -1 means the last element.",
  SADD: "Add unique members to the set; repeated members are not added again.",
  SINTER: "Return members present in every named set.",
  ZADD: "Set each unique sorted-set member’s numeric score.",
  ZREVRANGE:
    "Read the inclusive rank range from highest score to lowest; WITHSCORES includes scores.",
  ZINCRBY: "Change one sorted-set member’s score by this amount.",
  ZRANK: "Return the member’s ascending, zero-based rank.",
  EXPIRE: "Set or refresh this key’s expiration in seconds.",
  TTL: "Read seconds remaining: -1 means no expiry and -2 means no key.",
  PTTL: "Read remaining expiry in milliseconds, with the same -1/-2 special values.",
  PERSIST: "Remove the expiry without removing the value.",
  DEL: "Delete the named keys. It is not an owner-checked lock release.",
  TYPE: "Report the value’s Redis data type.",
  DBSIZE: "Count the keys in the selected database.",
  SCAN: "Iterate the keyspace with a cursor; MATCH filters names and COUNT is a work hint.",
  KEYS: "Return matching names in one potentially blocking keyspace scan.",
  INFO: "Inspect the actual server’s operational metadata; permissions may restrict it.",
  CONFIG: "Read or change a server setting where the provider permits it.",
  OBJECT:
    "Inspect object metadata, such as internal encoding, where permitted.",
  "JSON.SET":
    "Store JSON at the root or change the value at the given JSONPath. The JSON argument must remain valid JSON.",
  "JSON.GET":
    "Read the JSON value at a path; a JSONPath selection can return an array of matches.",
  "JSON.NUMINCRBY":
    "Atomically add the given number to the numeric JSON value at that path.",
  "FT.CREATE":
    "Create a search index with the chosen key prefix, JSON paths, aliases and field types.",
  "FT.SEARCH": "Search the previously defined index using the given query.",
  SETBIT: "Set one bit at the specified offset in a bitmap string.",
  PFADD: "Add values to an approximate distinct-count structure.",
  PFCOUNT: "Read the approximate distinct count from HyperLogLog.",
  GEOADD: "Add a member with longitude and latitude to a geospatial index.",
  XADD: "Append a field/value event entry to a Redis stream.",
};
const mongo: Record<string, string> = {
  insertOne: "Insert one document; MongoDB supplies _id when it is omitted.",
  insertMany:
    "Insert the array’s documents; inspect write results for partial errors.",
  find: "Filter documents and optionally project returned fields. This does not modify stored documents.",
  findOne: "Return one matching document rather than a cursor of matches.",
  updateOne: "Modify one matching document with the stated update operators.",
  updateMany: "Modify all matching documents with the stated update operators.",
  replaceOne:
    "Replace one matching document’s contents while following _id rules.",
  deleteOne: "Delete one matching document.",
  deleteMany:
    "Delete every matching document; an empty filter matches the entire collection.",
  aggregate:
    "Run these pipeline stages in sequence, passing each stage’s result to the next.",
  createIndex:
    "Build an index for the stated fields; the text index is required for the course’s $text search.",
  countDocuments: "Count documents matching this filter.",
  distinct: "Return the distinct values found for this field.",
  bulkWrite: "Submit the explicitly listed write operations as a batch.",
};
export function explainCodeLine(line: string): string {
  const x = line.trim();
  if (!x) return "";
  if (/^(--|\/\/|#)/.test(x))
    return "A comment or teaching note. It explains the example and is not a database operation.";
  const first = x.split(/\s+/)[0].toUpperCase();
  if (redis[first]) return redis[first];
  const method = x.match(/db\.\w+\.(\w+)\(/)?.[1];
  if (method && mongo[method]) return mongo[method];
  if (/^use\s/.test(x))
    return "Select the MongoDB database for subsequent shell commands. It is created only on the first write.";
  if (x.startsWith("\\copy"))
    return "Run a psql client-side export: the SELECT chooses columns, the local filename receives CSV, and HEADER includes column names.";
  if (/^CREATE(?: OR REPLACE)? TABLE/i.test(x))
    return x.includes(" AS ")
      ? "Create a stored table from the following SELECT result (CTAS). OR REPLACE intentionally replaces an existing table where supported."
      : "Start a table definition: the following fields declare the data structure. Check which SQL engine this syntax targets.";
  if (/^ALTER TABLE/i.test(x))
    return "Modify an existing table’s structure rather than rebuilding its stored rows.";
  if (/^ADD COLUMN/i.test(x))
    return "Add the named field and its type. REFERENCES declares a foreign-key relationship; existing rows initially receive NULL unless otherwise specified.";
  if (/^INSERT INTO/i.test(x))
    return "Insert rows into the named table, using the listed column order or values selected by the following query.";
  if (/^UPDATE\s/i.test(x))
    return "Change matching rows. The SET clause names new values and WHERE limits the affected records.";
  if (/^CALL\s/i.test(x))
    return "Invoke a stored procedure; the procedure must exist and you must have permission to execute it.";
  if (/^DESCRIBE DETAIL/i.test(x))
    return "Inspect table metadata in Databricks, including its format. This is not PostgreSQL SQL.";
  if (/^SELECT\s/i.test(x))
    return "Choose the output expressions. Asterisk means all fields; SUM totals values and COUNT counts rows where used.";
  if (/^FROM\s/i.test(x))
    return "Name the input table or subquery. A following short name is an alias used by other expressions.";
  if (/^LEFT JOIN/i.test(x))
    return "Keep all rows from the left input and attach matches satisfying ON. Missing matches yield NULL; multiple matches can multiply rows.";
  if (/^(INNER )?JOIN\s/i.test(x))
    return "Combine matching row pairs using the ON condition. Nonmatching rows are omitted by an inner join.";
  if (/^ON\s|^AND\s/i.test(x))
    return "Apply this comparison as part of the join/filter condition. Check both key identity and compatible data types.";
  if (/^WHERE\s/i.test(x))
    return "Keep only rows where this condition is true. IS NULL tests missing values; ordinary equality to NULL does not.";
  if (/^GROUP BY/i.test(x))
    return "Form one group per combination of these expressions before calculating totals or counts.";
  if (/^ORDER BY/i.test(x))
    return "Sort the result by these expressions; DESC means highest first, while ascending is the default.";
  if (/^LIMIT\s/i.test(x))
    return "Return at most this many result rows, after the preceding query operations.";
  if (/^UNION ALL/i.test(x))
    return "Append another query’s result rows without removing duplicates.";
  if (/GENERATED ALWAYS AS IDENTITY/i.test(x))
    return "Declare an automatically generated numeric identifier. In PostgreSQL, PRIMARY KEY also enforces uniqueness and non-NULL values.";
  if (/REFERENCES\s/i.test(x))
    return "Declare a typed foreign-key field that refers to the named parent key. Add NOT NULL separately when a reference is required.";
  if (/CAST\(/i.test(x))
    return "Convert the expression to the type named after AS. A second AS labels the output column; failed conversions need inspection.";
  if (/ROW_NUMBER\(/i.test(x))
    return "Assign a sequential row number using the window’s ORDER BY; this example uses it as a surrogate key.";
  if (
    /^(id|name|title|published|price|available|created_at|customer_key|customer_id|first_name|last_name|email|valid_from|valid_to|is_current)\s/i.test(
      x,
    )
  )
    return "Define this column’s name, data type and any constraints. NOT NULL requires a value; the declared type controls valid values and operations.";
  if (/^\$?\{?\s*\$match/i.test(x))
    return "Filter pipeline documents before later stages.";
  if (x.includes("$unwind"))
    return "Expand the specified array into one pipeline input per element; preserveNullAndEmptyArrays keeps unmatched inputs when requested.";
  if (x.includes("$group"))
    return "Group pipeline inputs by the _id expression and calculate the specified accumulators.";
  if (x.includes("$lookup"))
    return "Attach an array of documents whose foreignField matches the input localField.";
  if (x.includes("$merge") || x.includes("$out"))
    return "Write the pipeline result to a target collection as the terminal stage; merge policies and full replacement behave differently.";
  if (x.includes("$sort"))
    return "Order pipeline results; 1 means ascending and -1 means descending.";
  if (/^mongosh\s/.test(x))
    return "Start the MongoDB shell using the actual cluster endpoint and database user; supply credentials privately.";
  if (/^mongodump\s/.test(x))
    return "Run Database Tools in your operating-system terminal to write a BSON backup of the named database/collection.";
  if (/^mongorestore\s/.test(x))
    return "Run Database Tools in your operating-system terminal to restore the specified BSON backup into a deliberate destination.";
  if (/^redis-cli\s/.test(x))
    return "Start the Redis command-line client with the correct host and assigned port. Use the service-required authentication and TLS settings.";
  if (/^Set-Cookie:/i.test(x))
    return "An HTTP response header sets the session cookie; HttpOnly, Secure and SameSite control how the browser handles it.";
  if (x.includes("require('ioredis')") || x.includes('require("ioredis")'))
    return "Import the Redis client library into this Node.js application; it is not the Redis server itself.";
  if (/new Redis/.test(x))
    return "Create a Redis client configured to connect to your chosen endpoint. Environment variables keep settings out of the example source.";
  if (/process\.env/.test(x))
    return "Read connection configuration from the application environment. Never substitute a real secret into shared source code.";
  if (/redis\.set|client\.set/.test(x))
    return "Send SET through the application client; the optional EX argument gives this example a lifetime in seconds.";
  if (/redis\.get|client\.get/.test(x))
    return "Send GET through the client and read the stored value. await waits for the asynchronous response.";
  if (/\.quit\(/.test(x))
    return "Close the client connection when the script finishes so it does not consume an unnecessary connection.";
  if (/\.ping\(/.test(x))
    return "Send PING through the client and inspect the returned response to verify connectivity.";
  if (/^rs\.status/.test(x))
    return "Read permitted replica-set status and select each member’s name/state for a compact report.";
  if (/^\(?['"]/.test(x) || /^VALUES/i.test(x))
    return "Supply literal row values in the insert’s column order. Quotes represent strings; numbers and NULL have different meanings.";
  if (/^\)?[;\]}),]*$/.test(x))
    return "Close the current statement, object, array or function. Balanced delimiters determine where each instruction ends.";
  if (/^[a-z]+\.[a-z_]+,?$/i.test(x))
    return "Select this named field through its table alias; it becomes part of the result row.";
  if (/AS\s+\w+/i.test(x))
    return "Name the result expression with an alias so later output and queries can refer to it clearly.";
  return "This line continues the surrounding expression or data object. Use the explanation and ordered steps next to this example to interpret its role; it is not a separate command.";
}
