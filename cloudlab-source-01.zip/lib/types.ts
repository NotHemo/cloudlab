export type Difficulty = "Easy" | "Medium" | "Hard";
export type QuestionType =
  | "Multiple choice"
  | "True / false"
  | "Fill in the blank"
  | "Predict the output"
  | "Code interpretation"
  | "Scenario"
  | "Matching";
export type Question = {
  id: string;
  lessonId: string;
  week: number;
  type: QuestionType;
  difficulty: Difficulty;
  prompt: string;
  code?: string;
  options?: string[];
  answer: string;
  explanation: string;
  wrong?: Record<string, string>;
  pairs?: [string, string][];
};
export type Concept = {
  term: string;
  explanation: string;
  why: string;
  analogy: string;
  code?: string;
  lines?: string[];
  steps: string[];
  check: string;
  answer: string;
};
export type Lesson = {
  id: string;
  week: number;
  title: string;
  description: string;
  minutes: number;
  slides: number[];
  labParts: string[];
  concepts: Concept[];
  takeaways: string[];
  mistakes: string[];
  visual?:
    | "models"
    | "join"
    | "etl"
    | "star"
    | "storage"
    | "mongo"
    | "redis"
    | "scd"
    | "cache";
  note?: string;
  image?: string;
};
export type Module = {
  week: number;
  title: string;
  short: string;
  platform: string;
  description: string;
  lessonIds: string[];
};
export type LabStep = {
  title: string;
  instruction: string;
  code?: string;
  expected: string;
  hint: string;
  error: string;
  optional?: boolean;
  tool?: string;
};
export type Lab = {
  week: number;
  title: string;
  objectives: string[];
  prerequisites: string;
  steps: LabStep[];
};
export type Progress = {
  completed: string[];
  labSteps: string[];
  bookmarks: string[];
  notes: Record<string, string>;
  mastery: Record<string, "know" | "practice">;
  answers: Record<string, { correct: boolean; answer: string }>;
  scores: { date: string; score: number; total: number; mode: string }[];
  days: string[];
  lastLesson: string;
  theme: "light" | "dark";
};
