"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  Clock3,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  XCircle,
  RotateCcw,
  ClipboardCheck,
} from "lucide-react";
import { questions, isCorrect } from "@/content/questions";
import { lessonById } from "@/content/course";
import { shuffle, localDay } from "@/lib/utils";
import type { Question } from "@/lib/types";
import { useProgress } from "./progress-provider";
import { QuestionCard } from "./question";
import { Button } from "./ui/button";
const format = (s: number) =>
  `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
export function QuizWorkspace() {
  const [mode, setMode] = useState<"practice" | "exam">("practice"),
    [week, setWeek] = useState("0"),
    [difficulty, setDifficulty] = useState("All"),
    [type, setType] = useState("All"),
    [count, setCount] = useState(10),
    [minutes, setMinutes] = useState(15),
    [session, setSession] = useState<Question[]>([]),
    [answers, setAnswers] = useState<Record<string, string>>({}),
    [index, setIndex] = useState(0),
    [seconds, setSeconds] = useState(0),
    [status, setStatus] = useState<"setup" | "active" | "review">("setup"),
    [remainingOnly, setRemainingOnly] = useState(false);
  const { progress, update } = useProgress();
  const finished = useRef(false);
  const deadline = useRef(0);
  useEffect(() => {
    const w = new URLSearchParams(window.location.search).get("week");
    if (w && +w >= 1 && +w <= 6) setWeek(w);
  }, []);
  const pool = questions.filter(
    (q) =>
      (week === "0" || q.week === +week) &&
      (difficulty === "All" || q.difficulty === difficulty) &&
      (type === "All" || q.type === type) &&
      (!remainingOnly || progress.answers[q.id]?.correct === false),
  );
  function start() {
    setSession(shuffle(pool).slice(0, Math.min(count, pool.length)));
    setAnswers({});
    setIndex(0);
    setSeconds(minutes * 60);
    deadline.current = Date.now() + minutes * 60000;
    finished.current = false;
    setStatus("active");
  }
  function finish() {
    if (finished.current) return;
    finished.current = true;
    setStatus("review");
    const score = session.filter((q) =>
      isCorrect(q, answers[q.id] || ""),
    ).length;
    update((p) => ({
      ...p,
      answers: {
        ...p.answers,
        ...Object.fromEntries(
          session
            .filter((q) => answers[q.id])
            .map((q) => [
              q.id,
              { correct: isCorrect(q, answers[q.id]), answer: answers[q.id] },
            ]),
        ),
      },
      scores: [
        ...p.scores,
        { date: localDay(), score, total: session.length, mode },
      ].slice(-100),
    }));
  }
  useEffect(() => {
    if (status !== "active" || mode !== "exam") return;
    const t = setInterval(() => {
      setSeconds(
        Math.max(0, Math.ceil((deadline.current - Date.now()) / 1000)),
      );
    }, 250);
    return () => clearInterval(t);
  }, [status, mode]);
  useEffect(() => {
    if (status === "active" && mode === "exam" && seconds === 0) finish();
  }, [seconds, status, mode]);
  const current = session[index],
    score = session.filter((q) => isCorrect(q, answers[q.id] || "")).length;
  return (
    <div className="page quiz-page">
      <div className="page-heading">
        <div>
          <span className="eyeline">Build confidence, find the gaps</span>
          <h1>
            {status === "review"
              ? "Let’s review your answers."
              : "Quiz & mock exam"}
          </h1>
          <p>Questions grounded in your six weeks of lectures and labs.</p>
        </div>
        <span className="quiet-label">
          {questions.length} questions · 7 question formats
        </span>
      </div>
      {status === "setup" ? (
        <div className="quiz-setup-layout">
          <section className="quiz-config">
            <div className="mode-choice">
              <button
                aria-pressed={mode === "practice"}
                onClick={() => setMode("practice")}
              >
                <CheckCircle2 size={22} />
                <strong>Practice quiz</strong>
                <p>Immediate feedback. Learn after every answer.</p>
              </button>
              <button
                aria-pressed={mode === "exam"}
                onClick={() => setMode("exam")}
              >
                <Clock3 size={22} />
                <strong>Mock exam</strong>
                <p>A timed session. Review everything at the end.</p>
              </button>
            </div>
            <div className="form-grid">
              <label>
                Course coverage
                <select value={week} onChange={(e) => setWeek(e.target.value)}>
                  <option value="0">All six weeks</option>
                  {[1, 2, 3, 4, 5, 6].map((w) => (
                    <option value={w} key={w}>
                      Week {w}
                    </option>
                  ))}
                </select>
              </label>
              <label>
                Difficulty
                <select
                  value={difficulty}
                  onChange={(e) => setDifficulty(e.target.value)}
                >
                  {["All", "Easy", "Medium", "Hard"].map((d) => (
                    <option key={d}>{d}</option>
                  ))}
                </select>
              </label>
              <label>
                Question type
                <select value={type} onChange={(e) => setType(e.target.value)}>
                  {["All", ...new Set(questions.map((q) => q.type))].map(
                    (t) => (
                      <option key={t}>{t}</option>
                    ),
                  )}
                </select>
              </label>
              <label>
                Question count
                <input
                  type="number"
                  min={1}
                  max={questions.length}
                  value={count}
                  onChange={(e) =>
                    setCount(
                      Math.max(
                        1,
                        Math.min(questions.length, Number(e.target.value) || 1),
                      ),
                    )
                  }
                />
              </label>
              {mode === "exam" && (
                <label>
                  Time limit (minutes)
                  <input
                    type="number"
                    min={1}
                    max={180}
                    value={minutes}
                    onChange={(e) =>
                      setMinutes(
                        Math.max(1, Math.min(180, Number(e.target.value) || 1)),
                      )
                    }
                  />
                </label>
              )}
            </div>
            <label className="checkbox-label">
              <input
                type="checkbox"
                checked={remainingOnly}
                onChange={(e) => setRemainingOnly(e.target.checked)}
              />
              Revisit previously incorrect answers only
            </label>
            <div className="config-footer">
              <p>
                {pool.length
                  ? `${Math.min(count, pool.length)} questions will be selected from ${pool.length} matching questions.`
                  : "No questions match these filters. Change the filters or answer a practice question first."}
              </p>
              <Button onClick={start} disabled={!pool.length}>
                Start {mode === "exam" ? "mock exam" : "practice"}{" "}
                <ArrowRight size={16} />
              </Button>
            </div>
          </section>
          <aside className="tonal-panel">
            <ClipboardCheck size={26} />
            <h2>A useful rehearsal</h2>
            <p>
              This is a study tool, not a prediction of the university’s exam
              format or marking scheme.
            </p>
            <ul>
              <li>Multiple choice and true/false</li>
              <li>Short fill-in answers</li>
              <li>Predict output and interpret code</li>
              <li>Scenarios and matching</li>
            </ul>
            {progress.scores.length > 0 && (
              <>
                <h3>Recent sessions</h3>
                {progress.scores
                  .slice(-4)
                  .reverse()
                  .map((s, i) => (
                    <div className="score-history" key={i}>
                      <span>
                        {s.date} · {s.mode}
                      </span>
                      <strong>
                        {s.score}/{s.total}
                      </strong>
                    </div>
                  ))}
              </>
            )}
          </aside>
        </div>
      ) : status === "active" && current ? (
        <section className="active-quiz">
          <div className="exam-status">
            <span>
              Question {index + 1} of {session.length} ·{" "}
              {Object.keys(answers).length} saved
            </span>
            {mode === "exam" ? (
              <strong className={seconds < 60 ? "time-low" : ""}>
                <Clock3 size={17} />
                {format(seconds)}
              </strong>
            ) : (
              <span>Practice · take your time</span>
            )}
          </div>
          <div className="progress-track">
            <div
              style={{
                width: `${(Object.keys(answers).length / session.length) * 100}%`,
              }}
            />
          </div>
          <QuestionCard
            key={current.id}
            question={current}
            exam={mode === "exam"}
            stored={answers[current.id]}
            onAnswer={(answer) =>
              setAnswers((a) => ({ ...a, [current.id]: answer }))
            }
          />
          <div className="quiz-nav">
            <Button
              variant="outline"
              disabled={index === 0}
              onClick={() => setIndex((i) => i - 1)}
            >
              <ArrowLeft size={15} />
              Previous
            </Button>
            <div className="question-dots">
              {session.map((q, i) => (
                <button
                  key={q.id}
                  aria-label={`Go to question ${i + 1}${answers[q.id] ? " (answered)" : ""}`}
                  aria-current={i === index ? "step" : undefined}
                  className={answers[q.id] ? "answered" : ""}
                  onClick={() => setIndex(i)}
                >
                  {i + 1}
                </button>
              ))}
            </div>
            {index < session.length - 1 ? (
              <Button onClick={() => setIndex((i) => i + 1)}>
                Next
                <ArrowRight size={15} />
              </Button>
            ) : (
              <Button onClick={finish}>
                {mode === "exam" ? "Submit exam" : "See results"}
                <CheckCircle2 size={15} />
              </Button>
            )}
          </div>
          {mode === "exam" && (
            <p className="muted">
              Choose and save each answer before moving on. Unanswered questions
              receive zero credit.
            </p>
          )}
          <Button variant="ghost" onClick={finish}>
            Finish session now
          </Button>
        </section>
      ) : (
        <section>
          <div className="exam-result">
            <div>
              <span className="eyeline">
                {mode === "exam" ? "Mock exam" : "Practice quiz"} complete
              </span>
              <h2>
                {score} / {session.length}{" "}
                <small>{Math.round((score / session.length) * 100)}%</small>
              </h2>
              <p>
                {score === session.length
                  ? "All correct. Try a different difficulty to keep stretching."
                  : "The explanations below show you exactly what to revisit."}
              </p>
            </div>
            <Button onClick={() => setStatus("setup")}>
              <RotateCcw size={16} />
              Set up another session
            </Button>
          </div>
          <h2>Answer review</h2>
          {session.map((q, i) => {
            const correct = isCorrect(q, answers[q.id] || "");
            return (
              <section
                className={`review-card ${correct ? "good" : "bad"}`}
                key={q.id}
              >
                <div className="eyeline">
                  Question {i + 1} · Week {q.week} · {q.difficulty}
                  {correct ? <CheckCircle2 size={18} /> : <XCircle size={18} />}
                </div>
                <h3>{q.prompt}</h3>
                <p>
                  <b>Your answer:</b> {answers[q.id] || "Not answered"}
                </p>
                <p>
                  <b>Correct answer:</b>{" "}
                  {q.pairs
                    ? q.pairs.map((p) => `${p[0]} → ${p[1]}`).join("; ")
                    : q.answer}
                </p>
                <p>{q.explanation}</p>
                {q.wrong && (
                  <details>
                    <summary>Why the other choices are wrong</summary>
                    {Object.entries(q.wrong).map(([option, why]) => (
                      <p key={option}>
                        <b>{option}</b> — {why}
                      </p>
                    ))}
                  </details>
                )}
                <Link href={`/lesson/${q.lessonId}/`} className="text-link">
                  Review: {lessonById(q.lessonId)?.title}
                  <ArrowRight size={14} />
                </Link>
              </section>
            );
          })}
        </section>
      )}
    </div>
  );
}
