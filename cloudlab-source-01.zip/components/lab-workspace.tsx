"use client";
import { assetPath } from "@/lib/asset-path";
import { useEffect, useState } from "react";
import Link from "next/link";
import {
  ArrowRight,
  Check,
  FlaskConical,
  Terminal,
  ChevronRight,
  Download,
  Info,
} from "lucide-react";
import { labs } from "@/content/labs";
import { useProgress } from "./progress-provider";
import { Button } from "./ui/button";
import { CodeBlock } from "./code-block";
import { SQLPlayground, MongoPlayground, RedisPlayground } from "./playgrounds";
import {
  JoinVisualizer,
  ETLSimulator,
  StarExplorer,
  StorageComparison,
  SCDExplorer,
  CacheSimulator,
  ModelComparison,
} from "./visualizations";
const tools = [
  "SQL",
  "JOIN",
  "ETL",
  "Star schema",
  "Storage comparison",
  "SCD explorer",
  "MongoDB",
  "Redis",
  "Cache",
  "Compare models",
];
export function LabWorkspace() {
  const [week, setWeek] = useState(1),
    [tab, setTab] = useState<"guide" | "practice">("guide"),
    [tool, setTool] = useState("SQL");
  const { progress, update } = useProgress();
  useEffect(() => {
    const w = Number(new URLSearchParams(window.location.search).get("week"));
    if (w >= 1 && w <= 6) setWeek(w);
  }, []);
  const lab = labs[week - 1];
  const done = lab.steps.filter((_, i) =>
    progress.labSteps.includes(`${week}-${i}`),
  ).length;
  function openTool(t?: string) {
    const map: Record<string, string> = {
      SQL: "SQL",
      JOIN: "JOIN",
      ETL: "ETL",
      "Star schema": "Star schema",
      "Storage comparison": "Storage comparison",
      "SCD explorer": "SCD explorer",
      MongoDB: "MongoDB",
      Redis: "Redis",
    };
    setTool(
      map[t || ""] || (week === 5 ? "MongoDB" : week === 6 ? "Redis" : "SQL"),
    );
    setTab("practice");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  return (
    <div className="page">
      <div className="page-heading">
        <div>
          <span className="eyeline">Learn by doing</span>
          <h1>Practice labs</h1>
          <p>
            Follow the original activities. Try the ideas in a safe local
            sandbox.
          </p>
        </div>
        <span className="quiet-label">
          <FlaskConical size={17} />
          No cloud credentials needed here
        </span>
      </div>
      <div className="tabs">
        <button aria-selected={tab === "guide"} onClick={() => setTab("guide")}>
          Guided labs
        </button>
        <button
          aria-selected={tab === "practice"}
          onClick={() => setTab("practice")}
        >
          Interactive playgrounds
        </button>
      </div>
      {tab === "guide" ? (
        <>
          <div className="week-filter" role="group" aria-label="Lab week">
            {labs.map((l) => (
              <button
                aria-pressed={week === l.week}
                key={l.week}
                onClick={() => setWeek(l.week)}
              >
                Week {l.week}
              </button>
            ))}
          </div>
          <div className="lab-layout">
            <div>
              <div className="lab-intro">
                <span className="eyeline">Week {week} · guided practice</span>
                <h2>{lab.title}</h2>
                <p>
                  <b>Prerequisites:</b> {lab.prerequisites}
                </p>
                <h3>Your objectives</h3>
                <ul>
                  {lab.objectives.map((o) => (
                    <li key={o}>{o}</li>
                  ))}
                </ul>
                <div className="source-note">
                  <Info size={17} />
                  <p>
                    Cloud setup steps are real hands-on instructions. Embedded
                    playgrounds are labeled <b>Simulated Practice</b>. A
                    completion check records your own verification; it does not
                    claim we inspected your cloud account.
                  </p>
                </div>
              </div>
              <div className="lab-steps">
                {lab.steps.map((s, i) => {
                  const checked = progress.labSteps.includes(`${week}-${i}`);
                  return (
                    <section
                      className={`lab-step ${checked ? "checked" : ""}`}
                      key={`${week}-${i}`}
                    >
                      <div className="lab-step-header">
                        <span className="lab-step-num">
                          {checked ? <Check size={18} /> : i + 1}
                        </span>
                        <div>
                          <h3>{s.title}</h3>
                          <span>
                            {s.tool}
                            {s.optional ? " · Optional" : ""}
                          </span>
                        </div>
                        <input
                          type="checkbox"
                          aria-label={`Complete ${s.title}`}
                          checked={checked}
                          onChange={() =>
                            update((p) => ({
                              ...p,
                              labSteps: checked
                                ? p.labSteps.filter((x) => x !== `${week}-${i}`)
                                : [...p.labSteps, `${week}-${i}`],
                            }))
                          }
                        />
                      </div>
                      <p>{s.instruction}</p>
                      {s.code && (
                        <CodeBlock
                          code={s.code}
                          label={s.tool || "Lab command"}
                        />
                      )}
                      <div className="expected-output">
                        <b>What to expect</b>
                        <p>{s.expected}</p>
                      </div>
                      <details>
                        <summary>Need a hint?</summary>
                        <p>{s.hint}</p>
                      </details>
                      <details>
                        <summary>Common error & how to fix it</summary>
                        <p>{s.error}</p>
                      </details>
                      {s.tool && tools.includes(s.tool) && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openTool(s.tool)}
                        >
                          Open local {s.tool} practice <ArrowRight size={14} />
                        </Button>
                      )}
                    </section>
                  );
                })}
              </div>
              <div className="lesson-complete">
                <span>
                  <strong>
                    {done} of {lab.steps.length} steps checked
                  </strong>
                  <small>
                    {done === lab.steps.length
                      ? "Lab checklist complete. Review your deliverables with your tutor."
                      : "Check each step only after you verify the stated result."}
                  </small>
                </span>
                <Link href={`/quiz/?week=${week}`} className="btn btn-primary">
                  Check your learning <ArrowRight size={15} />
                </Link>
              </div>
            </div>
            <aside className="week-side">
              <div className="tonal-panel">
                <span className="eyeline">Your checklist</span>
                <h2>{Math.round((done / lab.steps.length) * 100)}% complete</h2>
                <div className="progress-track">
                  <div
                    style={{ width: `${(done / lab.steps.length) * 100}%` }}
                  />
                </div>
                <p>
                  {lab.steps.length} steps ·{" "}
                  {lab.steps.filter((s) => s.optional).length} optional
                </p>
                <Button onClick={() => openTool()} variant="outline">
                  Open playground <Terminal size={15} />
                </Button>
              </div>
              <div className="tonal-panel">
                <h3>Original instructions</h3>
                <p>
                  All the original guide text and uploaded files are accessible
                  in Course Sources.
                </p>
                <a
                  className="text-link"
                  href={assetPath(`/sources/IT8417_Week0${week}_Lab_Guide.docx`)}
                  download
                >
                  <Download size={15} />
                  Download original guide
                </a>
                <Link href={`/sources/?week=${week}`} className="text-link">
                  Read source & coverage map <ArrowRight size={14} />
                </Link>
              </div>
            </aside>
          </div>
        </>
      ) : (
        <div>
          <div className="tool-picker">
            <label htmlFor="practice-tool">Choose a playground</label>
            <select
              id="practice-tool"
              value={tool}
              onChange={(e) => setTool(e.target.value)}
            >
              {tools.map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
          </div>
          {tool === "SQL" ? (
            <SQLPlayground />
          ) : tool === "MongoDB" ? (
            <MongoPlayground />
          ) : tool === "Redis" ? (
            <RedisPlayground />
          ) : tool === "JOIN" ? (
            <JoinVisualizer />
          ) : tool === "ETL" ? (
            <ETLSimulator />
          ) : tool === "Star schema" ? (
            <StarExplorer />
          ) : tool === "Storage comparison" ? (
            <StorageComparison />
          ) : tool === "SCD explorer" ? (
            <SCDExplorer />
          ) : tool === "Cache" ? (
            <CacheSimulator />
          ) : (
            <ModelComparison />
          )}
        </div>
      )}
    </div>
  );
}
