"use client";
import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  ArrowRight,
  ArrowDown,
  Check,
  RotateCcw,
  Play,
  Database,
  ChevronRight,
  MousePointer2,
  Clock3,
} from "lucide-react";
import { Button } from "./ui/button";
import { DataTable, MongoPlayground, RedisPlayground } from "./playgrounds";
import type { Lesson } from "@/lib/types";
const authors = [
  { id: 1, name: "Ada Lovelace" },
  { id: 2, name: "Grace Hopper" },
];
const books = [
  { id: 1, title: "Analytical Engine", author_id: 1 },
  { id: 2, title: "First Program", author_id: 1 },
  { id: 3, title: "A-0 Compiler", author_id: 2 },
  { id: 4, title: "Unassigned book", author_id: null },
];
export function JoinVisualizer() {
  const [join, setJoin] = useState<"INNER" | "LEFT">("INNER"),
    [step, setStep] = useState(-1),
    [showUnmatched, setShowUnmatched] = useState(true);
  const source = showUnmatched ? books : books.slice(0, 3);
  const selected = source[step];
  const match = authors.find((a) => a.id === selected?.author_id);
  const result = source
    .filter(
      (b, i) =>
        (step === -1 || i <= step) && (join === "LEFT" || b.author_id !== null),
    )
    .map((b) => ({
      book: b.title,
      author: authors.find((a) => a.id === b.author_id)?.name ?? null,
    }));
  return (
    <div className="visual-panel">
      <div className="visual-heading">
        <div>
          <h3>Follow the match</h3>
          <p>books.author_id → authors.id</p>
        </div>
        <div className="segmented">
          {(["INNER", "LEFT"] as const).map((x) => (
            <button
              aria-pressed={join === x}
              onClick={() => setJoin(x)}
              key={x}
            >
              {x} JOIN
            </button>
          ))}
        </div>
      </div>
      <div className="join-grid">
        <div>
          <h4>
            books <small>Click a row</small>
          </h4>
          <div className="mini-table">
            <div className="mini-row header">
              <span>title</span>
              <span>author_id</span>
            </div>
            {source.map((b, i) => (
              <button
                onClick={() => setStep(i)}
                key={b.id}
                className={`mini-row ${step === i ? "matching-row" : ""}`}
              >
                <span>{b.title}</span>
                <span>{b.author_id ?? "NULL"}</span>
              </button>
            ))}
          </div>
        </div>
        <div className="join-arrow">
          <ArrowRight />
          <code>ON</code>
        </div>
        <div>
          <h4>authors</h4>
          <div className="mini-table">
            <div className="mini-row header">
              <span>id</span>
              <span>name</span>
            </div>
            {authors.map((a) => (
              <div
                key={a.id}
                className={`mini-row ${match?.id === a.id ? "matching-row" : ""}`}
              >
                <span>{a.id}</span>
                <span>{a.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
      <div className="visual-controls">
        <label className="checkbox-label">
          <input
            type="checkbox"
            checked={showUnmatched}
            onChange={(e) => {
              setShowUnmatched(e.target.checked);
              setStep(-1);
            }}
          />{" "}
          Include an unmatched book
        </label>
        <Button
          variant="outline"
          size="sm"
          onClick={() => setStep((n) => (n >= source.length - 1 ? -1 : n + 1))}
        >
          <Play size={14} />
          {step === -1 ? "Step through rows" : "Next row"}
        </Button>
        <Button variant="ghost" size="sm" onClick={() => setStep(-1)}>
          Show all
        </Button>
      </div>
      <p className="visual-explanation" aria-live="polite">
        {selected
          ? match
            ? `${selected.title} has author_id ${selected.author_id}. It matches ${match.name}.`
            : `No author matches NULL. ${join === "LEFT" ? "LEFT JOIN keeps the book and returns NULL for the author." : "INNER JOIN leaves this book out."}`
          : `${join === "INNER" ? "Only matching pairs appear." : "Every book stays, even with no matching author."} ${result.length} output rows.`}
      </p>
      <motion.div
        key={`${join}-${step}-${showUnmatched}`}
        initial={{ opacity: 0.5, y: 4 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <DataTable
          rows={result}
          caption="Joined result · small teaching dataset"
        />
      </motion.div>
    </div>
  );
}
const raw = [
  { rental_id: "500", amount: "4.99", rental_date: "2026-03-01" },
  { rental_id: "501", amount: "2.99", rental_date: "2026-03-01" },
  { rental_id: "502", amount: "oops", rental_date: "2026-04-02" },
];
export function ETLSimulator() {
  const [stage, setStage] = useState(0),
    [value, setValue] = useState("oops"),
    [message, setMessage] = useState(""),
    [output, setOutput] = useState<any[]>([]);
  const data = raw.map((r, i) => (i === 2 ? { ...r, amount: value } : r));
  function next() {
    if (stage === 0) {
      setOutput(data);
      setStage(1);
      setMessage(
        "Extracted three source rows into bronze. The source remains unchanged.",
      );
    } else if (stage === 1) {
      if (!Number.isFinite(Number(value)) || !value.trim()) {
        setMessage(
          "Transform blocked: amount “" +
            value +
            "” cannot be cast to a number. Correct the raw value; no row was silently dropped.",
        );
        return;
      }
      setOutput(
        data.map((r) => ({
          ...r,
          rental_id: Number(r.rental_id),
          amount: Number(r.amount),
        })),
      );
      setStage(2);
      setMessage(
        "Silver: IDs and amounts are numeric. Input=3, output=3; validation passed.",
      );
    } else if (stage === 2) {
      setOutput(
        data.map((r, i) => ({
          rental_id: Number(r.rental_id),
          date_id: i < 2 ? 1 : 2,
          amount: Number(r.amount),
        })),
      );
      setStage(3);
      setMessage(
        "Gold: each rental now has a reusable date key. Three events remain at rental grain.",
      );
    }
  }
  return (
    <div className="visual-panel">
      <div className="simulation-label">
        <Database size={15} />
        <b>Simulated Practice</b>
        <span>Three teaching rows · not the real CSV archive</span>
      </div>
      <h3>A pipeline with a quality gate</h3>
      <div className="pipeline">
        {[
          "Source",
          "Bronze · Extract",
          "Silver · Transform",
          "Gold · Load",
        ].map((s, i) => (
          <div key={s} className={stage >= i ? "reached" : ""}>
            <span>
              {i === 0 ? (
                <Database size={18} />
              ) : stage > i ? (
                <Check size={18} />
              ) : (
                i
              )}
            </span>
            <b>{s}</b>
            {i < 3 && <ArrowRight className="pipe-arrow" size={18} />}
          </div>
        ))}
      </div>
      {stage <= 1 && (
        <label className="inline-edit">
          Raw amount for rental 502
          <input
            aria-label="Raw amount for rental 502"
            value={value}
            onChange={(e) => setValue(e.target.value)}
          />
          <small>
            Repair the intentionally invalid “oops” before Transform.
          </small>
        </label>
      )}
      <DataTable rows={stage === 0 ? data : output} />
      <div className="visual-controls">
        <Button onClick={next} disabled={stage === 3}>
          <Play size={15} />
          {
            [
              "Extract rows",
              "Validate & transform",
              "Load the star",
              "Pipeline complete",
            ][stage]
          }
        </Button>
        <Button
          variant="ghost"
          onClick={() => {
            setStage(0);
            setOutput([]);
            setValue("oops");
            setMessage("");
          }}
        >
          <RotateCcw size={14} />
          Reset
        </Button>
      </div>
      <p aria-live="polite" className="visual-explanation">
        {message ||
          "Move the data through each stage. Check types and row counts, not only table names."}
      </p>
    </div>
  );
}
const starData: Record<
  string,
  { key: string; description: string; rows: Record<string, any>[] }
> = {
  dim_date: {
    key: "date_id",
    description:
      "When: one row per rental day. Calendar fields are defined once.",
    rows: [
      { date_id: 1, full_date: "2026-03-01", year: 2026, month: 3 },
      { date_id: 2, full_date: "2026-04-02", year: 2026, month: 4 },
    ],
  },
  dim_film: {
    key: "film_id",
    description:
      "What: one descriptive film row. Film ID was resolved through inventory during Load.",
    rows: [
      { film_id: 25, title: "Cloud Journey", rental_rate: 4.99 },
      { film_id: 44, title: "Data Stories", rental_rate: 2.99 },
    ],
  },
  dim_customer: {
    key: "customer_id",
    description:
      "Who rented: current descriptive data in this Type 1 model. Type 2 requires version keys.",
    rows: [
      { customer_id: 1, first_name: "Mary", last_name: "Smith" },
      { customer_id: 2, first_name: "Ahmed", last_name: "Ali" },
    ],
  },
  dim_staff: {
    key: "staff_id",
    description: "Who handled it: staff names kept apart from event amounts.",
    rows: [
      { staff_id: 1, first_name: "Mariam", last_name: "Hasan" },
      { staff_id: 2, first_name: "Omar", last_name: "Khalid" },
    ],
  },
  fact_rental: {
    key: "rental_id",
    description:
      "Grain: one rental event. Keys describe context; amount is the paid revenue measure.",
    rows: [
      {
        rental_id: 500,
        film_id: 25,
        customer_id: 1,
        staff_id: 1,
        date_id: 1,
        amount: 4.99,
      },
      {
        rental_id: 501,
        film_id: 44,
        customer_id: 2,
        staff_id: 2,
        date_id: 1,
        amount: 2.99,
      },
      {
        rental_id: 502,
        film_id: 25,
        customer_id: 1,
        staff_id: 1,
        date_id: 2,
        amount: null,
      },
    ],
  },
};
export function StarExplorer() {
  const [selected, setSelected] = useState("fact_rental");
  return (
    <div className="visual-panel">
      <div className="visual-heading">
        <div>
          <h3>Explore the rental star</h3>
          <p>Choose a table to inspect its role and rows.</p>
        </div>
        <MousePointer2 size={18} />
      </div>
      <div className="star-schema">
        {Object.entries(starData).map(([name, d]) => (
          <button
            key={name}
            className={`star-node ${name} ${selected === name ? "chosen" : ""}`}
            onClick={() => setSelected(name)}
            aria-pressed={selected === name}
          >
            <Database size={17} />
            <b>{name}</b>
            <small>
              {name === "fact_rental"
                ? "Measures + dimension keys"
                : `${d.key} · descriptive context`}
            </small>
          </button>
        ))}
        <div className="star-lines" aria-hidden="true">
          <span />
          <span />
        </div>
      </div>
      <p className="visual-explanation">
        <b>{selected}</b> · {starData[selected].description}
      </p>
      <DataTable
        rows={starData[selected].rows}
        caption="Illustrative rows, not full dvdrental output"
      />
    </div>
  );
}
export function StorageComparison() {
  const [columns, setColumns] = useState(2),
    [mode, setMode] = useState<"sum" | "row">("sum");
  const total = 36,
    rowRead = mode === "sum" ? total : 12,
    colRead = mode === "sum" ? columns * 3 : 12;
  return (
    <div className="visual-panel">
      <h3>Same data. Different reading patterns.</h3>
      <div className="visual-controls">
        <div className="segmented">
          <button aria-pressed={mode === "sum"} onClick={() => setMode("sum")}>
            Aggregate columns
          </button>
          <button aria-pressed={mode === "row"} onClick={() => setMode("row")}>
            Read one full row
          </button>
        </div>
        {mode === "sum" && (
          <label>
            Columns needed: {columns} of 12
            <input
              aria-label="Columns needed"
              type="range"
              min={1}
              max={12}
              value={columns}
              onChange={(e) => setColumns(+e.target.value)}
            />
          </label>
        )}
      </div>
      <div className="storage-grid">
        {["Row layout", "Column layout"].map((title, t) => (
          <div key={title}>
            <h4>
              {title}
              <span>{t ? colRead : rowRead} / 36 cells read</span>
            </h4>
            <div className={`storage-cells ${t ? "columns" : ""}`}>
              {Array.from({ length: 36 }, (_, i) => {
                const row = t ? i % 3 : Math.floor(i / 12),
                  col = t ? Math.floor(i / 3) : i % 12;
                const active =
                  mode === "row" ? row === 0 : t ? col < columns : true;
                return (
                  <motion.div
                    key={i}
                    animate={{ opacity: 1 }}
                    className={active ? "read" : ""}
                  >
                    {col === 0
                      ? row + 1
                      : col === 1
                        ? ["4.99", "2.99", "4.99"][row]
                        : `c${col + 1}`}
                  </motion.div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
      <p className="visual-explanation">
        {mode === "sum"
          ? `In this simplified full-scan model, column projection reads ${colRead} values instead of 36. Actual I/O depends on row groups, indexes, compression and the query engine.`
          : "Reading a full row needs all 12 values in both layouts. A row-oriented system keeps that record together; it often suits transactional access."}
      </p>
    </div>
  );
}
export function SCDExplorer() {
  const [type, setType] = useState(1),
    [changed, setChanged] = useState(false);
  const rows =
    type === 2 && changed
      ? [
          {
            customer_key: 501,
            customer_id: 1042,
            city: "Manama",
            valid_from: "2023-01-10",
            valid_to: "2026-04-01",
            current: false,
          },
          {
            customer_key: 877,
            customer_id: 1042,
            city: "Riffa",
            valid_from: "2026-04-01",
            valid_to: null,
            current: true,
          },
        ]
      : [
          {
            customer_id: 1042,
            city: changed ? "Riffa" : "Manama",
            ...(type === 3 ? { previous_city: changed ? "Manama" : null } : {}),
          },
        ];
  return (
    <div className="visual-panel">
      <h3>A customer moves from Manama to Riffa</h3>
      <div className="visual-controls">
        <div className="segmented">
          {[1, 2, 3].map((n) => (
            <button
              key={n}
              aria-pressed={type === n}
              onClick={() => setType(n)}
            >
              Type {n}
            </button>
          ))}
        </div>
        <Button onClick={() => setChanged(!changed)} variant="outline">
          {changed ? "Undo move" : "Apply move on 1 Apr 2026"}
        </Button>
      </div>
      <DataTable rows={rows} />
      <div className="history-result">
        <span>Historical rental · 15 Mar 2026</span>
        <strong>
          {!changed
            ? "Manama"
            : type === 1
              ? "Riffa"
              : type === 2
                ? "Manama"
                : "Manama (previous_city)"}
        </strong>
        <p>
          {type === 1
            ? "Type 1 points old facts at current attributes."
            : type === 2
              ? "Type 2 uses [valid_from, valid_to) and a version key."
              : "Type 3 retains a limited previous value; it is not an unlimited dated history."}
        </p>
      </div>
    </div>
  );
}
const modelInfo: Record<
  string,
  { model: string; use: string; avoid: string; example: string }
> = {
  PostgreSQL: {
    model: "Relational",
    use: "Structured transactions, constraints and relationships.",
    avoid:
      "Using the live transaction system for every expensive historical scan.",
    example: "Student records, loans and rental transactions.",
  },
  Databricks: {
    model: "Lakehouse / analytical warehouse",
    use: "ETL, large historical scans, columnar analytical tables.",
    avoid:
      "Treating an analytical warehouse as the first choice for every single-key session lookup.",
    example: "Monthly rental revenue across years.",
  },
  MongoDB: {
    model: "Document",
    use: "Flexible nested records designed around common reads.",
    avoid:
      "Unbounded arrays and ignoring validation or transaction requirements.",
    example: "A product catalog with varying specifications.",
  },
  Redis: {
    model: "Key-value structures",
    use: "Hot data, caches, counters, sessions and expiry.",
    avoid: "Assuming it replaces all reporting and durable financial storage.",
    example: "An expiring login code or a leaderboard.",
  },
};
export function ModelComparison() {
  const [selected, setSelected] = useState("PostgreSQL");
  return (
    <div className="visual-panel">
      <h3>Choose by the job, not the hype</h3>
      <div className="model-tabs">
        {Object.keys(modelInfo).map((k) => (
          <button
            key={k}
            aria-pressed={selected === k}
            onClick={() => setSelected(k)}
          >
            {k}
          </button>
        ))}
      </div>
      <div className="model-detail">
        <span className="muted">{modelInfo[selected].model}</span>
        <h4>{modelInfo[selected].example}</h4>
        <p>
          <b>A good fit:</b> {modelInfo[selected].use}
        </p>
        <p>
          <b>A common mistake:</b> {modelInfo[selected].avoid}
        </p>
      </div>
      <p className="muted">
        One application can use several: PostgreSQL records rentals → Databricks
        analyzes history; MongoDB models flexible documents; Redis caches
        frequent lookups.
      </p>
    </div>
  );
}
export function CacheSimulator() {
  const [cache, setCache] = useState<{ value: number; expiry: number } | null>(
      null,
    ),
    [source, setSource] = useState(12),
    [hits, setHits] = useState(0),
    [misses, setMisses] = useState(0),
    [ratio, setRatio] = useState(95),
    [message, setMessage] = useState(
      "Read a product price to follow the cache-aside path.",
    ),
    [now, setNow] = useState(Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 250);
    return () => clearInterval(t);
  }, []);
  const valid = cache && cache.expiry > now;
  function lookup() {
    if (cache && cache.expiry > Date.now()) {
      setHits((h) => h + 1);
      setMessage(
        `HIT → return cached ${cache.value.toFixed(2)}. Source database was not read.`,
      );
    } else {
      setMisses((m) => m + 1);
      setCache({ value: source, expiry: Date.now() + 10000 });
      setMessage(
        `MISS → read source ${source.toFixed(2)} → fill cache with 10-second TTL → return.`,
      );
    }
  }
  return (
    <div className="visual-panel">
      <div className="simulation-label">
        <Database size={15} />
        <b>Simulated Practice</b>
        <span>Illustrative timing model, not a benchmark</span>
      </div>
      <h3>Watch cache-aside in action</h3>
      <div className="cache-flow">
        <div>
          <small>Application</small>
          <Button onClick={lookup} variant="outline">
            Read product price <ArrowRight size={14} />
          </Button>
        </div>
        <ArrowRight />
        <div className={valid ? "cache-valid" : ""}>
          <small>Redis cache</small>
          <strong>{valid ? cache.value.toFixed(2) : "Empty"}</strong>
          <span>
            {valid
              ? `${((cache.expiry - now) / 1000).toFixed(1)}s left`
              : "Next read is a miss"}
          </span>
        </div>
        <ArrowRight />
        <div>
          <small>Source of truth</small>
          <strong>{source.toFixed(2)}</strong>
          <button
            onClick={() => {
              setSource((v) => v + 1);
              setMessage(
                "Source price changed. The cached copy may now be stale until invalidation or expiry.",
              );
            }}
          >
            Change source price +1
          </button>
        </div>
      </div>
      <div className="visual-controls">
        <span>
          {hits} hits · {misses} misses ·{" "}
          {hits + misses ? Math.round((hits / (hits + misses)) * 100) : 0}%
          observed hit ratio
        </span>
        <Button
          variant="ghost"
          onClick={() => {
            setCache(null);
            setMessage(
              "Cached copy invalidated. The next read fetches the current source price.",
            );
          }}
        >
          Invalidate cache
        </Button>
      </div>
      <p className="visual-explanation" aria-live="polite">
        {message}
      </p>
      <div className="cache-calculator">
        <label>
          Assumed hit ratio <b>{ratio}%</b>
          <input
            type="range"
            min={0}
            max={100}
            value={ratio}
            onChange={(e) => setRatio(+e.target.value)}
          />
        </label>
        <div>
          <strong>
            {((ratio / 100) * 0.5 + (1 - ratio / 100) * 4).toFixed(3)}{" "}
            <small>ms average</small>
          </strong>
          <p>hit 0.5 ms · miss = look 0.5 + DB 3 + fill 0.5 = 4 ms</p>
        </div>
      </div>
    </div>
  );
}
export function Visualization({ kind }: { kind: Lesson["visual"] }) {
  switch (kind) {
    case "join":
      return <JoinVisualizer />;
    case "etl":
      return <ETLSimulator />;
    case "star":
      return <StarExplorer />;
    case "storage":
      return <StorageComparison />;
    case "mongo":
      return <MongoPlayground />;
    case "redis":
      return <RedisPlayground />;
    case "scd":
      return <SCDExplorer />;
    case "cache":
      return <CacheSimulator />;
    case "models":
      return <ModelComparison />;
    default:
      return null;
  }
}
