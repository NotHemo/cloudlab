"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import {
  RotateCcw,
  Shuffle,
  Check,
  ArrowLeft,
  ArrowRight,
  FlipHorizontal,
  BookOpen,
} from "lucide-react";
import { motion } from "motion/react";
import { lessons } from "@/content/course";
import { shuffle } from "@/lib/utils";
import { useProgress } from "./progress-provider";
import { Button } from "./ui/button";
import { CodeBlock } from "./code-block";
export const flashcards = lessons.flatMap((l) =>
  l.concepts.map((c, i) => ({
    id: `${l.id}:${i}`,
    week: l.week,
    lessonId: l.id,
    ...c,
  })),
);
export function FlashcardWorkspace() {
  const { progress, update } = useProgress();
  const [week, setWeek] = useState("0"),
    [filter, setFilter] = useState("all"),
    [order, setOrder] = useState<string[]>([]),
    [index, setIndex] = useState(0),
    [flipped, setFlipped] = useState(false);
  const pool = flashcards.filter(
    (c) =>
      (week === "0" || c.week === +week) &&
      (filter === "all" ||
        (filter === "practice" && progress.mastery[c.id] === "practice") ||
        (filter === "unseen" && !progress.mastery[c.id])),
  );
  const cards = order.length
    ? [...pool].sort((a, b) => order.indexOf(a.id) - order.indexOf(b.id))
    : pool;
  const card = cards[index % Math.max(1, cards.length)];
  function move(n: number) {
    setFlipped(false);
    setIndex(
      (i) => (i + n + Math.max(1, cards.length)) % Math.max(1, cards.length),
    );
  }
  function mark(value: "know" | "practice") {
    if (!card) return;
    update((p) => ({ ...p, mastery: { ...p.mastery, [card.id]: value } }));
    if (filter === "all") move(1);
    else {
      setFlipped(false);
      setIndex(0);
    }
  }
  useEffect(() => {
    function key(e: KeyboardEvent) {
      if ((e.target as HTMLElement)?.closest("input,textarea,select,button,a"))
        return;
      if (e.code === "Space") {
        e.preventDefault();
        setFlipped((f) => !f);
      }
      if (e.key === "ArrowRight") move(1);
      if (e.key === "ArrowLeft") move(-1);
    }
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, [cards.length]);
  const scope = flashcards.filter((c) => week === "0" || c.week === +week),
    known = scope.filter((c) => progress.mastery[c.id] === "know").length;
  return (
    <div className="page flashcard-page">
      <div className="page-heading">
        <div>
          <span className="eyeline">A small habit, a stronger memory</span>
          <h1>Make the ideas stick.</h1>
          <p>Say the answer out loud, then flip the card to check yourself.</p>
        </div>
        <span className="module-count">
          {known}/{scope.length}
          <small>marked “Know”</small>
        </span>
      </div>
      <div className="flashcard-controls">
        <label>
          Week
          <select
            value={week}
            onChange={(e) => {
              setWeek(e.target.value);
              setIndex(0);
              setFlipped(false);
            }}
          >
            <option value="0">All weeks</option>
            {[1, 2, 3, 4, 5, 6].map((w) => (
              <option key={w} value={w}>
                Week {w}
              </option>
            ))}
          </select>
        </label>
        <label>
          Deck
          <select
            value={filter}
            onChange={(e) => {
              setFilter(e.target.value);
              setIndex(0);
              setFlipped(false);
            }}
          >
            <option value="all">All concepts</option>
            <option value="practice">Need practice</option>
            <option value="unseen">Not reviewed yet</option>
          </select>
        </label>
        <Button
          variant="outline"
          onClick={() => {
            setOrder(shuffle(pool.map((c) => c.id)));
            setIndex(0);
            setFlipped(false);
          }}
        >
          <Shuffle size={15} />
          Shuffle
        </Button>
      </div>
      <div className="progress-track">
        <div style={{ width: `${(known / scope.length) * 100}%` }} />
      </div>
      {card ? (
        <>
          <div className="flash-position">
            {(index % cards.length) + 1} of {cards.length} cards · Week{" "}
            {card.week}
            <span>
              {progress.mastery[card.id] === "know"
                ? "Know"
                : progress.mastery[card.id] === "practice"
                  ? "Need practice"
                  : "Not reviewed"}
            </span>
          </div>
          <motion.div
            key={card.id + (flipped ? "back" : "front")}
            initial={{ opacity: 0.5, rotateX: flipped ? -5 : 5 }}
            animate={{ opacity: 1, rotateX: 0 }}
            className="flashcard"
          >
            <button
              className="flashcard-flip-area"
              onClick={() => setFlipped(!flipped)}
              aria-label={flipped ? "Show term" : "Flip card to reveal answer"}
            >
              <span className="eyeline">
                {flipped ? "The idea in simple words" : "Can you explain this?"}
              </span>
              <h2>{card.term}</h2>
              {flipped ? (
                <p>{card.explanation}</p>
              ) : (
                <span className="flip-prompt">
                  <FlipHorizontal size={19} />
                  Click to reveal · Space to flip
                </span>
              )}
            </button>
            {flipped && (
              <div className="flashcard-back">
                <p>
                  <b>Why it matters:</b> {card.why}
                </p>
                <p>
                  <b>Think of:</b> {card.analogy}
                </p>
                {card.code && (
                  <details>
                    <summary>See the command example</summary>
                    <CodeBlock code={card.code} />
                  </details>
                )}
                <Link className="text-link" href={`/lesson/${card.lessonId}/`}>
                  Open the related lesson <ArrowRight size={14} />
                </Link>
              </div>
            )}
          </motion.div>
          <div className="flashcard-actions">
            <Button
              variant="ghost"
              aria-label="Previous flashcard"
              onClick={() => move(-1)}
            >
              <ArrowLeft size={18} />
            </Button>
            <Button variant="outline" onClick={() => mark("practice")}>
              <RotateCcw size={16} />
              Need practice
            </Button>
            <Button onClick={() => mark("know")}>
              <Check size={17} />
              Know this
            </Button>
            <Button
              variant="ghost"
              aria-label="Next flashcard"
              onClick={() => move(1)}
            >
              <ArrowRight size={18} />
            </Button>
          </div>
          <p className="center muted">
            Mastery is your self-assessment. Quizzes help check it against
            actual answers.
          </p>
        </>
      ) : (
        <div className="empty-state">
          <Check size={30} />
          <h2>No cards in this deck</h2>
          <p>
            Choose all concepts or mark a card as “Need practice” to build this
            deck.
          </p>
          <Button onClick={() => setFilter("all")}>Show all concepts</Button>
        </div>
      )}
    </div>
  );
}
