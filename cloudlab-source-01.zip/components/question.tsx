"use client";
import { useState, useMemo } from "react";
import Link from "next/link";
import { CheckCircle2, XCircle, ArrowRight } from "lucide-react";
import { Question } from "@/lib/types";
import { isCorrect } from "@/content/questions";
import { Button } from "./ui/button";
import { CodeBlock } from "./code-block";
import { useProgress } from "./progress-provider";
export function QuestionCard({
  question: q,
  exam = false,
  onAnswer,
  stored,
  number,
}: {
  question: Question;
  exam?: boolean;
  onAnswer?: (answer: string) => void;
  stored?: string;
  number?: number;
}) {
  const { update } = useProgress();
  const [answer, setAnswer] = useState(stored || ""),
    [submitted, setSubmitted] = useState(false),
    [matches, setMatches] = useState<string[]>(stored?.split("|") || []);
  const stableOrder = (values: string[]) =>
    [...values].sort((a, b) => hash(q.id + a) - hash(q.id + b));
  const options = useMemo(() => stableOrder(q.options || []), [q.id]);
  const defs = useMemo(
    () => stableOrder(q.pairs?.map((p) => p[1]) || []),
    [q.id],
  );
  const chosen = q.pairs ? matches.join("|") : answer;
  const correct = isCorrect(q, chosen);
  function submit() {
    if (!chosen) return;
    setSubmitted(true);
    onAnswer?.(chosen);
    if (!exam)
      update((p) => ({
        ...p,
        answers: { ...p.answers, [q.id]: { correct, answer: chosen } },
      }));
  }
  return (
    <section className="question-card" aria-label="Knowledge check">
      <div className="eyeline">
        {number ? `Question ${number} · ` : ""}
        {q.type}
        <span>{q.difficulty}</span>
      </div>
      <h3>{q.prompt}</h3>
      {q.code && <CodeBlock code={q.code} label="Read the code" />}
      {q.pairs ? (
        <div className="matching">
          {q.pairs.map(([term], i) => (
            <label key={term}>
              {term}
              <select
                aria-label={`Definition for ${term}`}
                value={matches[i] || ""}
                disabled={submitted && !exam}
                onChange={(e) => {
                  const a = [...matches];
                  a[i] = e.target.value;
                  setMatches(a);
                  setSubmitted(false);
                }}
              >
                <option value="">Choose definition</option>
                {defs.map((d) => (
                  <option key={d}>{d}</option>
                ))}
              </select>
            </label>
          ))}
        </div>
      ) : options.length ? (
        <div className="answer-options">
          {options.map((opt, i) => (
            <button
              key={opt}
              className={`answer-option ${answer === opt ? "selected" : ""} ${submitted && !exam && opt === q.answer ? "correct" : ""} ${submitted && !exam && answer === opt && !correct ? "incorrect" : ""}`}
              disabled={submitted && !exam}
              onClick={() => {
                setAnswer(opt);
                setSubmitted(false);
              }}
            >
              <span>{String.fromCharCode(65 + i)}</span>
              {opt}
            </button>
          ))}
        </div>
      ) : (
        <label className="field-label">
          Your answer
          <input
            value={answer}
            disabled={submitted && !exam}
            onChange={(e) => {
              setAnswer(e.target.value);
              setSubmitted(false);
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter") submit();
            }}
            autoComplete="off"
          />
        </label>
      )}
      <Button
        onClick={submit}
        variant={submitted ? "outline" : "default"}
        disabled={
          !chosen ||
          (!!q.pairs && matches.filter(Boolean).length !== q.pairs.length) ||
          (submitted && !exam)
        }
      >
        {exam ? (submitted ? "Answer saved" : "Save answer") : "Check answer"}
      </Button>
      {submitted && !exam && (
        <div
          aria-live="polite"
          className={`feedback ${correct ? "good" : "bad"}`}
        >
          <strong>
            {correct ? <CheckCircle2 size={18} /> : <XCircle size={18} />}{" "}
            {correct
              ? "Correct. You’ve got it."
              : "Not quite. Let’s work it out."}
          </strong>
          <p>{q.explanation}</p>
          {q.wrong && (
            <details>
              <summary>Why the other answers are wrong</summary>
              {Object.entries(q.wrong).map(([option, why]) => (
                <p key={option}>
                  <b>{option}</b> — {why}
                </p>
              ))}
            </details>
          )}
          <Link href={`/lesson/${q.lessonId}/`}>
            Review this lesson <ArrowRight size={14} />
          </Link>
        </div>
      )}
    </section>
  );
}
function hash(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++)
    h = (Math.imul(31, h) + s.charCodeAt(i)) | 0;
  return h >>> 0;
}
