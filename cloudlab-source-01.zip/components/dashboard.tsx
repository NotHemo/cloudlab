"use client";
import Link from "next/link";
import {
  ArrowRight,
  CheckCircle2,
  Clock3,
  Flame,
  FlaskConical,
  Layers,
  MoveUpRight,
  BookOpen,
  Target,
} from "lucide-react";
import { motion } from "motion/react";
import { modules, lessons, lessonById } from "@/content/course";
import { questions } from "@/content/questions";
import { labs } from "@/content/labs";
import { useProgress } from "./progress-provider";
import { studyStreak } from "@/lib/utils";
export function CourseJourney() {
  return (
    <div
      className="course-journey"
      aria-label="Course path: relational data to warehouse, documents and cache"
    >
      <svg
        viewBox="0 0 620 145"
        role="img"
        aria-label="Relational tables flow into a warehouse; documents and cache complement the system"
      >
        <path className="journey-path" d="M85 74H535" />
        <path
          className="journey-path"
          d="m200 70 6 4-6 4m150-8 6 4-6 4m150-8 6 4-6 4"
        />
        <g className="journey-node">
          <rect x="24" y="35" width="112" height="76" rx="10" />
          <path d="M48 56h64M48 69h64M48 82h64M65 56v39M88 56v39" />
        </g>
        <g className="journey-node">
          <rect x="178" y="35" width="112" height="76" rx="10" />
          <path d="m212 56 22-11 22 11-22 11Zm0 14 22 11 22-11m-44 14 22 11 22-11" />
        </g>
        <g className="journey-node">
          <rect x="332" y="35" width="112" height="76" rx="10" />
          <text x="388" y="83" textAnchor="middle" fontSize="30">
            {"{ }"}
          </text>
        </g>
        <g className="journey-node accent">
          <rect x="486" y="35" width="112" height="76" rx="10" />
          <path d="m548 47-22 30h15l-8 24 23-33h-17Z" />
        </g>
        <text x="80" y="134" textAnchor="middle">
          Relational
        </text>
        <text x="234" y="134" textAnchor="middle">
          Warehouse
        </text>
        <text x="388" y="134" textAnchor="middle">
          Documents
        </text>
        <text x="542" y="134" textAnchor="middle">
          Cache
        </text>
      </svg>
    </div>
  );
}
export function Dashboard() {
  const { progress, ready } = useProgress();
  const completed = progress.completed.filter((id) => lessonById(id)).length;
  const percent = Math.round((completed / lessons.length) * 100);
  const current = lessonById(progress.lastLesson) || lessons[0];
  const next = progress.completed.includes(current.id)
    ? lessons.find((l) => !progress.completed.includes(l.id)) || current
    : current;
  const answers = Object.values(progress.answers);
  const score = answers.length
    ? Math.round(
        (answers.filter((a) => a.correct).length / answers.length) * 100,
      )
    : null;
  const weak = [
    ...new Set(
      questions
        .filter(
          (q) => progress.answers[q.id] && !progress.answers[q.id].correct,
        )
        .map((q) => q.lessonId),
    ),
  ];
  const days = studyStreak(progress.days);
  const cards = Object.values(progress.mastery).filter(
    (x) => x === "know",
  ).length;
  const labDone = progress.labSteps.length;
  return (
    <div className="page dashboard">
      <div className="page-heading">
        <div>
          <span className="eyeline">Your learning workspace</span>
          <h1>Make cloud databases click.</h1>
          <p>
            Six weeks. One connected journey. A little understanding at a time.
          </p>
        </div>
        <div className="course-code">
          IT8417<span>Weeks 01—06</span>
        </div>
      </div>
      <div className="dashboard-grid">
        <section className="continue-panel">
          <div className="continue-copy">
            <span className="eyeline">
              {completed
                ? "Pick up where you left off"
                : "Start with the foundations"}
            </span>
            <h2>{next.title}</h2>
            <p>{next.description}</p>
            <Link className="btn btn-primary" href={`/lesson/${next.id}/`}>
              {completed ? "Continue learning" : "Start learning"}
              <ArrowRight size={17} />
            </Link>
            <span className="lesson-meta">
              Week {next.week} <span>·</span> {next.minutes} min <span>·</span>{" "}
              Interactive lesson
            </span>
          </div>
          <CourseJourney />
        </section>
        <section className="progress-panel" aria-label="Course progress">
          <div className="section-heading">
            <h2>Your progress</h2>
            <span>
              {completed}/{lessons.length} lessons
            </span>
          </div>
          <div
            className="progress-circle"
            role="progressbar"
            aria-label="Lessons completed"
            aria-valuenow={percent}
            aria-valuemin={0}
            aria-valuemax={100}
          >
            <svg viewBox="0 0 120 120" aria-hidden="true">
              <circle cx="60" cy="60" r="50" />
              <circle
                className="circle-fill"
                style={{ opacity: percent ? 1 : 0 }}
                cx="60"
                cy="60"
                r="50"
                strokeDasharray={`${(percent / 100) * 314.16} 314.16`}
                transform="rotate(-90 60 60)"
              />
            </svg>
            <div>
              <strong>
                {percent}
                <small>%</small>
              </strong>
              <span>course complete</span>
            </div>
          </div>
          <div className="streak-row">
            <Flame size={17} />
            <b>
              {days} day{days === 1 ? "" : "s"}
            </b>
            <span>study streak</span>
          </div>
          <p className="muted">
            {days
              ? "Keep the momentum. Every lesson counts."
              : "Your first study day starts with an activity."}
          </p>
        </section>
        <section className="learning-path">
          <div className="section-heading">
            <div>
              <h2>Your learning path</h2>
              <p>Build the foundations, then put them to work.</p>
            </div>
            <span className="muted">6 modules</span>
          </div>
          <div className="module-grid">
            {modules.map((m) => {
              const done = m.lessonIds.filter((id) =>
                progress.completed.includes(id),
              ).length;
              const pct = Math.round((done / m.lessonIds.length) * 100);
              return (
                <motion.div
                  key={m.week}
                  whileHover={{ y: -2 }}
                  transition={{ duration: 0.15 }}
                >
                  <Link
                    href={`/week/${m.week}/`}
                    className={`module-card ${m.week === next.week ? "recommended" : ""}`}
                  >
                    <div className="module-card-top">
                      <span>Week {String(m.week).padStart(2, "0")}</span>
                      {done === m.lessonIds.length ? (
                        <span className="status-done">
                          <CheckCircle2 size={13} />
                          Completed
                        </span>
                      ) : done ? (
                        <span className="status-started">In progress</span>
                      ) : m.week === next.week ? (
                        <span className="status-started">Next up</span>
                      ) : (
                        <span>Ready when you are</span>
                      )}
                    </div>
                    <h3>{m.title}</h3>
                    <p>{m.description}</p>
                    <div className="module-platform">{m.platform}</div>
                    <div className="module-card-bottom">
                      <span>{m.lessonIds.length} lessons · 1 guided lab</span>
                      <ArrowRight size={18} />
                    </div>
                    <div className="module-progress-caption">
                      <span>Lesson progress</span>
                      <strong>{pct}%</strong>
                    </div>
                    <div
                      className="progress-track"
                      aria-label={`${pct}% complete`}
                    >
                      <div style={{ width: `${pct}%` }} />
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </section>
        <aside className="study-rail">
          <section className="rail-section">
            <div className="section-heading">
              <h2>Make it stick</h2>
              <Target size={17} />
            </div>
            <Link className="study-action" href="/flashcards/">
              <Layers size={20} />
              <span>
                <strong>Flip a few flashcards</strong>
                <small>{cards} concepts marked “Know”</small>
              </span>
              <Chevron />
            </Link>
            <Link className="study-action" href="/quiz/">
              <BookOpen size={20} />
              <span>
                <strong>Check your understanding</strong>
                <small>
                  {score === null
                    ? "No quiz answers yet"
                    : `${score}% across ${answers.length} answered questions`}
                </small>
              </span>
              <Chevron />
            </Link>
            <Link className="study-action" href="/labs/">
              <FlaskConical size={20} />
              <span>
                <strong>Learn by doing</strong>
                <small>
                  {labDone} of {labs.reduce((n, l) => n + l.steps.length, 0)}{" "}
                  lab steps checked
                </small>
              </span>
              <Chevron />
            </Link>
          </section>
          <section className="rail-section">
            <h2>Needs another look</h2>
            {weak.length ? (
              weak.slice(0, 4).map((id) => (
                <Link className="weak-topic" key={id} href={`/lesson/${id}/`}>
                  {lessonById(id)?.title}
                  <ArrowRight size={14} />
                </Link>
              ))
            ) : (
              <>
                <p className="muted">
                  Your tricky topics will appear here after a knowledge check.
                </p>
                <Link href="/quiz/" className="text-link">
                  Try a short quiz <ArrowRight size={14} />
                </Link>
              </>
            )}
          </section>
          <section className="rail-note">
            <span>One useful idea</span>
            <p>
              “A database model is a choice about how you’ll use your data.”
            </p>
            <Link href="/revision/">
              Compare the four platforms <ArrowRight size={14} />
            </Link>
          </section>
        </aside>
      </div>
      <div className="course-footnote">
        <CheckCircle2 size={15} />
        <span>
          Built from your 6 lecture decks and 6 lab guides. Your progress stays
          in this browser.
        </span>
        <Link href="/sources/">
          Explore the sources <MoveUpRight size={13} />
        </Link>
      </div>
    </div>
  );
}
function Chevron() {
  return <ArrowRight size={15} />;
}
