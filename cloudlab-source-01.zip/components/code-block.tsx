"use client";
import { useState } from "react";
import { Check, Copy } from "lucide-react";
import { Button } from "./ui/button";
import { explainCodeLine } from "@/lib/code-explanations";
const token =
  /((?:--|\/\/|#)[^\n]*|'(?:[^']|'')*'|"(?:[^"\\]|\\.)*"|\b(?:SELECT|FROM|WHERE|JOIN|LEFT|INNER|ON|AS|ORDER|BY|GROUP|CREATE|TABLE|INSERT|INTO|VALUES|UPDATE|SET|DELETE|ALTER|ADD|COLUMN|REFERENCES|PRIMARY|KEY|NOT|NULL|GENERATED|ALWAYS|IDENTITY|INT|TEXT|CAST|TIMESTAMP|DISTINCT|LIMIT|COUNT|SUM|EX|NX|GET|TTL|PING|HSET|ZADD|TRUE|FALSE|USING|PARQUET|DELTA|EXPIRE|KEEPTTL)\b|\$[a-zA-Z_]+|\b\d+(?:\.\d+)?\b)/gi;
export function CodeBlock({
  code,
  label = "Example",
  lines,
}: {
  code: string;
  label?: string;
  lines?: string[];
}) {
  const [copied, setCopied] = useState(false),
    [error, setError] = useState("");
  async function copy() {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      setError("Copy unavailable. Select the code to copy it.");
    }
  }
  return (
    <div className="code-wrap">
      <div className="code-toolbar">
        <span>{label}</span>
        <Button variant="ghost" size="sm" onClick={copy} aria-label="Copy code">
          {copied ? <Check size={14} /> : <Copy size={14} />}{" "}
          {copied ? "Copied" : "Copy"}
        </Button>
      </div>
      <pre tabIndex={0}>
        <code>
          {code.split(token).map((t, i) => (
            <span
              key={i}
              className={
                /^(--|\/\/|#)/.test(t)
                  ? "tok-comment"
                  : /^['"]/.test(t)
                    ? "tok-string"
                    : /^\d/.test(t)
                      ? "tok-number"
                      : i % 2 === 1
                        ? "tok-keyword"
                        : undefined
              }
            >
              {t}
            </span>
          ))}
        </code>
      </pre>
      {error && <p role="status">{error}</p>}
      {lines && (
        <ol className="code-lines">
          {lines.map((x) => (
            <li key={x}>{x}</li>
          ))}
        </ol>
      )}
      <details className="code-walkthrough">
        <summary>Read the code line by line</summary>
        <ol>
          {code.split("\n").map((line, i) =>
            line.trim() ? (
              <li key={i} value={i + 1}>
                <code>{line}</code>
                <p>{explainCodeLine(line)}</p>
              </li>
            ) : null,
          )}
        </ol>
      </details>
    </div>
  );
}
