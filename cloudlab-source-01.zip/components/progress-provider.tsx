"use client";
import { createContext, useContext, useEffect, useState, useRef } from "react";
import type { Progress } from "@/lib/types";
import { localDay } from "@/lib/utils";
import { DEFAULT_THEME, savedTheme } from "@/lib/theme";
const initial: Progress = {
  completed: [],
  labSteps: [],
  bookmarks: [],
  notes: {},
  mastery: {},
  answers: {},
  scores: [],
  days: [],
  lastLesson: "cloud-basics",
  theme: DEFAULT_THEME,
};
const Context = createContext<{
  progress: Progress;
  update: (fn: (p: Progress) => Progress) => void;
  ready: boolean;
  storageError: string;
}>({ progress: initial, update: () => {}, ready: false, storageError: "" });
export function ProgressProvider({ children }: { children: React.ReactNode }) {
  const [progress, setProgress] = useState<Progress>(initial),
    [ready, setReady] = useState(false),
    [storageError, setStorageError] = useState("");
  const changed = useRef(false);
  useEffect(() => {
    try {
      const saved = localStorage.getItem("it8417-progress-v1");
      if (saved) {
        const value = JSON.parse(saved);
        if (
          value &&
          Array.isArray(value.completed) &&
          typeof value.notes === "object"
        ) {
          setProgress({ ...initial, ...value, theme: savedTheme(value) });
        } else
          setStorageError(
            "Saved progress has an invalid format. Export your browser data before clearing it.",
          );
      }
    } catch {
      setStorageError(
        "Saved progress could not be read. It has not been overwritten.",
      );
    }
    setReady(true);
  }, []);
  useEffect(() => {
    if (!ready) return;
    document.documentElement.dataset.theme = progress.theme;
    if (!changed.current) return;
    try {
      localStorage.setItem("it8417-progress-v1", JSON.stringify(progress));
      setStorageError("");
    } catch {
      setStorageError(
        "Your browser could not save progress. Export a backup from My notebook.",
      );
    }
  }, [progress, ready]);
  const update = (fn: (p: Progress) => Progress) => {
    changed.current = true;
    setProgress((p) => {
      const next = fn(p);
      const day = localDay();
      return {
        ...next,
        days: next.days.includes(day) ? next.days : [...next.days, day],
      };
    });
  };
  return (
    <Context.Provider value={{ progress, update, ready, storageError }}>
      {children}
      {storageError && (
        <div role="alert" className="storage-alert">
          {storageError}
        </div>
      )}
    </Context.Provider>
  );
}
export const useProgress = () => useContext(Context);
