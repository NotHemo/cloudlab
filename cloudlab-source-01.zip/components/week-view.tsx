"use client";
import Link from "next/link";
import {
  ArrowRight,
  CheckCircle2,
  Clock3,
  FlaskConical,
  BookOpen,
  ChevronRight,
} from "lucide-react";
import { modules, lessons } from "@/content/course";
import { useProgress } from "./progress-provider";
import { Visualization } from "./visualizations";
export function WeekView({ week }: { week: number }) {
  const module = modules.find((m) => m.week === week)!;
  const items = lessons.filter((l) => l.week === week);
  const { progress } = useProgress();
  const done = items.filter((l) => progress.completed.includes(l.id)).length;
  return (
    <div className="page">
      <div className="route-crumb">
        <Link href="/">My learning</Link>
        <ChevronRight size={14} />
        Week {week}
      </div>
      <div className="page-heading">
        <div>
          <span className="eyeline">
            Week {String(week).padStart(2, "0")} · {module.platform}
          </span>
          <h1>{module.title}</h1>
          <p>{module.description}</p>
        </div>
        <span className="module-count">
          {done} / {items.length}
          <small>lessons complete</small>
        </span>
      </div>
      <div className="progress-track module-progress">
        <div style={{ width: `${(done / items.length) * 100}%` }} />
      </div>
      <div className="week-layout">
        <section>
          <div className="section-heading">
            <h2>Your lessons</h2>
            <span>
              {items.reduce((n, l) => n + l.minutes, 0)} min reading + practice
            </span>
          </div>
          <div className="lesson-list">
            {items.map((l, i) => (
              <Link
                href={`/lesson/${l.id}/`}
                className="lesson-list-row"
                key={l.id}
              >
                <span
                  className={`lesson-index ${progress.completed.includes(l.id) ? "done" : ""}`}
                >
                  {progress.completed.includes(l.id) ? (
                    <CheckCircle2 size={19} />
                  ) : (
                    String(i + 1).padStart(2, "0")
                  )}
                </span>
                <span>
                  <strong>{l.title}</strong>
                  <p>{l.description}</p>
                  <small>
                    {l.concepts.length} topics · {l.minutes} min{" "}
                    {l.visual ? "· Interactive practice" : ""}
                  </small>
                </span>
                <ArrowRight size={18} />
              </Link>
            ))}
          </div>
        </section>
        <aside className="week-side">
          <section className="tonal-panel">
            <FlaskConical size={23} />
            <h2>Put it into practice</h2>
            <p>
              The guided Week {week} lab brings the lecture and original lab
              instructions together.
            </p>
            <Link href={`/labs/?week=${week}`} className="btn btn-primary">
              Open guided lab <ArrowRight size={16} />
            </Link>
          </section>
          <section className="tonal-panel">
            <h3>By the end of this week</h3>
            <ul>
              {items.slice(0, 4).map((l) => (
                <li key={l.id}>{l.takeaways[0]}</li>
              ))}
            </ul>
            <Link className="text-link" href={`/quiz/?week=${week}`}>
              Quiz this week <ArrowRight size={14} />
            </Link>
          </section>
          <Link className="source-link" href={`/sources/?week=${week}`}>
            <BookOpen size={17} />
            Lecture, lab & source map
            <ArrowRight size={14} />
          </Link>
        </aside>
      </div>
    </div>
  );
}
