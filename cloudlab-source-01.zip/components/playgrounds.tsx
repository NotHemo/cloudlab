"use client";
import { assetPath } from "@/lib/asset-path";
import { useEffect, useRef, useState } from "react";
import type { PGlite } from "@electric-sql/pglite";
import { Play, RotateCcw, Terminal, Database, ChevronDown } from "lucide-react";
import { runMongo, mongoSeed, type MongoState } from "@/lib/mongo-engine";
import {
  runRedis,
  redisSeed,
  liveRedis,
  type RedisState,
} from "@/lib/redis-engine";
import { sqlSeed, sqlExamples } from "@/lib/sql-seed";
import { Button } from "./ui/button";
export function DataTable({
  rows,
  caption,
}: {
  rows: Record<string, any>[];
  caption?: string;
}) {
  const cols = [...new Set(rows.flatMap((r) => Object.keys(r)))];
  return (
    <div className="table-scroll">
      {caption && <p className="table-caption">{caption}</p>}
      {rows.length ? (
        <table>
          <thead>
            <tr>
              {cols.map((c) => (
                <th key={c}>{c}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.slice(0, 100).map((r, i) => (
              <tr key={i}>
                {cols.map((c) => (
                  <td key={c} className={typeof r[c] === "number" ? "num" : ""}>
                    {r[c] === null ? (
                      <span className="null">NULL</span>
                    ) : typeof r[c] === "object" ? (
                      JSON.stringify(r[c])
                    ) : (
                      String(r[c] ?? "")
                    )}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p className="empty-inline">No rows returned.</p>
      )}
      {rows.length > 100 && (
        <p>Showing the first 100 of {rows.length} returned rows.</p>
      )}
    </div>
  );
}
export function SQLPlayground() {
  const db = useRef<PGlite | null>(null);
  const [ready, setReady] = useState(false),
    [busy, setBusy] = useState(false),
    [code, setCode] = useState(sqlExamples[0].code),
    [error, setError] = useState(""),
    [results, setResults] = useState<
      { rows: Record<string, any>[]; affectedRows?: number }[]
    >([]),
    [tables, setTables] = useState<string[]>([]),
    [initKey, setInitKey] = useState(0);
  useEffect(() => {
    let cancelled = false;
    let instance: PGlite;
    setReady(false);
    setError("");
    (async () => {
      try {
        const { PGlite } = await import("@electric-sql/pglite");
        instance = new PGlite({
          pgliteWasmModule: await WebAssembly.compileStreaming(
            fetch(assetPath("/engine/pglite.wasm")),
          ),
          initdbWasmModule: await WebAssembly.compileStreaming(
            fetch(assetPath("/engine/initdb.wasm")),
          ),
          fsBundle: await (await fetch(assetPath("/engine/pglite.data"))).blob(),
        });
        await instance.waitReady;
        await instance.exec(sqlSeed);
        if (cancelled) {
          await instance.close();
          return;
        }
        db.current = instance;
        setTables(
          (
            await instance.query<{ table_name: string }>(
              "SELECT table_name FROM information_schema.tables WHERE table_schema='public' ORDER BY table_name",
            )
          ).rows.map((r) => r.table_name),
        );
        setReady(true);
      } catch (e) {
        if (!cancelled)
          setError(
            `Could not start browser PostgreSQL: ${(e as Error).message}`,
          );
      }
    })();
    return () => {
      cancelled = true;
      const old = instance;
      if (old) old.waitReady.then(() => old.close()).catch(() => {});
      db.current = null;
    };
  }, [initKey]);
  async function run() {
    if (!db.current) return;
    setBusy(true);
    setError("");
    try {
      const res = await db.current.exec(code);
      setResults(res);
      const t = await db.current.query<{ table_name: string }>(
        "SELECT table_name FROM information_schema.tables WHERE table_schema='public' ORDER BY table_name",
      );
      setTables(t.rows.map((r) => r.table_name));
    } catch (e) {
      setResults([]);
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="playground">
      <div className="simulation-label">
        <Terminal size={15} />
        <b>Simulated Practice</b>
        <span>Real PostgreSQL · in this browser only</span>
      </div>
      <p className="muted">
        A small teaching dataset, separate from your Supabase project and the
        full dvdrental archive. Changes reset when this practice component
        closes. Databricks syntax such as DESCRIBE DETAIL is not PostgreSQL.
      </p>
      <div className="editor-toolbar">
        <label>
          Example
          <select
            aria-label="SQL example"
            onChange={(e) => {
              setCode(sqlExamples[+e.target.value].code);
              setError("");
            }}
            defaultValue="0"
          >
            {sqlExamples.map((x, i) => (
              <option value={i} key={x.title}>
                {x.title}
              </option>
            ))}
          </select>
        </label>
        <Button
          variant="ghost"
          onClick={() => {
            setInitKey((k) => k + 1);
            setResults([]);
          }}
          disabled={busy}
        >
          <RotateCcw size={14} />
          Reset dataset
        </Button>
      </div>
      <label className="sr-only" htmlFor="sql-command">
        SQL command
      </label>
      <textarea
        id="sql-command"
        className="command-editor"
        value={code}
        onChange={(e) => setCode(e.target.value)}
        spellCheck={false}
        onKeyDown={(e) => {
          if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
            e.preventDefault();
            run();
          }
        }}
      />
      <div className="editor-actions">
        <span>
          {ready
            ? "PostgreSQL ready · Ctrl/⌘ + Enter"
            : "Starting local PostgreSQL…"}
        </span>
        <Button onClick={run} disabled={!ready || busy || !code.trim()}>
          <Play size={15} />
          {busy ? "Running…" : "Run SQL"}
        </Button>
      </div>
      <div aria-live="polite">
        {error && (
          <div role="alert" className="feedback bad">
            <strong>PostgreSQL returned an error</strong>
            <p>{error}</p>
            <p>
              Check the table/column names, types and constraints. Your cloud
              database was not touched.
            </p>
          </div>
        )}
        {results.map((r, i) => (
          <div key={i} className="query-output">
            <div className="eyeline">
              Statement {i + 1}
              <span>
                {r.rows.length} returned rows
                {r.affectedRows !== undefined
                  ? ` · ${r.affectedRows} affected`
                  : ""}
              </span>
            </div>
            {r.rows.length ? (
              <DataTable rows={r.rows} />
            ) : (
              <p className="empty-inline">
                Command completed. No rows returned.
              </p>
            )}
          </div>
        ))}
      </div>
      <details className="schema-details">
        <summary>
          <Database size={15} />
          Browse local tables ({tables.length})
        </summary>
        <div className="table-chips">
          {tables.map((t) => (
            <button
              key={t}
              onClick={() => setCode(`SELECT * FROM ${t} LIMIT 20;`)}
            >
              {t}
            </button>
          ))}
        </div>
      </details>
    </div>
  );
}
const mongoExamples = [
  ["Read customers", "db.customers.find({})"],
  [
    "Insert a customer",
    'db.customers.insertOne({first_name:"Yousef",age:21,address:{city:"Muharraq"}})',
  ],
  [
    "Update a customer",
    'db.customers.updateOne({first_name:"Ahmed"},{$set:{age:45}})',
  ],
  ["Delete one", 'db.customers.deleteOne({first_name:"Ahmed"})'],
  [
    "Same account conditions",
    'db.customers.find({account:{$elemMatch:{currency:"USD",balance:{$gte:100}}}},{_id:0,first_name:1})',
  ],
  [
    "Projection and sorting",
    "db.customers.find({age:{$gte:18}},{_id:0,first_name:1,age:1}).sort({age:-1}).limit(3)",
  ],
  [
    "Group orders",
    'db.purchase_orders.aggregate([{$group:{_id:"$product",total:{$sum:"$total"}}},{$sort:{total:-1}}])',
  ],
  [
    "Unwind accounts",
    'db.customers.aggregate([{$unwind:"$account"},{$group:{_id:"$account.currency",sum_balance:{$sum:"$account.balance"}}}])',
  ],
  [
    "LEFT lookup",
    'db.clients.aggregate([{$lookup:{from:"orders",localField:"_id",foreignField:"user_id",as:"user_orders"}}])',
  ],
  [
    "INNER lookup",
    'db.clients.aggregate([{$lookup:{from:"orders",localField:"_id",foreignField:"user_id",as:"user_orders"}},{$match:{"user_orders.0":{$exists:true}}}])',
  ],
  [
    "Right-preserving lookup",
    'db.orders.aggregate([{$lookup:{from:"clients",localField:"user_id",foreignField:"_id",as:"client"}},{$unwind:{path:"$client",preserveNullAndEmptyArrays:true}}])',
  ],
  [
    "Materialize with $out",
    'db.purchase_orders.aggregate([{$group:{_id:"$product",total:{$sum:"$total"}}},{$out:"product_totals"}])',
  ],
  [
    "Merge salary totals",
    'db.salaries.aggregate([{$group:{_id:{year:"$fiscal_year",dept:"$dept"},salaries:{$sum:"$salary"}}},{$merge:{into:"budgets",on:"_id",whenMatched:"replace",whenNotMatched:"insert"}}])',
  ],
  [
    "Create text index",
    'db.articles.createIndex({subject:"text",author:"text"})',
  ],
  ["Text search (index first)", 'db.articles.find({$text:{$search:"coffee"}})'],
  [
    "Bulk writes",
    'db.customers.bulkWrite([{insertOne:{document:{first_name:"Salem",age:25}}},{updateOne:{filter:{first_name:"Ahmed"},update:{$inc:{age:1}}}}])',
  ],
];
export function MongoPlayground() {
  const [state, setState] = useState<MongoState>(mongoSeed),
    [code, setCode] = useState(mongoExamples[0][1]),
    [output, setOutput] = useState<any>(null),
    [before, setBefore] = useState<any>(null),
    [error, setError] = useState(""),
    [collection, setCollection] = useState("customers");
  function run() {
    try {
      const result = runMongo(state, code);
      setBefore(state.collections[collection] || []);
      setState(result.state);
      setOutput(result.output);
      setError("");
    } catch (e) {
      setError((e as Error).message);
    }
  }
  return (
    <div className="playground">
      <div className="simulation-label">
        <Terminal size={15} />
        <b>Simulated Practice</b>
        <span>Local document model · no Atlas connection</span>
      </div>
      <p className="muted">
        One command at a time. A safe JSON/JSON5 parser handles data; no
        JavaScript is evaluated. Numeric teaching IDs replace BSON ObjectIds
        here. Text search demonstrates simple token matching, not real MongoDB
        ranking.
      </p>
      <div className="editor-toolbar">
        <label>
          Example
          <select
            aria-label="MongoDB example"
            onChange={(e) => setCode(mongoExamples[+e.target.value][1])}
          >
            {mongoExamples.map(([t], i) => (
              <option key={t} value={i}>
                {t}
              </option>
            ))}
          </select>
        </label>
        <Button
          variant="ghost"
          onClick={() => {
            setState(mongoSeed());
            setOutput(null);
            setBefore(null);
            setError("");
            setCollection("customers");
          }}
        >
          <RotateCcw size={14} />
          Reset
        </Button>
      </div>
      <label className="sr-only" htmlFor="mongo-command">
        MongoDB command
      </label>
      <textarea
        id="mongo-command"
        className="command-editor"
        value={code}
        onChange={(e) => setCode(e.target.value)}
        spellCheck={false}
      />
      <div className="editor-actions">
        <span>CRUD · filters · arrays · aggregation · indexes</span>
        <Button onClick={run}>
          <Play size={15} />
          Run command
        </Button>
      </div>
      {error && (
        <p className="feedback bad" role="alert">
          {error}
        </p>
      )}
      {output !== null && (
        <div className="query-output" aria-live="polite">
          <strong>Command result</strong>
          <pre>{JSON.stringify(output, null, 2)}</pre>
        </div>
      )}
      <div className="editor-toolbar">
        <label>
          Inspect collection
          <select
            value={collection}
            onChange={(e) => {
              setCollection(e.target.value);
              setBefore(null);
            }}
          >
            {Object.keys(state.collections).map((k) => (
              <option key={k}>{k}</option>
            ))}
          </select>
        </label>
        <span className="muted">
          {state.collections[collection]?.length || 0} documents
        </span>
      </div>
      <div className="before-after">
        {before && (
          <div>
            <h4>Before the last successful command</h4>
            <pre>{JSON.stringify(before, null, 2)}</pre>
          </div>
        )}
        <div>
          <h4>Current documents</h4>
          <pre>
            {JSON.stringify(state.collections[collection] || [], null, 2)}
          </pre>
        </div>
      </div>
      <details>
        <summary>Supported subset and limits</summary>
        <p>
          insertOne/Many, find/One, updateOne/Many, replaceOne, deleteOne/Many,
          countDocuments, distinct, createIndex and selected bulkWrite
          operations. Filters include comparison, logic, $elemMatch, $all,
          $size, $exists and string $regex. Pipelines: $match, $group
          ($sum/$push/$avg), $sort, $unwind, simple $lookup, $project,
          $skip/$limit, terminal $out and replace/insert $merge. Arbitrary
          JavaScript, ObjectId construction, real query plans, transactions,
          server replication and full-text relevance are outside this
          simulation.
        </p>
      </details>
    </div>
  );
}
const redisExamples = [
  ["PING", "PING"],
  ["Store an expiring value", 'SET demo:flash_sale "live now" EX 10'],
  ["Read value", "GET demo:flash_sale"],
  ["Inspect expiry", "TTL demo:flash_sale"],
  ["Keep expiry on update", 'SET demo:flash_sale "updated" KEEPTTL'],
  ["Remove expiry", "PERSIST demo:flash_sale"],
  ["Atomic counter", "INCR pageviews:7"],
  ["Hash profile", "HSET customer:khalid tier gold"],
  ["Read hash", "HGETALL customer:khalid"],
  ["List", "RPUSH recent_pages home catalog cart"],
  ["Read list", "LRANGE recent_pages 0 -1"],
  ["Unique members", "SADD visitors:mon ahmed yousef ahmed"],
  ["Sorted scores", "ZREVRANGE leaderboard 0 2 WITHSCORES"],
  ["Update score", "ZINCRBY leaderboard 100 ahmed"],
  ["NX lock", "SET lock:invoice:8841 worker-3 NX EX 10"],
  ["Reset token", "SET reset:demo user:nasser EX 60"],
  ["Consume token", "GETDEL reset:demo"],
  [
    "Native JSON",
    'JSON.SET customer:json:ahmed $ \'{"name":"Ahmed","city":"Manama","orders":[{"id":1,"total":120.5}]}\'',
  ],
  ["Read JSON path", "JSON.GET customer:json:ahmed $.city"],
  ["Edit JSON path", "JSON.SET customer:json:ahmed $.city '\"Muharraq\"'"],
  [
    "Create JSON index",
    "FT.CREATE idx:customers ON JSON PREFIX 1 customer:json: SCHEMA $.name AS name TEXT $.city AS city TAG",
  ],
  ["Search indexed city", 'FT.SEARCH idx:customers "@city:{Muharraq}"'],
  ["Scan keyspace", "SCAN 0 MATCH customer:* COUNT 100"],
];
export function RedisPlayground() {
  const [state, setState] = useState<RedisState>(redisSeed),
    [code, setCode] = useState("PING"),
    [history, setHistory] = useState<
      { code: string; result: string; error?: boolean }[]
    >([]),
    [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 250);
    return () => clearInterval(t);
  }, []);
  const current = liveRedis(state, now);
  function run() {
    try {
      const r = runRedis(state, code);
      setState(r.state);
      setHistory((h) =>
        [
          {
            code,
            result:
              r.output === null
                ? "(nil)"
                : typeof r.output === "string"
                  ? r.output
                  : JSON.stringify(r.output, null, 2),
          },
          ...h,
        ].slice(0, 12),
      );
    } catch (e) {
      setHistory((h) =>
        [{ code, result: (e as Error).message, error: true }, ...h].slice(
          0,
          12,
        ),
      );
    }
  }
  return (
    <div className="playground">
      <div className="simulation-label">
        <Terminal size={15} />
        <b>Simulated Practice</b>
        <span>Local keyspace · real elapsed expiry timers</span>
      </div>
      <p className="muted">
        This is a teaching implementation, not a Redis server. Run one command
        at a time. Data resets when you close this component; browser background
        throttling may delay display refresh, but expiration is checked against
        the actual timestamp.
      </p>
      <div className="editor-toolbar">
        <label>
          Example
          <select
            aria-label="Redis example"
            onChange={(e) => setCode(redisExamples[+e.target.value][1])}
          >
            {redisExamples.map(([t], i) => (
              <option key={t} value={i}>
                {t}
              </option>
            ))}
          </select>
        </label>
        <Button
          variant="ghost"
          onClick={() => {
            setState(redisSeed());
            setHistory([]);
          }}
        >
          <RotateCcw size={14} />
          Reset
        </Button>
      </div>
      <label className="sr-only" htmlFor="redis-command">
        Redis command
      </label>
      <textarea
        id="redis-command"
        className="command-editor redis-editor"
        spellCheck={false}
        value={code}
        onChange={(e) => setCode(e.target.value)}
        onKeyDown={(e) => {
          if ((e.ctrlKey || e.metaKey) && e.key === "Enter") {
            e.preventDefault();
            run();
          }
        }}
      />
      <div className="editor-actions">
        <span>Strings · hashes · lists · sets · sorted sets · JSON</span>
        <Button onClick={run}>
          <Play size={15} />
          Run command
        </Button>
      </div>
      <div className="redis-panels">
        <div>
          <h4>
            Live keyspace{" "}
            <span className="muted">
              {Object.keys(current.keys).length} keys
            </span>
          </h4>
          <DataTable
            rows={Object.entries(current.keys).map(([key, v]) => ({
              key,
              type: v.type,
              value:
                typeof v.value === "object" ? JSON.stringify(v.value) : v.value,
              TTL: v.expiresAt
                ? `${Math.max(0, (v.expiresAt - now) / 1000).toFixed(1)}s`
                : "no expiry",
            }))}
          />
        </div>
        <div>
          <h4>Command history</h4>
          <div className="terminal-output" aria-live="polite">
            {history.length ? (
              history.map((h, i) => (
                <div key={i} className={h.error ? "terminal-error" : ""}>
                  <span>› {h.code}</span>
                  <pre>{h.result}</pre>
                </div>
              ))
            ) : (
              <p>Run PING to start.</p>
            )}
          </div>
        </div>
      </div>
      <details>
        <summary>Supported subset and limits</summary>
        <p>
          SET EX/PX/NX/XX/KEEPTTL; GET/GETDEL, INCR/DECR/INCRBY,
          DEL/EXISTS/TYPE/DBSIZE, TTL/PTTL/EXPIRE/PEXPIRE/PERSIST, KEYS/SCAN;
          HSET/HGET/HGETALL/HINCRBY; LPUSH/RPUSH/LPOP/RPOP/LLEN/LRANGE/LPOS;
          SADD/SMEMBERS/SCARD/SISMEMBER/SINTER;
          ZADD/ZINCRBY/ZRANK/ZREVRANK/ZRANGE/ZREVRANGE; basic
          JSON.SET/GET/NUMINCRBY; simple FT.CREATE with one prefix and exact TAG
          queries. Numeric counters use JavaScript safe integers. No server
          persistence, replication, script execution, optional specialized types
          or full query engine is simulated.
        </p>
      </details>
    </div>
  );
}
