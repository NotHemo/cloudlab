"use client";
import { assetPath } from "@/lib/asset-path";
import { useEffect, useState } from "react";
import Link from "next/link";
import {
  ArrowRight,
  ArrowLeft,
  Bookmark,
  BookmarkCheck,
  CheckCircle2,
  ChevronRight,
  Lightbulb,
  BookOpen,
  StickyNote,
  Check,
  Clock3,
} from "lucide-react";
import { lessons, modules, lessonById } from "@/content/course";
import { questions } from "@/content/questions";
import { useProgress } from "./progress-provider";
import { CodeBlock } from "./code-block";
import { QuestionCard } from "./question";
import { Visualization } from "./visualizations";
import { Button } from "./ui/button";
export function LessonView({ id }: { id: string }) {
  const lesson = lessonById(id)!;
  const { progress, update, ready } = useProgress();
  const [note, setNote] = useState(""),
    [saved, setSaved] = useState(false);
  const checks = questions.filter((q) => q.lessonId === id);
  const index = lessons.findIndex((l) => l.id === id),
    next = lessons[index + 1],
    prev = lessons[index - 1];
  const done = progress.completed.includes(id),
    bookmarked = progress.bookmarks.includes(id);
  useEffect(() => {
    if (ready) {
      setNote(progress.notes[id] || "");
      update((p) => (p.lastLesson === id ? p : { ...p, lastLesson: id }));
    }
  }, [id, ready]);
  return (
    <div className="page lesson-page">
      <div className="route-crumb">
        <Link href={`/week/${lesson.week}/`}>Week {lesson.week}</Link>
        <ChevronRight size={14} />
        <span>{lesson.title}</span>
      </div>
      <div className="page-heading">
        <div>
          <span className="eyeline">
            Lesson {modules[lesson.week - 1].lessonIds.indexOf(id) + 1} of{" "}
            {modules[lesson.week - 1].lessonIds.length} · {lesson.minutes} min +
            practice
          </span>
          <h1>{lesson.title}</h1>
          <p>{lesson.description}</p>
        </div>
        <Button
          variant="outline"
          aria-pressed={bookmarked}
          onClick={() =>
            update((p) => ({
              ...p,
              bookmarks: bookmarked
                ? p.bookmarks.filter((x) => x !== id)
                : [...p.bookmarks, id],
            }))
          }
        >
          {bookmarked ? <BookmarkCheck size={17} /> : <Bookmark size={17} />}
          <span>{bookmarked ? "Bookmarked" : "Bookmark"}</span>
        </Button>
      </div>
      <div className="lesson-layout">
        <article className="lesson-article">
          <div className="lesson-goal">
            <Lightbulb size={20} />
            <div>
              <b>The idea to take away</b>
              <p>{lesson.takeaways[0]}</p>
            </div>
          </div>
          {lesson.note && (
            <aside className="source-note">
              <BookOpen size={17} />
              <p>{lesson.note}</p>
            </aside>
          )}
          {lesson.concepts.map((c, i) => (
            <div key={c.term}>
              <section id={`concept-${i}`} className="concept">
                <span className="eyeline">
                  {String(i + 1).padStart(2, "0")} · Understand the idea
                </span>
                <h2>{c.term}</h2>
                <p className="concept-explanation">{c.explanation}</p>
                <p>
                  <strong>Why we use it.</strong> {c.why}
                </p>
                <div className="analogy">
                  <span>Think of it this way</span>
                  <p>{c.analogy}</p>
                </div>
                {c.code && (
                  <CodeBlock
                    code={c.code}
                    label="Technical example"
                    lines={c.lines}
                  />
                )}
                <h3>How it works</h3>
                <ol className="step-list">
                  {c.steps.map((s, n) => (
                    <li key={s}>
                      <span>{n + 1}</span>
                      <p>{s}</p>
                    </li>
                  ))}
                </ol>
                <details className="quick-think">
                  <summary>Pause and think: {c.check}</summary>
                  <p>{c.answer}</p>
                </details>
              </section>
              {i === 0 && checks[0] && (
                <QuestionCard question={checks[0]} key={checks[0].id} />
              )}
            </div>
          ))}
          {lesson.visual && (
            <section className="lesson-interactive">
              <span className="eyeline">Explore it yourself</span>
              <Visualization kind={lesson.visual} />
            </section>
          )}
          {lesson.image && (
            <details className="source-figure">
              <summary>View the original course diagram</summary>
              <img
                src={assetPath(lesson.image)}
                alt={
                  lesson.id === "dvdrental"
                    ? "DVD Rental ER diagram with fifteen tables and their foreign-key relationships"
                    : "Original comparison of pgAdmin and the Supabase dashboard"
                }
              />
              <p>
                The original visual is included for reference. The lesson
                explains its main relationships and terms above.
              </p>
            </details>
          )}
          <section className="lesson-summary">
            <span className="eyeline">Bring it together</span>
            <h2>What you learned</h2>
            <ul>
              {lesson.takeaways.map((t) => (
                <li key={t}>
                  <Check size={16} />
                  {t}
                </li>
              ))}
            </ul>
            <h3>Important terms</h3>
            <div className="term-chips">
              {lesson.concepts.map((c, i) => (
                <a href={`#concept-${i}`} key={c.term}>
                  {c.term}
                </a>
              ))}
            </div>
            <h3>Common mistakes</h3>
            <ul>
              {lesson.mistakes.map((m) => (
                <li key={m}>{m}</li>
              ))}
            </ul>
            {lesson.concepts.some((c) => c.code) && (
              <details>
                <summary>Commands to remember</summary>
                {lesson.concepts
                  .filter((c) => c.code)
                  .map((c) => (
                    <CodeBlock key={c.term} code={c.code!} label={c.term} />
                  ))}
              </details>
            )}
          </section>
          <section className="recap">
            <h2>A quick recap check</h2>
            {checks.slice(1, 4).map((q) => (
              <QuestionCard question={q} key={q.id} />
            ))}
          </section>
          <section className="personal-note">
            <h3>
              <StickyNote size={18} />
              Your personal note
            </h3>
            <label className="sr-only" htmlFor="lesson-note">
              Note for this lesson
            </label>
            <textarea
              id="lesson-note"
              placeholder="Explain the idea in your own words. What finally clicked?"
              value={note}
              onChange={(e) => {
                setNote(e.target.value);
                setSaved(false);
              }}
            />
            <div>
              <span className="muted">
                Stored in this browser. Keep credentials out of notes.
              </span>
              <Button
                variant="outline"
                onClick={() => {
                  update((p) => ({ ...p, notes: { ...p.notes, [id]: note } }));
                  setSaved(true);
                }}
              >
                {saved ? <Check size={15} /> : null}
                {saved ? "Saved" : "Save note"}
              </Button>
            </div>
          </section>
          <div className="lesson-complete">
            <div>
              <CheckCircle2 size={24} />
              <span>
                <strong>
                  {done ? "Lesson complete" : "Ready to move on?"}
                </strong>
                <small>
                  {done
                    ? "You can revisit it any time."
                    : "Mark your reading complete when you understand the key ideas."}
                </small>
              </span>
            </div>
            <Button
              onClick={() =>
                update((p) => ({
                  ...p,
                  completed: done
                    ? p.completed.filter((x) => x !== id)
                    : [...p.completed, id],
                }))
              }
              variant={done ? "outline" : "default"}
            >
              {done ? "Mark incomplete" : "Complete lesson"}
            </Button>
          </div>
          <div className="lesson-pagination">
            {prev ? (
              <Link href={`/lesson/${prev.id}/`}>
                <ArrowLeft size={17} />
                <span>
                  Previous<small>{prev.title}</small>
                </span>
              </Link>
            ) : (
              <span />
            )}
            {next ? (
              <Link href={`/lesson/${next.id}/`}>
                <span>
                  Next lesson<small>{next.title}</small>
                </span>
                <ArrowRight size={17} />
              </Link>
            ) : (
              <Link href="/quiz/">
                Take a mock exam
                <ArrowRight size={17} />
              </Link>
            )}
          </div>
        </article>
        <aside className="lesson-toc">
          <div>
            <span className="eyeline">In this lesson</span>
            {lesson.concepts.map((c, i) => (
              <a href={`#concept-${i}`} key={c.term}>
                <span>{String(i + 1).padStart(2, "0")}</span>
                {c.term}
              </a>
            ))}
            <Link href={`/labs/?week=${lesson.week}`}>
              Week {lesson.week} practice lab <ArrowRight size={14} />
            </Link>
            <Link href={`/sources/?week=${lesson.week}`}>
              Source slides {lesson.slides.join(", ")} <BookOpen size={14} />
            </Link>
          </div>
          <p>
            Read a little.
            <br />
            Try the example.
            <br />
            Explain it back.
          </p>
        </aside>
      </div>
    </div>
  );
}
