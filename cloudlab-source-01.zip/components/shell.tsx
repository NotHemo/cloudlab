"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import {
  LayoutDashboard,
  BookOpen,
  FlaskConical,
  Layers,
  ClipboardCheck,
  Bookmark,
  Search,
  Sun,
  Moon,
  Menu,
  X,
  Database,
  ChevronRight,
  Files,
  GraduationCap,
  PanelLeftClose,
} from "lucide-react";
import { modules, lessons } from "@/content/course";
import { useProgress } from "./progress-provider";
import { Button } from "./ui/button";
const nav = [
  { href: "/", label: "My learning", icon: LayoutDashboard },
  { href: "/labs/", label: "Practice labs", icon: FlaskConical },
  { href: "/quiz/", label: "Quiz & mock exam", icon: ClipboardCheck },
  { href: "/flashcards/", label: "Flashcards", icon: Layers },
  { href: "/revision/", label: "Quick revision", icon: BookOpen },
  { href: "/notebook/", label: "My notebook", icon: Bookmark },
];
export function Shell({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  const { progress, update } = useProgress();
  const [open, setOpen] = useState(false),
    [search, setSearch] = useState(""),
    [focused, setFocused] = useState(false);
  const sidebar = useRef<HTMLElement>(null);
  const menuButton = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    const desktop = window.matchMedia("(min-width:1051px)");
    const close = () => {
      if (desktop.matches) setOpen(false);
    };
    desktop.addEventListener("change", close);
    return () => desktop.removeEventListener("change", close);
  }, []);
  useEffect(() => {
    if (!open) return;
    sidebar.current?.querySelector<HTMLElement>("button,a[href]")?.focus();
    const keyboard = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        menuButton.current?.focus();
      }
      if (e.key === "Tab") {
        const controls = [
          ...(sidebar.current?.querySelectorAll<HTMLElement>(
            "a[href],button,input,select",
          ) || []),
        ].filter((el) => el.getClientRects().length);
        const first = controls[0],
          last = controls[controls.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last?.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first?.focus();
        }
      }
    };
    document.addEventListener("keydown", keyboard);
    return () => document.removeEventListener("keydown", keyboard);
  }, [open]);
  const result = search.trim()
    ? lessons
        .filter((l) =>
          `${l.title} ${l.description} ${l.concepts.map((c) => c.term + " " + c.explanation).join(" ")}`
            .toLowerCase()
            .includes(search.toLowerCase()),
        )
        .slice(0, 12)
    : [];
  const percent = Math.round(
    (progress.completed.length / lessons.length) * 100,
  );
  return (
    <div className="app-shell">
      <a href="#main" className="skip-link">
        Skip to content
      </a>
      <div className="mobile-bar">
        <Link href="/" className="brand">
          <Database size={24} />
          <b>CloudLab</b>
        </Link>
        <Button
          ref={menuButton}
          size="icon"
          variant="ghost"
          aria-label={open ? "Close navigation" : "Open navigation"}
          aria-expanded={open}
          aria-controls="course-navigation"
          onClick={() => setOpen(!open)}
        >
          {open ? <X /> : <Menu />}
        </Button>
      </div>
      <aside
        ref={sidebar}
        id="course-navigation"
        aria-label="Course navigation"
        className={`sidebar ${open ? "is-open" : ""}`}
      >
        <button
          className="mobile-close"
          onClick={() => {
            setOpen(false);
            menuButton.current?.focus();
          }}
        >
          <X size={17} />
          Close navigation
        </button>
        <Link href="/" className="brand" onClick={() => setOpen(false)}>
          <svg width="30" height="34" viewBox="0 0 30 34" aria-hidden="true">
            <path
              d="M3 8 15 2 27 8 15 14ZM3 16l12 6 12-6M3 24l12 7 12-7"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.8"
              strokeLinejoin="round"
            />
          </svg>
          <span>
            <b>CloudLab</b>
            <small>Your database learning space</small>
          </span>
        </Link>
        <div className="course-label">
          <GraduationCap size={16} />
          <span>
            IT8417 <small>Advanced Cloud Databases</small>
          </span>
        </div>
        <nav aria-label="Study tools">
          {nav.map(({ href, label, icon: Icon }) => (
            <Link
              className={`nav-link ${path === href ? "active" : ""}`}
              key={href}
              href={href}
              aria-current={path === href ? "page" : undefined}
              onClick={() => setOpen(false)}
            >
              <Icon size={18} />
              {label}
            </Link>
          ))}
        </nav>
        <div className="nav-group-label">
          Your course <span>6 weeks</span>
        </div>
        <nav className="week-nav" aria-label="Course modules">
          {modules.map((m) => {
            const done = m.lessonIds.filter((id) =>
              progress.completed.includes(id),
            ).length;
            return (
              <div key={m.week}>
                <Link
                  className={`week-link ${path === `/week/${m.week}/` || m.lessonIds.some((id) => path === `/lesson/${id}/`) ? "active" : ""}`}
                  aria-current={
                    path === `/week/${m.week}/` ? "page" : undefined
                  }
                  href={`/week/${m.week}/`}
                  onClick={() => setOpen(false)}
                >
                  <span className="week-number">
                    {String(m.week).padStart(2, "0")}
                  </span>
                  <span>
                    {m.short}
                    <small>
                      {done}/{m.lessonIds.length} lessons
                    </small>
                  </span>
                  <ChevronRight size={14} />
                </Link>
                {path.startsWith("/lesson/") &&
                  m.lessonIds.some((id) => path.includes(id)) && (
                    <div className="topic-nav">
                      {lessons
                        .filter((l) => l.week === m.week)
                        .map((l) => (
                          <Link
                            onClick={() => setOpen(false)}
                            key={l.id}
                            className={path.includes(l.id) ? "current" : ""}
                            href={`/lesson/${l.id}/`}
                          >
                            {l.title}
                          </Link>
                        ))}
                    </div>
                  )}
              </div>
            );
          })}
        </nav>
        <div className="sidebar-foot">
          <div className="progress-label">
            <span>Course progress</span>
            <strong>{percent}%</strong>
          </div>
          <div className="progress-track">
            <div style={{ width: `${percent}%` }} />
          </div>
          <Link
            href="/sources/"
            className={`nav-link ${path === "/sources/" ? "active" : ""}`}
            onClick={() => setOpen(false)}
          >
            <Files size={17} />
            Course sources <span className="source-count">12</span>
          </Link>
          <button
            className="theme-button"
            onClick={() =>
              update((p) => ({
                ...p,
                theme: p.theme === "light" ? "dark" : "light",
              }))
            }
          >
            {progress.theme === "light" ? (
              <Moon size={17} />
            ) : (
              <Sun size={17} />
            )}{" "}
            {progress.theme === "light"
              ? "Switch to dark mode"
              : "Switch to light mode"}
          </button>
          <p>Made for understanding.</p>
        </div>
      </aside>
      <div className="workspace" inert={open}>
        <header className="workspace-bar">
          <div className="breadcrumb">
            IT8417 <ChevronRight size={13} /> <span>Weeks 1–6</span>
          </div>
          <div className="search-box">
            <Search size={17} />
            <input
              aria-label="Search all course lessons"
              placeholder="Search a concept, command, or lesson…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onFocus={() => setFocused(true)}
              onKeyDown={(e) => {
                if (e.key === "Escape") {
                  setFocused(false);
                  setSearch("");
                }
              }}
            />
            {search && (
              <button aria-label="Clear search" onClick={() => setSearch("")}>
                <X size={14} />
              </button>
            )}
            {focused && search && (
              <div className="search-results">
                <div className="search-result-heading">
                  {result.length
                    ? `${result.length} matching lessons`
                    : "No matching lessons"}
                </div>
                {result.map((l) => (
                  <Link
                    key={l.id}
                    href={`/lesson/${l.id}/`}
                    onClick={() => {
                      setSearch("");
                      setFocused(false);
                    }}
                  >
                    <span>Week {l.week}</span>
                    <strong>{l.title}</strong>
                    <small>{l.description}</small>
                  </Link>
                ))}
              </div>
            )}
          </div>
          <span className="student-avatar" aria-label="Local student profile">
            S
          </span>
        </header>
        <main id="main" tabIndex={-1}>
          {children}
        </main>
        <footer className="page-footer">
          <span>IT8417 · Learn it. Try it. Make it click.</span>
          <Link href="/sources/">
            Source map & teaching notes <ChevronRight size={13} />
          </Link>
        </footer>
      </div>
    </div>
  );
}
