"use client";
import { useRef, useState } from "react";
import Link from "next/link";
import {
  Bookmark,
  StickyNote,
  ArrowRight,
  Download,
  Upload,
  Check,
} from "lucide-react";
import { lessons } from "@/content/course";
import { parseProgressBackup } from "@/lib/progress";
import { useProgress } from "@/components/progress-provider";
import { Button } from "@/components/ui/button";
export default function NotebookPage() {
  const { progress, update } = useProgress();
  const [status, setStatus] = useState(""),
    [editing, setEditing] = useState<string | null>(null),
    [text, setText] = useState("");
  const input = useRef<HTMLInputElement>(null);
  const notes = lessons.filter((l) => progress.notes[l.id]?.trim());
  const marked = lessons.filter((l) => progress.bookmarks.includes(l.id));
  function exportData() {
    const url = URL.createObjectURL(
      new Blob(
        [JSON.stringify({ version: 1, course: "IT8417", progress }, null, 2)],
        { type: "application/json" },
      ),
    );
    const a = document.createElement("a");
    a.href = url;
    a.download = "it8417-study-backup.json";
    a.click();
    URL.revokeObjectURL(url);
    setStatus("Progress backup exported.");
  }
  async function importData(file?: File) {
    if (!file) return;
    try {
      if (file.size > 2_000_000)
        throw new Error("Choose a backup smaller than 2 MB.");
      const p = parseProgressBackup(await file.text());
      update((old) => ({
        ...old,
        completed: [...new Set([...old.completed, ...p.completed!])],
        bookmarks: [...new Set([...old.bookmarks, ...p.bookmarks!])],
        labSteps: [...new Set([...old.labSteps, ...p.labSteps!])],
        days: [...new Set([...old.days, ...p.days!])],
        notes: { ...old.notes, ...p.notes },
        answers: { ...old.answers, ...p.answers },
        mastery: { ...old.mastery, ...p.mastery },
      }));
      setStatus(
        "Backup merged. Existing lesson completions were retained; matching notes and answers use the imported values.",
      );
    } catch (e) {
      setStatus(`Import failed: ${(e as Error).message}`);
    }
    if (input.current) input.current.value = "";
  }
  return (
    <div className="page">
      <div className="page-heading">
        <div>
          <span className="eyeline">
            Your own understanding, in your own words
          </span>
          <h1>My notebook</h1>
          <p>
            Keep useful lessons close and save the explanations that make sense
            to you.
          </p>
        </div>
        <div className="button-row">
          <Button variant="outline" onClick={exportData}>
            <Download size={16} />
            Export backup
          </Button>
          <Button variant="outline" onClick={() => input.current?.click()}>
            <Upload size={16} />
            Import backup
          </Button>
          <input
            className="sr-only"
            ref={input}
            type="file"
            accept="application/json,.json"
            onChange={(e) => importData(e.target.files?.[0])}
            aria-label="Import progress backup"
          />
        </div>
      </div>
      {status && (
        <p className="source-note" role="status">
          {status}
        </p>
      )}
      <div className="notebook-grid">
        <section>
          <h2>
            <Bookmark size={20} />
            Bookmarked lessons <span>{marked.length}</span>
          </h2>
          {marked.length ? (
            marked.map((l) => (
              <div className="notebook-row" key={l.id}>
                <Link href={`/lesson/${l.id}/`}>
                  <small>Week {l.week}</small>
                  <strong>{l.title}</strong>
                </Link>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() =>
                    update((p) => ({
                      ...p,
                      bookmarks: p.bookmarks.filter((x) => x !== l.id),
                    }))
                  }
                >
                  Remove
                </Button>
              </div>
            ))
          ) : (
            <div className="empty-state">
              <Bookmark size={26} />
              <h3>Your reading shelf starts here.</h3>
              <p>Bookmark any lesson to find it again quickly.</p>
              <Link className="text-link" href="/">
                Explore your course <ArrowRight size={14} />
              </Link>
            </div>
          )}
        </section>
        <section>
          <h2>
            <StickyNote size={20} />
            Personal notes <span>{notes.length}</span>
          </h2>
          {notes.length ? (
            notes.map((l) => (
              <div className="note-card" key={l.id}>
                <Link href={`/lesson/${l.id}/`}>
                  Week {l.week} · {l.title}
                  <ArrowRight size={14} />
                </Link>
                {editing === l.id ? (
                  <>
                    <label className="sr-only" htmlFor="edit-note">
                      Edit note
                    </label>
                    <textarea
                      id="edit-note"
                      value={text}
                      onChange={(e) => setText(e.target.value)}
                    />
                    <Button
                      size="sm"
                      onClick={() => {
                        update((p) => ({
                          ...p,
                          notes: { ...p.notes, [l.id]: text },
                        }));
                        setEditing(null);
                      }}
                    >
                      <Check size={14} />
                      Save
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setEditing(null)}
                    >
                      Cancel
                    </Button>
                  </>
                ) : (
                  <>
                    <p>{progress.notes[l.id]}</p>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setText(progress.notes[l.id]);
                        setEditing(l.id);
                      }}
                    >
                      Edit note
                    </Button>
                  </>
                )}
              </div>
            ))
          ) : (
            <div className="empty-state">
              <StickyNote size={26} />
              <h3>Write it so you understand it.</h3>
              <p>
                Each lesson has a note space. Save a question, analogy or a
                small breakthrough.
              </p>
            </div>
          )}
        </section>
      </div>
      <p className="muted">
        Study data is stored in this browser’s LocalStorage. Export a backup
        before clearing browser data or switching devices. Avoid storing
        passwords in notes.
      </p>
    </div>
  );
}
