import type { Metadata } from "next";
import { ProgressProvider } from "@/components/progress-provider";
import { Shell } from "@/components/shell";
import { DEFAULT_THEME, themeBootstrapScript } from "@/lib/theme";
import "./globals.css";
export const metadata: Metadata = {
  title: "CloudLab — IT8417",
  description:
    "Learn Advanced Cloud Databases through guided lessons, interactive practice and revision. Weeks 1–6.",
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" data-theme={DEFAULT_THEME} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeBootstrapScript }} />
      </head>
      <body>
        <ProgressProvider>
          <Shell>{children}</Shell>
        </ProgressProvider>
      </body>
    </html>
  );
}
