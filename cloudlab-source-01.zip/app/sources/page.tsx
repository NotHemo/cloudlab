"use client";
import { assetPath } from "@/lib/asset-path";
import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Download,
  ArrowRight,
  Files,
  BookOpen,
  ExternalLink,
} from "lucide-react";
import sourceData from "@/content/sources.json";
import { lessons } from "@/content/course";
import { labs } from "@/content/labs";
type Source = {
  file: string;
  week: number;
  type: string;
  media: string[];
  sections: { number: number; paragraphs: string[]; images: string[] }[];
};
const sources = sourceData as Source[];
const references = [
  [
    "Supabase connections: direct and pooler modes",
    "https://supabase.com/docs/guides/database/connecting-to-postgres",
  ],
  [
    "PostgreSQL COPY and client/server file access",
    "https://www.postgresql.org/docs/current/sql-copy.html",
  ],
  [
    "Databricks constraints and validation",
    "https://docs.databricks.com/aws/en/tables/constraints",
  ],
  [
    "MongoDB embedding and references",
    "https://www.mongodb.com/docs/manual/data-modeling/",
  ],
  [
    "MongoDB $lookup behavior",
    "https://www.mongodb.com/docs/manual/reference/operator/aggregation/lookup/",
  ],
  [
    "Redis SET options and KEEPTTL",
    "https://redis.io/docs/latest/commands/set/",
  ],
  ["Redis key expiration", "https://redis.io/docs/latest/commands/expire/"],
];
export default function SourcesPage() {
  const [week, setWeek] = useState(1),
    [view, setView] = useState<"map" | "slides" | "lab" | "images">("map");
  useEffect(() => {
    const w = Number(new URLSearchParams(window.location.search).get("week"));
    if (w >= 1 && w <= 6) setWeek(w);
  }, []);
  const slides = sources.find((s) => s.week === week && s.type === ".pptx")!,
    lab = sources.find((s) => s.week === week && s.type === ".docx")!;
  return (
    <div className="page sources-page">
      <div className="page-heading">
        <div>
          <span className="eyeline">Trace every topic back to the course</span>
          <h1>Course sources</h1>
          <p>
            12 original files · 156 slides · six practical guides. Teaching
            explanations are linked to their sources.
          </p>
        </div>
        <Files size={28} />
      </div>
      <div className="source-note">
        <BookOpen size={20} />
        <p>
          The 12 Office files are the primary reference. Analogies, small
          teaching datasets and simulations are additions. Separate
          archives/scripts named by the guides were not uploaded: dvdrental.tar,
          Week 2 Script 04, the optional RLS guide and the referenced Week 5/6
          scripts. Their absence is labeled in the relevant lab steps.
        </p>
      </div>
      <div className="week-filter">
        {[1, 2, 3, 4, 5, 6].map((w) => (
          <button aria-pressed={week === w} key={w} onClick={() => setWeek(w)}>
            Week {w}
          </button>
        ))}
      </div>
      <div className="source-downloads">
        <a
          href={assetPath(`/sources/${slides.file}`)}
          download
          className="btn btn-outline"
        >
          <Download size={15} />
          Original lecture PPTX
        </a>
        <a href={assetPath(`/sources/${lab.file}`)} download className="btn btn-outline">
          <Download size={15} />
          Original lab DOCX
        </a>
        <a
          href={assetPath(`/practice/week-${week}-teaching-examples.txt`)}
          download
          className="text-link"
        >
          Teaching command extracts <Download size={14} />
        </a>
      </div>
      <div className="tabs">
        {(["map", "slides", "lab", "images"] as const).map((v) => (
          <button key={v} aria-selected={view === v} onClick={() => setView(v)}>
            {
              {
                map: "Coverage map",
                slides: "Lecture source text",
                lab: "Original lab text",
                images: "Source visuals",
              }[v]
            }
          </button>
        ))}
      </div>
      {view === "map" ? (
        <>
          <h2>Week {week} · source-to-lesson map</h2>
          <p className="muted">
            Slide references use physical slide order in the PPTX, because
            printed slide numbers are inconsistent.
          </p>
          <div className="coverage-list">
            {slides.sections.map((s) => (
              <div key={s.number}>
                <span className="coverage-index">
                  {String(s.number).padStart(2, "0")}
                </span>
                <div>
                  <strong>
                    {s.paragraphs.filter((p) => !p.startsWith("IT8417"))[1] ||
                      s.paragraphs[0] ||
                      "Source visual"}
                  </strong>
                  <div>
                    {lessons
                      .filter(
                        (l) => l.week === week && l.slides.includes(s.number),
                      )
                      .map((l) => (
                        <Link key={l.id} href={`/lesson/${l.id}/`}>
                          {l.title}
                          <ArrowRight size={12} />
                        </Link>
                      ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
          <h2>Lab activities</h2>
          <div className="coverage-list">
            {labs[week - 1].steps.map((s, i) => (
              <div key={s.title}>
                <span className="coverage-index">{i + 1}</span>
                <div>
                  <strong>{s.title}</strong>
                  <p>{s.instruction}</p>
                  <Link href={`/labs/?week=${week}`}>
                    Open guided lab <ArrowRight size={13} />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : view === "slides" ? (
        <div>
          {slides.sections.map((s) => (
            <details className="source-section" key={`${week}-${s.number}`}>
              <summary>
                Slide {s.number} ·{" "}
                {s.paragraphs[1] || s.paragraphs[0] || "Visual"}
              </summary>
              <div className="source-transcript">
                {s.paragraphs.map((p, i) => (
                  <p key={i}>{p}</p>
                ))}
              </div>
              {s.images
                .filter((p) => !p.endsWith("/image1.png"))
                .map((p, i) => (
                  <img
                    key={i}
                    src={assetPath(p)}
                    alt={`Source visual from Week ${week} slide ${s.number}`}
                  />
                ))}
            </details>
          ))}
        </div>
      ) : view === "lab" ? (
        <section className="source-transcript source-lab">
          <h2>Original Week {week} guide</h2>
          <p className="muted">
            Plain-text extraction in source order, including table cells. The
            downloadable DOCX preserves the original formatting.
            Credential-looking MongoDB URI values are masked in this readable
            copy.
          </p>
          {lab.sections
            .flatMap((s) => s.paragraphs)
            .map((p, i) => (
              <p key={`${week}-${i}`}>{p}</p>
            ))}
        </section>
      ) : (
        <div className="source-images">
          {[...slides.media, ...lab.media]
            .filter(
              (p) => !p.endsWith("/image1.png") || p.includes("Lab_Guide"),
            )
            .map((p) => (
              <figure key={p}>
                <a href={assetPath(p)} target="_blank" rel="noreferrer">
                  <img
                    src={assetPath(p)}
                    alt={`Original ${p.split("/").slice(-2).join(" ")} course visual`}
                  />
                </a>
                <figcaption>{p.split("/").slice(-2).join(" · ")}</figcaption>
              </figure>
            ))}
        </div>
      )}
      <section className="source-corrections">
        <h2>Accuracy notes</h2>
        <ul>
          <li>
            <b>Week 1:</b> The lab mixes a transaction-pooler URI (6543) with a
            5432 label. Use all fields from one selected mode.
          </li>
          <li>
            <b>Week 3:</b> The pipeline uses six source tables. CSV imports can
            infer types; CAST alone does not inherently drop rows. COPY with a
            server filename differs from COPY TO STDOUT.
          </li>
          <li>
            <b>Week 4:</b> A LEFT JOIN can multiply events if payment matches
            are not unique. Validate the fact grain. The free-setup Parquet
            restriction is retained. SCD examples need valid Delta syntax, a
            justified historical baseline and event-time key resolution.
          </li>
          <li>
            <b>Week 5:</b> Analytical columnar engines are different from
            wide-column/column-family stores. Right-preserving lookup starts
            from the intended preserved collection. Referenced course scripts
            are separate resources.
          </li>
          <li>
            <b>Week 6:</b> The lab uses Redis Cloud; Week 1 previews Upstash.
            Source plan limits and version claims are context, not permanent
            service guarantees. Multi-command atomicity, lock ownership and
            persistence require the distinctions explained in the lessons.
          </li>
        </ul>
        <h3>Primary documentation used for technical clarifications</h3>
        <p className="muted">
          These clarify source inconsistencies. They do not add unrelated exam
          requirements.
        </p>
        {references.map(([title, url]) => (
          <a key={url} href={url} target="_blank" rel="noreferrer">
            {title}
            <ExternalLink size={13} />
          </a>
        ))}
      </section>
    </div>
  );
}
