"use client";
import { useState } from "react";
import Link from "next/link";
import { ArrowRight, Search, BookOpen } from "lucide-react";
import { modules, lessons } from "@/content/course";
import { CodeBlock } from "@/components/code-block";
import { ModelComparison } from "@/components/visualizations";
export default function RevisionPage() {
  const [week, setWeek] = useState(0),
    [query, setQuery] = useState("");
  const shown = lessons.filter(
    (l) =>
      (!week || l.week === week) &&
      `${l.title} ${l.concepts.map((c) => c.term).join(" ")}`
        .toLowerCase()
        .includes(query.toLowerCase()),
  );
  return (
    <div className="page revision-page">
      <div className="page-heading">
        <div>
          <span className="eyeline">The essentials, all in one place</span>
          <h1>Quick revision</h1>
          <p>
            Refresh the important ideas. Follow a lesson link when you need the
            full story.
          </p>
        </div>
        <Link className="btn btn-outline" href="/quiz/">
          Test what you remember <ArrowRight size={16} />
        </Link>
      </div>
      <div className="revision-toolbar">
        <div className="week-filter">
          <button aria-pressed={!week} onClick={() => setWeek(0)}>
            All
          </button>
          {modules.map((m) => (
            <button
              key={m.week}
              aria-pressed={week === m.week}
              onClick={() => setWeek(m.week)}
            >
              Week {m.week}
            </button>
          ))}
        </div>
        <label className="search-inline">
          <Search size={16} />
          <input
            aria-label="Filter revision topics"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Find a topic…"
          />
        </label>
      </div>
      {!week && !query && (
        <>
          <ModelComparison />
          <section className="comparison-sheet">
            <h2>Comparisons to remember</h2>
            <div className="table-scroll">
              <table>
                <thead>
                  <tr>
                    <th>Comparison</th>
                    <th>First idea</th>
                    <th>Second idea</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    [
                      "Primary / foreign key",
                      "Unique, non-NULL row identity",
                      "Reference to a permitted parent key",
                    ],
                    [
                      "OLTP / OLAP",
                      "Record operational transactions",
                      "Analyze many historical events",
                    ],
                    [
                      "Row / column storage",
                      "Keep a full record together",
                      "Group same-column values for scans",
                    ],
                    [
                      "Parquet / Delta",
                      "Open columnar file format",
                      "Parquet plus table transaction log",
                    ],
                    [
                      "Embedding / referencing",
                      "Related fields inside one parent",
                      "Links to separate documents",
                    ],
                    [
                      "Replication / sharding",
                      "Copies of the same data",
                      "Different data partitions",
                    ],
                    [
                      "Expiry / eviction",
                      "Remove validity after a time limit",
                      "Remove keys under a memory policy",
                    ],
                    [
                      "RDB / AOF",
                      "Periodic snapshots",
                      "Append-only write record",
                    ],
                    [
                      "Type 1 / Type 2 SCD",
                      "Overwrite description",
                      "Retain dated version rows",
                    ],
                  ].map(([a, b, c]) => (
                    <tr key={a}>
                      <td>{a}</td>
                      <td>{b}</td>
                      <td>{c}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}
      {shown.length ? (
        shown.map((l) => (
          <section className="revision-topic" key={l.id}>
            <div className="section-heading">
              <div>
                <span className="eyeline">Week {l.week}</span>
                <h2>{l.title}</h2>
              </div>
              <Link href={`/lesson/${l.id}/`} className="text-link">
                Full lesson <ArrowRight size={14} />
              </Link>
            </div>
            <ul className="revision-takeaways">
              {l.takeaways.map((t) => (
                <li key={t}>{t}</li>
              ))}
            </ul>
            <details>
              <summary>
                Terms & simple definitions ({l.concepts.length})
              </summary>
              {l.concepts.map((c) => (
                <div className="revision-definition" key={c.term}>
                  <h3>{c.term}</h3>
                  <p>{c.explanation}</p>
                </div>
              ))}
            </details>
            <details>
              <summary>Important commands</summary>
              {l.concepts.some((c) => c.code) ? (
                l.concepts
                  .filter((c) => c.code)
                  .map((c) => (
                    <CodeBlock key={c.term} code={c.code!} label={c.term} />
                  ))
              ) : (
                <p>
                  This is a design/concept lesson; focus on responsibilities and
                  trade-offs.
                </p>
              )}
            </details>
            <div className="exam-mistakes">
              <b>Common exam mistakes</b>
              {l.mistakes.map((m) => (
                <p key={m}>• {m}</p>
              ))}
            </div>
          </section>
        ))
      ) : (
        <p className="empty-state">
          No revision topics match. Try another term or week.
        </p>
      )}
    </div>
  );
}
