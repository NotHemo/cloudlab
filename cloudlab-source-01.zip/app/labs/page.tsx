import { LabWorkspace } from "@/components/lab-workspace";
export default function LabsPage() {
  return <LabWorkspace />;
}
