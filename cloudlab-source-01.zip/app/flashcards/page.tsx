import { FlashcardWorkspace } from "@/components/flashcard-workspace";
export default function FlashcardsPage() {
  return <FlashcardWorkspace />;
}
