import { modules } from "@/content/course";
import { WeekView } from "@/components/week-view";
export function generateStaticParams() {
  return modules.map((m) => ({ week: String(m.week) }));
}
export default async function WeekPage({
  params,
}: {
  params: Promise<{ week: string }>;
}) {
  const { week } = await params;
  return <WeekView week={Number(week)} />;
}
