import type { Lab, LabStep } from "@/lib/types";
const s = (
  title: string,
  instruction: string,
  code: string,
  expected: string,
  hint: string,
  error: string,
  tool?: string,
  optional = false,
): LabStep => ({
  title,
  instruction,
  code: code || undefined,
  expected,
  hint,
  error,
  tool,
  optional,
});
const exportTables: Record<string, string> = {
  customer: "customer_id,first_name,last_name,email",
  staff: "staff_id,first_name,last_name",
  film: "film_id,title,rental_rate,rating",
  inventory: "inventory_id,film_id",
  rental: "rental_id,rental_date,inventory_id,customer_id,staff_id",
  payment: "payment_id,rental_id,customer_id,staff_id,amount,payment_date",
};
export const extractionCode = Object.entries(exportTables)
  .map(
    ([name, cols]) =>
      `\\copy (select ${cols} from ${name}) to '${name}.csv' with csv header`,
  )
  .join("\n");
export const stagingCode = `CREATE TABLE stg_customer AS SELECT CAST(customer_id AS INT) AS customer_id,first_name,last_name,email FROM bronze_customer;
CREATE TABLE stg_staff AS SELECT CAST(staff_id AS INT) AS staff_id,first_name,last_name FROM bronze_staff;
CREATE TABLE stg_film AS SELECT CAST(film_id AS INT) AS film_id,title,CAST(rental_rate AS DOUBLE) AS rental_rate,rating FROM bronze_film;
CREATE TABLE stg_inventory AS SELECT CAST(inventory_id AS INT) AS inventory_id,CAST(film_id AS INT) AS film_id FROM bronze_inventory;
CREATE TABLE stg_rental AS SELECT CAST(rental_id AS INT) AS rental_id,CAST(rental_date AS TIMESTAMP) AS rental_date,CAST(inventory_id AS INT) AS inventory_id,CAST(customer_id AS INT) AS customer_id,CAST(staff_id AS INT) AS staff_id FROM bronze_rental;
CREATE TABLE stg_payment AS SELECT CAST(payment_id AS INT) AS payment_id,CAST(rental_id AS INT) AS rental_id,CAST(customer_id AS INT) AS customer_id,CAST(staff_id AS INT) AS staff_id,CAST(amount AS DOUBLE) AS amount,CAST(payment_date AS TIMESTAMP) AS payment_date FROM bronze_payment;`;
export const dimensionCode = `CREATE TABLE dim_customer AS SELECT * FROM stg_customer;
CREATE TABLE dim_staff AS SELECT * FROM stg_staff;
CREATE TABLE dim_film AS SELECT * FROM stg_film;
CREATE TABLE dim_date AS
SELECT ROW_NUMBER() OVER (ORDER BY full_date) AS date_id,full_date,
 YEAR(full_date) AS year,MONTH(full_date) AS month
FROM (SELECT DISTINCT CAST(rental_date AS DATE) AS full_date FROM stg_rental) d;`;
export const factCode = `CREATE TABLE fact_rental AS
SELECT r.rental_id,r.customer_id,r.staff_id,i.film_id,d.date_id,p.amount
FROM stg_rental r
JOIN stg_inventory i ON r.inventory_id=i.inventory_id
JOIN dim_date d ON CAST(r.rental_date AS DATE)=d.full_date
LEFT JOIN stg_payment p ON p.rental_id=r.rental_id;`;
export const analyticsCode = `-- Revenue and rental count by film
SELECT f.title,COUNT(*) AS times_rented,SUM(fr.amount) AS total_revenue
FROM fact_rental fr JOIN dim_film f ON fr.film_id=f.film_id
GROUP BY f.title ORDER BY total_revenue DESC LIMIT 10;
-- Revenue by staff
SELECT s.first_name,s.last_name,SUM(fr.amount) AS total_revenue
FROM fact_rental fr JOIN dim_staff s ON fr.staff_id=s.staff_id
GROUP BY s.first_name,s.last_name ORDER BY total_revenue DESC;
-- Revenue by rental month
SELECT d.year,d.month,SUM(fr.amount) AS monthly_revenue
FROM fact_rental fr JOIN dim_date d ON fr.date_id=d.date_id
GROUP BY d.year,d.month ORDER BY d.year,d.month;
-- Popularity
SELECT f.title,COUNT(*) AS times_rented
FROM fact_rental fr JOIN dim_film f ON fr.film_id=f.film_id
GROUP BY f.title ORDER BY times_rented DESC LIMIT 10;`;
export const labs: Lab[] = [
  {
    week: 1,
    title: "Get a live database, two ways",
    objectives: [
      "Create a Supabase project and books table.",
      "Use Table Editor and SQL Editor.",
      "Connect pgAdmin and verify shared rows.",
    ],
    prerequisites:
      "Email or GitHub account; permission to install pgAdmin. No previous database experience needed.",
    steps: [
      s(
        "A · Provision it8417-db",
        "Follow the course signup flow at Supabase. Create an organization, choose the intended free plan, name the project it8417-db, save a strong database password privately and choose a nearby region. Wait for provisioning.",
        "",
        "A ready project dashboard. This site cannot create or verify a cloud account.",
        "Keep the database password separate from your Supabase account login.",
        "If a payment prompt appears, inspect the selected plan/add-on before continuing.",
        "Supabase dashboard",
      ),
      s(
        "B1 · Create books in Table Editor",
        "Create books with title (text), published (int4), and an identity primary key id. Insert one row visually. If using SQL instead, run this once.",
        "CREATE TABLE books (id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,title text NOT NULL,published int);",
        "books appears under public.Tables. A row you insert visually appears in a SELECT.",
        "Do not run CREATE TABLE again if the UI already created it.",
        "“relation already exists” means inspect the existing table first; avoid deleting useful work.",
        "SQL",
      ),
      s(
        "B2 · Insert and read from SQL Editor",
        "Run the insert and SELECT. Supabase’s default SQL Editor workflow autocommits.",
        "INSERT INTO books(title,published) VALUES\n ('Notes on the Analytical Engine',1843),\n ('The First Computer Program',1843);\nSELECT * FROM books;",
        "The two new titles are present, plus any earlier UI row. Generated IDs depend on earlier inserts.",
        "Insert only title and published; let the identity column generate id.",
        "Repeated inserts create repeated book rows unless you define an appropriate uniqueness rule.",
        "SQL",
      ),
      s(
        "C1 · Copy one complete connection configuration",
        "Open the project Connect/settings dialog. Choose a supported direct or session-pooler configuration for a persistent desktop client and your network. Copy host, port, database, user and password fields from that same mode.",
        "",
        "All fields belong to the same connection mode. Direct/session commonly use 5432; transaction pooling uses 6543.",
        "The guide mixes a transaction URI and a 5432 label; use the actual displayed mode’s values.",
        "A full postgresql:// URI is not just a host name.",
        "Supabase dashboard",
      ),
      s(
        "C2 · Install and register in pgAdmin",
        "Install the desktop application from pgadmin.org. Set its separate master password. Right-click Servers → Register → Server. General name is a label; Connection uses copied settings. Use the supported TLS/SSL setting.",
        "",
        "The server connects and public.books is visible under postgres → Schemas → public.",
        "For timeout, check endpoint/port/network; for authentication failure, check database credentials.",
        "Do not enter pgAdmin’s master password as the database password.",
        "pgAdmin",
      ),
      s(
        "C3 · Verify the same data in two windows",
        "In pgAdmin open books → View/Edit Data → All Rows, or use Query Tool. Refresh the Supabase table and compare.",
        "SELECT * FROM public.books ORDER BY id;",
        "The same stored rows appear in both clients. Record completion only after checking your own project.",
        "If one view is stale, refresh it; check database and schema.",
        "Two different projects may coincidentally have a books table—check the connection.",
        "SQL",
      ),
    ],
  },
  {
    week: 2,
    title: "Build the relationship",
    objectives: [
      "Design a one-to-many relationship.",
      "Create keys, backfill books and run a JOIN.",
      "Explore the optional DVD Rental sample and its objects.",
    ],
    prerequisites:
      "Week 1 books table and Supabase/pgAdmin connection. Optional Part D needs dvdrental.tar and course Script 04, neither uploaded here.",
    steps: [
      s(
        "A · Sketch the schema",
        "authors has id/name. books has id/title/published/author_id. Put the foreign key on the many side: books.",
        "",
        "One author may have many books. The course’s simplified design assigns at most one author per book.",
        "A book with multiple authors would need a different design, often a bridge table.",
        "Do not copy names into every row as the only relationship.",
        "JOIN",
      ),
      s(
        "B1 · Create and inspect authors",
        "Create the parent table and insert two names. Note your actual generated IDs.",
        "CREATE TABLE authors(id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,name text NOT NULL);\nINSERT INTO authors(name) VALUES ('Ada Lovelace'),('Grace Hopper');\nSELECT * FROM authors;",
        "Two new author records with unique IDs; actual numbers depend on table state.",
        "The SQL playground has a seeded authors table: reset/select it, or use a new table name to practice CREATE.",
        "If it already exists, inspect it rather than creating duplicates.",
        "SQL",
      ),
      s(
        "B2 · Link and backfill books",
        "Run ALTER once in your Week 1 schema. Adjust IDs in UPDATE to match your authors. If the Grace Hopper title was not inserted in Week 1, insert it before updating it.",
        "ALTER TABLE books ADD COLUMN author_id bigint REFERENCES authors(id);\nUPDATE books SET author_id=1 WHERE title IN ('Notes on the Analytical Engine','The First Computer Program');\nUPDATE books SET author_id=2 WHERE title='A Compiler for the A-0 System';\nSELECT * FROM books WHERE author_id IS NULL;",
        "Target books have real author references. Unmatched earlier rows can still be NULL.",
        "UPDATE changing zero rows may simply mean that title does not exist.",
        "An invalid parent ID causes a foreign-key violation; do not disable integrity to hide it.",
        "SQL",
      ),
      s(
        "C · Run the JOIN",
        "Read titles, publication years and author names. Run the same query in pgAdmin if desired.",
        "SELECT b.title,b.published,a.name AS author_name\nFROM books b JOIN authors a ON b.author_id=a.id\nORDER BY b.published;",
        "Each matched book is combined with its author. Unfilled author_id values do not appear in INNER JOIN.",
        "Use the JOIN visualizer to compare INNER and LEFT.",
        "An ON condition using non-unique fields can multiply output rows.",
        "JOIN",
      ),
      s(
        "D1 · Restore dvdrental (recommended)",
        "Obtain the separate course dvdrental.tar. In pgAdmin right-click postgres → Restore, choose Custom/tar, select the archive and start Restore. Refresh public.Tables.",
        "",
        "The guide expects 15 sample tables alongside authors/books; exact results require the actual archive.",
        "Use the Restore option “No owner” if the dump’s original owner role is absent.",
        "Restore against the intended database, not an unrelated project. The archive is not bundled in this site.",
        "pgAdmin",
        true,
      ),
      s(
        "D2 · Test each object type (recommended)",
        "Try a table join, view, sequence, trigger and function. Read actor.last_update before and after UPDATE. Only call rent_film after creating it with the separate Script 04.",
        "SELECT f.title,c.name FROM film f JOIN film_category fc ON f.film_id=fc.film_id JOIN category c ON fc.category_id=c.category_id LIMIT 10;\nSELECT * FROM film_list LIMIT 5;\nSELECT * FROM actor_actor_id_seq;\nSELECT actor_id,first_name,last_update FROM actor WHERE actor_id=1;\nUPDATE actor SET first_name=first_name WHERE actor_id=1;\nSELECT actor_id,first_name,last_update FROM actor WHERE actor_id=1;\nSELECT * FROM film_in_stock(1,1);\n-- Separate Script 04 required:\n-- CALL rent_film(1,2,1);",
        "The trigger should update last_update even when first_name is set to itself. Function results depend on actual inventory.",
        "The guide reports no original procedures; its rent_film is a course addition.",
        "The local mini dataset does not pretend to be the full restored sample or its functions.",
        "pgAdmin",
        true,
      ),
    ],
  },
  {
    week: 3,
    title: "Move some real data",
    objectives: [
      "Export all six source tables to CSV with psql.",
      "Create six bronze tables in Databricks.",
      "Build six typed staging tables and validate them.",
    ],
    prerequisites:
      "Week 2’s real dvdrental restore, pgAdmin Desktop with PSQL Tool, and a Databricks workspace.",
    steps: [
      s(
        "A · Create the workspace and notebook",
        "Use the course Free Edition signup path, verify email, open the workspace and create it8417-warehouse with default language SQL. Check actual account plan and compute availability.",
        "",
        "A notebook ready for interactive cells.",
        "A SQL warehouse and notebook compute are different services.",
        "Do not enter payment details merely because the lesson mentions a plan; check the current product flow.",
        "Databricks",
      ),
      s(
        "B1 · Export all six CSVs",
        "Open the pgAdmin PSQL Tool connected to your restored project. Run each line separately. Change output names to full local paths for a folder you have created if needed.",
        extractionCode,
        "customer.csv, staff.csv, film.csv, inventory.csv, rental.csv and payment.csv with headers. Actual counts come from your restored dataset.",
        "Use \\! cd in the relevant psql shell to inspect its working location, or specify a known absolute path.",
        "\\copy is not accepted by the ordinary SQL Query Tool. File access is on the client.",
        "PSQL Tool",
      ),
      s(
        "B2 · Create six bronze tables",
        "In Databricks use Add/upload data → create/modify table. Import each CSV into bronze_customer, bronze_staff, bronze_film, bronze_inventory, bronze_rental and bronze_payment in your selected catalog/schema.",
        "SELECT * FROM bronze_payment LIMIT 10;",
        "Six queryable raw tables. Inferred column types may vary; inspect them instead of assuming.",
        "Check commas and header detection if all values appear in one column.",
        "A .txt file or wrong delimiter can produce one giant field.",
        "ETL",
      ),
      s(
        "C1 · Transform all six tables",
        "Run the six CTAS statements. The guide uses DOUBLE for amounts/rates; exact financial systems often need an explicit DECIMAL design.",
        stagingCode,
        "Six stg_ tables with numeric IDs and typed rental/payment timestamps. No exact row counts are invented here.",
        "The local PostgreSQL playground uses a compatible teaching dataset; Databricks-specific DOUBLE may need DOUBLE PRECISION in PostgreSQL.",
        "A malformed CAST may fail the query. Tolerant casting may return NULL; neither inherently deletes rows.",
        "ETL",
      ),
      s(
        "C2 · Verify counts, types and values",
        "Compare each bronze/staging pair and inspect conversions. This check covers all six pairs.",
        Object.keys(exportTables)
          .map(
            (t) =>
              `SELECT '${t}' AS entity,(SELECT COUNT(*) FROM bronze_${t}) AS bronze,(SELECT COUNT(*) FROM stg_${t}) AS staging;`,
          )
          .join("\n"),
        "Each no-filter transformation preserves source row count; types and values also pass inspection.",
        "Equal counts are necessary but not sufficient. Inspect unexpected NULLs, invalid IDs and timestamps.",
        "A missing table may be in another catalog/schema; qualify its name.",
        "ETL",
      ),
      s(
        "Checkpoint · Keep your silver tables",
        "Explain Extract vs Transform and \\copy vs COPY in your own words. Save the workspace for Week 4.",
        "",
        "You can point to six raw tables and six typed staging tables and explain their provenance.",
        "Bronze keeps a traceable source; silver prepares a reliable input for gold.",
        "Do not overwrite or discard source files until validation is complete.",
        "ETL",
      ),
    ],
  },
  {
    week: 4,
    title: "Finish the warehouse",
    objectives: [
      "Build four dimensions and a rental-grain fact.",
      "Answer all four analytical questions.",
      "Inspect Delta/Parquet, SCD history and optional Genie querying.",
    ],
    prerequisites:
      "All six Week 3 staging tables. Plain Parquet creation is restricted in the free setup described by the guide.",
    steps: [
      s(
        "A1 · Build dimensions",
        "Copy the three clean entity dimensions and derive distinct rental dates with a surrogate date_id. Databricks SQL below uses YEAR and MONTH.",
        dimensionCode,
        "dim_customer, dim_staff, dim_film and dim_date; each day appears once.",
        "The local SQL playground is PostgreSQL: use EXTRACT(YEAR FROM full_date) and EXTRACT(MONTH FROM full_date).",
        "Do not rebuild date IDs independently of fact_rental; new ROW_NUMBER mappings can invalidate old keys.",
        "Star schema",
      ),
      s(
        "A2 · Check join cardinality before the fact",
        "Check duplicate payments and inventory keys before assuming one output per rental.",
        "SELECT rental_id,COUNT(*) FROM stg_payment GROUP BY rental_id HAVING COUNT(*)>1;\nSELECT inventory_id,COUNT(*) FROM stg_inventory GROUP BY inventory_id HAVING COUNT(*)>1;",
        "Any repeated match key is investigated. Empty results mean none were found in your data.",
        "If payments are multiple per rental, aggregate amount by rental_id before the fact join.",
        "LEFT JOIN preserves rows but does not prevent one-to-many multiplication.",
        "SQL",
      ),
      s(
        "A3 · Load and validate fact_rental",
        "Use the source join path. If cardinality checks found multiple payments, replace p with a subquery grouped by rental_id. Validate rental IDs, missing lookups and NULL amounts.",
        factCode +
          "\nSELECT COUNT(*),COUNT(DISTINCT rental_id) FROM fact_rental;\nSELECT COUNT(*) FROM stg_rental;\nSELECT COUNT(*) FROM fact_rental WHERE amount IS NULL;",
        "At the intended grain, every rental occurs once. NULL amounts identify unmatched payments; their actual count is dataset-dependent.",
        "Check p.rental_id=r.rental_id and the rental_date-to-full_date cast.",
        "INNER JOINs can drop rentals if inventory/date lookups are incomplete.",
        "Star schema",
      ),
      s(
        "B · Answer all four business questions",
        "Run revenue by film, revenue by staff, revenue by rental year/month, and most-rented films. Explain why the two film rankings can differ.",
        analyticsCode,
        "Aggregated results from your own warehouse; no fabricated real-dataset rankings.",
        "The SQL playground has a small clearly labeled teaching warehouse you can query.",
        "GROUP BY needs the chosen descriptive fields. Month alone merges years.",
        "SQL",
      ),
      s(
        "C · Inspect Delta and the Parquet limitation",
        "Inspect metadata. The original guide explicitly says plain Parquet creation and comparison do not run in its free setup because external storage is needed. Treat the following export as environment-dependent.",
        "DESCRIBE DETAIL fact_rental;\n-- Only where supported:\nCREATE TABLE fact_rental_parquet USING PARQUET AS SELECT * FROM fact_rental;\nDESCRIBE DETAIL fact_rental_parquet;",
        "Inspect the actual reported format. A restricted export is recorded as unavailable, not marked as a successful cloud execution.",
        "Use Storage Comparison for a browser illustration. It does not create a Parquet file.",
        "DESCRIBE DETAIL and USING PARQUET are not PostgreSQL playground commands.",
        "Storage comparison",
      ),
      s(
        "D1 · Observe a Type 1 overwrite (optional)",
        "View customer 1’s rental history and surname. Change staging surname to Al-Rashid, rebuild dim_customer and query again.",
        "UPDATE stg_customer SET last_name='Al-Rashid' WHERE customer_id=1;\nCREATE OR REPLACE TABLE dim_customer AS SELECT * FROM stg_customer;\nSELECT fr.rental_id,c.last_name FROM fact_rental fr\nJOIN dim_customer c ON fr.customer_id=c.customer_id WHERE c.customer_id=1;",
        "All those rentals show the current surname; this design did not retain the prior version.",
        "Use a disposable copy if you need to preserve your real coursework state.",
        "Replacing the dimension is an intentional overwrite. It cannot reconstruct absent history.",
        "SCD explorer",
        true,
      ),
      s(
        "D2 · Build a Type 2 teaching dimension (optional)",
        "Use a fresh teaching table. This Delta-oriented version avoids the guide’s unbound email in VALUES. A real historical implementation needs a justified initial validity date and event-time fact-key resolution.",
        "CREATE TABLE dim_customer_scd2 (\n customer_key BIGINT GENERATED ALWAYS AS IDENTITY,\n customer_id INT,first_name STRING,last_name STRING,email STRING,\n valid_from TIMESTAMP,valid_to TIMESTAMP,is_current BOOLEAN\n) USING DELTA;\nINSERT INTO dim_customer_scd2 (customer_id,first_name,last_name,email,valid_from,valid_to,is_current)\nSELECT customer_id,first_name,last_name,email,TIMESTAMP '2000-01-01 00:00:00',NULL,TRUE FROM stg_customer;\n-- Teaching change instant only; use the actual business-effective time in practice.\nUPDATE dim_customer_scd2 SET valid_to=TIMESTAMP '2026-04-01 00:00:00',is_current=FALSE\n WHERE customer_id=1 AND is_current=TRUE;\nINSERT INTO dim_customer_scd2 (customer_id,first_name,last_name,email,valid_from,valid_to,is_current)\nSELECT customer_id,first_name,'Al-Rashid-Smith',email,TIMESTAMP '2026-04-01 00:00:00',NULL,TRUE\nFROM stg_customer WHERE customer_id=1;",
        "Two versions for customer 1. A real load assigns each rental to the version valid on its rental_date. The dates here are explicitly teaching assumptions.",
        "Delta primary/foreign key metadata is informational where supported; validate uniqueness and non-overlapping intervals yourself.",
        "Creating two versions does not fix the existing fact table’s customer_id-only join.",
        "SCD explorer",
        true,
      ),
      s(
        "E · Optional Genie inquiry",
        "Create a Genie space/agent from the fact and four dimensions. Add business definitions, attach supported SQL Warehouse compute, ask a question and inspect its generated SQL. Specify a month in the actual dataset.",
        "",
        "A real query/result or a clarifying question, depending on the available workspace and prompt.",
        "Compare the generated revenue query with your hand-written SQL.",
        "No paid model API is used by this site, and no local panel pretends to be a real Genie service.",
        "Databricks Genie",
        true,
      ),
    ],
  },
  {
    week: 5,
    title: "Put MongoDB through its paces",
    objectives: [
      "Set up Atlas and connect from Compass and mongosh.",
      "Practice CRUD, nested/array queries, search and aggregation.",
      "Study replication, sharding and backup/restore.",
    ],
    prerequisites:
      "Email for signup and permission to install Compass, mongosh and Database Tools. Eight referenced course scripts were not supplied; all guide instructions remain available in Sources.",
    steps: [
      s(
        "A · Create and secure a cluster",
        "Create the course Atlas project it8417-mongo and intended free cluster option. Choose a nearby region, create a database user and add only the necessary current IP through Network Access.",
        "",
        "An available cluster and a permitted database user/IP. Check current plan terms in Atlas.",
        "An Atlas account login and a database user serve different purposes.",
        "A valid password cannot override a blocked IP. Do not paste real credentials into this site.",
        "MongoDB Atlas",
      ),
      s(
        "B1 · Connect two clients",
        "Install Compass and mongosh. Copy each connection from Atlas’s Connect dialog, substitute values privately, then connect. The password-prompt form avoids embedding a password in the command shown here.",
        'mongosh "mongodb+srv://YOUR_CLUSTER/" --username YOUR_DB_USER',
        "The same cluster is accessible through the GUI and shell.",
        "Use the actual database username and account-specific endpoint.",
        "The guide contains example node URIs with password-looking values. Do not reuse them.",
        "OS terminal",
      ),
      s(
        "B2 · CRUD and write scope",
        "Create a small teaching customers collection. Practice insertOne/insertMany, updateOne/updateMany, $set/$inc/$mul/$rename, replaceOne, upsert, bulkWrite and deleteOne/deleteMany. Preview filters first.",
        'use it8417_bank\ndb.customers.insertMany([{first_name:"Ahmed",age:30},{first_name:"Mariam",age:28}])\ndb.customers.updateOne({first_name:"Ahmed"},{$set:{gender:"male",age:45}})\ndb.customers.updateMany({age:{$gte:18}},{$inc:{visits:1}})\ndb.customers.updateOne({first_name:"Yousef"},{$set:{age:21}},{upsert:true})\ndb.customers.find({})',
        "Write counts reflect your actual matches; find shows the changed records.",
        "deleteMany({}) has no filter restriction; keep destructive practice to disposable data.",
        "Replacing a document is different from updating a few fields with $set.",
        "MongoDB",
      ),
      s(
        "C · Nested objects, arrays and precise filters",
        "Add Hassan’s embedded address and accounts. Update a dot path. Use $elemMatch, projection, sort/limit/skip, $eq/$gt/$gte/$in/$nin/$ne, $and/$or/$not, $all/$size, $expr and regex.",
        'db.customers.insertOne({first_name:"Hassan",last_name:"Abdullah",address:{street:"82 Al Fateh Street",city:"Manama",country:"Bahrain"},account:[{account_id:"1234",currency:"USD",balance:123.45},{account_id:"4321",currency:"GEL",balance:1000}]})\ndb.customers.updateOne({last_name:"Abdullah"},{$set:{"address.street":"New St 5"}})\ndb.customers.find({account:{$elemMatch:{currency:"USD",balance:{$gte:100}}}},{_id:0,first_name:1}).limit(5)',
        "Hassan matches because one USD account has balance at least 100. Projection does not change stored fields.",
        "Require conditions on the same element with $elemMatch.",
        "Independent array conditions may match different account elements.",
        "MongoDB",
      ),
      s(
        "D · Text index before text search",
        "Create a tiny teaching articles dataset, then build the text index and query with textScore. The simulator demonstrates basic token matching, not MongoDB’s real ranking implementation.",
        'db.articles.insertMany([{subject:"coffee and databases",author:"Mariam"},{subject:"tea in Manama",author:"Ahmed"}])\ndb.articles.createIndex({subject:"text",author:"text"})\ndb.articles.find({$text:{$search:"coffee"}},{score:{$meta:"textScore"}}).sort({score:{$meta:"textScore"}})',
        "The coffee article matches; actual scores are engine-dependent.",
        "Build the index before using $text.",
        "The Atlas Search $search pipeline stage is a different feature from $text’s $search expression.",
        "MongoDB",
      ),
      s(
        "E · Group and unwind",
        "Practice purchase-order totals and account balances by currency. Also use distinct() and countDocuments() when a full pipeline is unnecessary.",
        'db.purchase_orders.aggregate([{$match:{}},{$group:{_id:"$product",total:{$sum:"$total"}}},{$sort:{total:-1}}])\ndb.customers.aggregate([{$unwind:"$account"},{$group:{_id:"$account.currency",sum_balance:{$sum:"$account.balance"}}}])\ndb.customers.countDocuments({})\ndb.customers.distinct("first_name")',
        "Pipeline rows change shape after grouping. Exact totals depend on the current collection.",
        "Inspect each stage’s output before adding the next one.",
        "A $group _id expression is the grouping key, not automatically a source ObjectId.",
        "MongoDB",
      ),
      s(
        "F · Materialize and join",
        "Practice terminal $out and $merge. Run a left lookup, an inner pattern filtering non-empty arrays, and reverse the starting collection for a right-preserving pattern. getSiblingDB chooses a database handle; it is not an automatic cross-database join.",
        'db.purchase_orders.aggregate([{$group:{_id:"$product",total:{$sum:"$total"}}},{$out:"product_totals"}])\ndb.salaries.aggregate([{$group:{_id:{year:"$fiscal_year",dept:"$dept"},salaries:{$sum:"$salary"}}},{$merge:{into:"budgets",on:"_id",whenMatched:"replace",whenNotMatched:"insert"}}])\ndb.clients.aggregate([{$lookup:{from:"orders",localField:"_id",foreignField:"user_id",as:"user_orders"}}])\ndb.orders.aggregate([{$lookup:{from:"clients",localField:"user_id",foreignField:"_id",as:"client"}},{$unwind:{path:"$client",preserveNullAndEmptyArrays:true}}])',
        "Saved report collections and joined arrays. The reverse lookup keeps all orders even without a matching client.",
        "Use the local MongoDB playground’s examples and editable JSON inputs for safe practice.",
        "Do not put more processing stages after $out/$merge.",
        "MongoDB",
      ),
      s(
        "G1 · Observe replication, study sharding",
        "Run the allowed replica status command or inspect Atlas monitoring. The course expects a primary and two secondaries. Study mongos/config servers/shards without claiming to deploy a free sharded cluster.",
        "rs.status().members.map(m=>({name:m.name,state:m.stateStr}))",
        "Real status depends on your cluster and permissions. Local replica administration is reference-only for this managed lab.",
        "Atlas owns membership; do not run rs.initiate or rs.add against the managed service.",
        "An arbiter votes but has no data. Replication is not sharding.",
        "mongosh",
      ),
      s(
        "G2 · Back up and restore in the OS terminal",
        "Install Database Tools. Back up the collection, verify the BSON file and restore deliberately. Cloud-managed snapshots are a separate plan-dependent feature.",
        'mongodump --uri "mongodb+srv://USER@CLUSTER/" --db it8417_bank --collection customers --out ./backups\nmongorestore --uri "mongodb+srv://USER@CLUSTER/" -d it8417_bank -c customers ./backups/it8417_bank/customers.bson',
        "A usable local backup and a checked restore. Credentials and outputs are never invented by the learning site.",
        "Use a separate test destination if you want to verify recovery without touching your live practice collection.",
        "These are OS commands, not mongosh or SQL statements.",
        "OS terminal",
      ),
    ],
  },
  {
    week: 6,
    title: "Redis, from PING to persistence",
    objectives: [
      "Connect with CLI, Insight and code.",
      "Exercise five core types, expiry and temporary-data use cases.",
      "Edit/search JSON and justify recovery choices.",
    ],
    prerequisites:
      "Email for Redis Cloud; redis-cli through WSL/lab machine on Windows, plus Insight. Five referenced scripts are not among the uploaded files.",
    steps: [
      s(
        "A · Create the database",
        "Use the course signup path, name it it8417-redis, select a version/features supporting JSON and Query Engine, choose the nearest region and wait for ready status. Locate host, database-specific port, default username and password.",
        "",
        "A real cloud endpoint. The course quotes 30 MB/30 connections/100 ops/s; actual current terms come from your account.",
        "Use disposable data and a unique password.",
        "Do not assume port 6379 for Redis Cloud.",
        "Redis Cloud",
      ),
      s(
        "B1 · CLI and Insight",
        "Install redis-cli with the course’s OS-specific instructions: brew install redis (macOS), apt install redis-tools (Ubuntu/WSL), or use a lab machine. Connect using actual host/port and password prompt; add the same database in Insight.",
        'redis-cli -h YOUR_HOST -p YOUR_PORT --user default --askpass\nPING\nPING "hello"',
        "PONG, then hello. Insight displays the same keyspace.",
        "Use TLS options if required by the actual provider configuration.",
        "For NOAUTH/WRONGPASS check the username and copied password; for timeout inspect host/port/network.",
        "OS terminal",
      ),
      s(
        "B2 · Connect from Node.js",
        "Install ioredis in your separate lab project and run a client using environment variables. The code below is a runnable async wrapper; add provider-required TLS settings.",
        'const Redis = require("ioredis");\n(async()=>{\n const client=new Redis({host:process.env.REDIS_HOST,port:Number(process.env.REDIS_PORT),password:process.env.REDIS_PASSWORD});\n try { console.log(await client.ping()); await client.set("course","Big Data","EX",60); console.log(await client.get("course")); }\n finally { await client.quit(); }\n})().catch(console.error);',
        "PONG and Big Data, with a 60-second expiring key. These execute only when you run the external client.",
        "JavaScript is the language, Node.js the runtime, ioredis the client library.",
        "Do not put a real password in a submitted file.",
        "Node.js",
      ),
      s(
        "C · Basic keys, NX, counters and scanning",
        "Predict each reply, then execute. Compare KEYS to incremental SCAN on this tiny dataset; use SCAN for scale. Measure real network latency separately with redis-cli --latency and stop it with Ctrl-C.",
        'SET customer:ahmed:name "Ahmed Al-Sayed"\nGET customer:ahmed:name\nINCR customer:ahmed:balance\nSET username:ahmed_alsayed "taken" NX\nSCAN 0 MATCH customer:* COUNT 100',
        "SET usually replies OK; a new counter replies 1; repeated NX on an existing key returns nil.",
        "COUNT is a scan work hint. Continue with the returned cursor until 0.",
        "Do not run unbounded request loops against a throttled free database.",
        "Redis",
      ),
      s(
        "D1 · All five core types",
        "Create a string, hash, list, set and sorted set. Check each TYPE and inspect them in Insight.",
        'SET course IT8417\nHSET customer:khalid name "Khalid Al-Amin" city Riffa tier gold\nRPUSH session:khalid:recent_pages home catalog cart\nSADD visitors:mon ahmed yousef\nSADD visitors:tue yousef omar\nSINTER visitors:mon visitors:tue\nZADD leaderboard:week06 420 ahmed 500 yousef 275 omar\nZREVRANGE leaderboard:week06 0 2 WITHSCORES\nZINCRBY leaderboard:week06 100 ahmed\nZRANK leaderboard:week06 ahmed\nTYPE customer:khalid',
        "The visitor intersection contains yousef. Highest-first scores initially put yousef before ahmed and omar.",
        "ZRANK is ascending and zero-based; score updates can change rank.",
        "WRONGTYPE means the key holds another kind of value.",
        "Redis",
      ),
      s(
        "D2 · Encodings and optional extras",
        "Try OBJECT ENCODING when permitted. Review bitmap, HyperLogLog, geospatial and stream examples in the lesson; their low-level implementation is overview material.",
        "OBJECT ENCODING customer:khalid\n-- Optional real Redis examples:\nSETBIT attendance 7 1\nPFADD unique:visitors ahmed yousef\nPFCOUNT unique:visitors\nGEOADD places 50.586 26.223 Manama\nXADD events * kind login user ahmed",
        "Encoding may be compact (for example listpack) or restricted by the service. Extras are real-service reference examples, not all implemented locally.",
        "HyperLogLog is an approximate distinct counter.",
        "If OBJECT is refused, record the managed-service restriction.",
        "Redis Cloud",
        true,
      ),
      s(
        "E1 · Watch expiry and SET behavior",
        "Set a 10-second value, inspect TTL, wait and read again. Repeat with PTTL, PERSIST and SET KEEPTTL. Then demonstrate that plain SET clears expiry.",
        'SET demo:flash_sale "live now" EX 10\nGET demo:flash_sale\nTTL demo:flash_sale\n-- Wait at least ten seconds, then GET again.\nGET demo:flash_sale\nSET demo:ttl keep EX 60\nSET demo:ttl changed KEEPTTL\nTTL demo:ttl\nSET demo:ttl permanent\nTTL demo:ttl',
        "After expiry GET returns nil and TTL returns -2. After plain SET on demo:ttl, TTL is -1.",
        "The local Redis simulator uses real elapsed browser time.",
        "PERSIST removes TTL, not the value.",
        "Redis",
      ),
      s(
        "E2 · Six temporary-data uses",
        "Exercise an OTP, single-use reset token, sliding session, cached API response, cart and lock. Use teaching values only.",
        'SET otp:login:omar "482915" EX 300\nSET reset:token:demo "user:nasser" EX 900\nGETDEL reset:token:demo\nGETDEL reset:token:demo\nHSET session:nasser user_id nasser\nEXPIRE session:nasser 1800\nSET cache:api:exchange_rate:BHD_USD "demo-value" EX 60\nHSET cart:yousef sku:1001 2\nHINCRBY cart:yousef sku:1001 1\nEXPIRE cart:yousef 604800\nSET lock:invoice:8841 "unique-worker-token" NX EX 30',
        "GETDEL succeeds once then returns nil; cart quantity becomes 3; a second lock NX fails while the first exists.",
        "A real lock needs safe owner-checked release. A correct rate limiter needs atomic counter/expiry behavior.",
        "Do not treat a bare DEL as safe release after your lock could have expired.",
        "Redis",
      ),
      s(
        "F · JSON and indexed search (optional)",
        "Compare plain-string JSON with native JSON commands. Create an index before search. Search for the current city after editing it.",
        'JSON.SET customer:json:ahmed $ \'{"name":"Ahmed Al-Sayed","city":"Manama","orders":[{"id":1,"total":120.5}]}\'\nJSON.GET customer:json:ahmed $.city\nJSON.SET customer:json:ahmed $.city \'"Muharraq"\'\nJSON.NUMINCRBY customer:json:ahmed $.orders[0].total 10\nFT.CREATE idx:customers ON JSON PREFIX 1 customer:json: SCHEMA $.name AS name TEXT $.city AS city TAG\nFT.SEARCH idx:customers "@city:{Muharraq}"',
        'The first city read is ["Manama"]. After editing it, the document matches Muharraq and its order total is 130.5.',
        "The simulator supports a documented teaching subset of JSONPath/TAG search, not the whole engine.",
        "Unknown commands can mean unavailable features/version; check your deployment rather than assuming all older versions lack modules.",
        "Redis",
        true,
      ),
      s(
        "G · Inspect persistence and justify choices",
        "Inspect permitted metadata, then write one sentence each for pure API cache, sessions and a valued leaderboard. State acceptable data loss; there is no universal one-word answer.",
        "INFO persistence\nINFO memory\nDBSIZE\nCONFIG GET appendonly",
        "A reasoned choice: disposable cache can rebuild; session loss may require login; valuable state needs a stronger recovery plan.",
        "RDB can lose changes after a snapshot; AOF everysec can risk roughly one second.",
        "CONFIG may be restricted by the provider; persistence is distinct from backups and replication.",
        "Redis Cloud",
      ),
    ],
  },
];
