import type { Question, Difficulty, QuestionType } from "@/lib/types";
import { lessons } from "./course";
const bank: Question[] = [];
function q(
  lessonId: string,
  prompt: string,
  answer: string,
  distractors: [string, string][],
  difficulty: Difficulty = "Easy",
  type: QuestionType = "Multiple choice",
  code?: string,
) {
  const l = lessons.find((l) => l.id === lessonId)!;
  bank.push({
    id: `${lessonId}-${bank.filter((x) => x.lessonId === lessonId).length + 1}`,
    lessonId,
    week: l.week,
    prompt,
    answer,
    options: [answer, ...distractors.map((d) => d[0])],
    wrong: Object.fromEntries(distractors),
    explanation: distractors.length
      ? `The correct answer is “${answer}”. ${explain[lessonId] || l.takeaways[0]}`
      : l.takeaways[0],
    difficulty,
    type,
    code,
  });
}
const explain: Record<string, string> = {
  "cloud-basics":
    "The database runs on the remote server; pgAdmin is only a client.",
  "service-models":
    "DBaaS manages the database engine; IaaS gives you infrastructure to manage it yourself.",
  "postgres-supabase":
    "Supabase provides a managed platform around the PostgreSQL engine.",
  "connection-security":
    "Authentication, network access and encryption are separate parts of a connection.",
  "first-project":
    "Both tools can read and write one shared PostgreSQL database.",
  "keys-integrity":
    "Keys enforce identity and valid references; a nullable foreign key can still be NULL.",
  "sql-joins":
    "INNER JOIN keeps matching pairs; LEFT JOIN also retains unmatched left rows.",
  "etl-extract":
    "\\copy writes through the psql client; SQL COPY with a filename acts on the server.",
  "load-star":
    "The event grain must survive the joins without dropped or multiplied rentals.",
  "ttl-temporary":
    "TTL -1 means no expiry; -2 means no key. Plain SET clears expiry unless KEEPTTL is used.",
  "relational-model":
    "A cluster hosts databases; each database contains schemas, and schemas contain tables and other objects. Roles and schemas are independent.",
  "types-constraints":
    "numeric represents exact decimals. NOT NULL requires a value; UNIQUE alone does not forbid NULL under PostgreSQL’s default behavior.",
  "evolve-schema":
    "Backfilling populates fields for existing rows. SQL uses IS NULL to test a missing value, because ordinary equality with NULL does not return true.",
  dvdrental:
    "film_in_stock is called as a function with SELECT. The rent_film procedure is a separate course addition. A dump may name an owner role that your managed server does not have.",
  "oltp-olap":
    "OLAP summarizes many events over time; OLTP records individual business transactions. Time-variant means keeping data needed for historical comparisons.",
  "lake-warehouse":
    "A lake commonly applies structure when reading raw data. Bronze retains raw inputs, silver contains clean typed staging data, and gold exposes the analytical model.",
  "databricks-compute":
    "A SQL Warehouse is specialized SQL/BI compute. A notebook’s language controls syntax, while its compute resources run the code.",
  "staging-transform":
    "CAST converts an expression’s type; it is not a row filter. Equal counts do not prove correct values: check types, errors and unexpected NULLs too.",
  "columnar-storage":
    "Columnar layout groups values by column. Analytical scans can skip unused columns, and neighboring same-type values often compress well.",
  "parquet-delta":
    "Delta tracks table state through a transaction log over Parquet data. Plain Parquet has no Delta log, and the original free-setup lab notes a restriction on its export steps.",
  "grain-star":
    "Grain declares exactly what one fact row represents. Here it is one rental event; dimensions describe that event and measures quantify it.",
  "analytical-sql":
    "Grouping by both year and month keeps January in different years separate. Rental counts measure popularity, while payment amounts measure revenue.",
  "slowly-changing":
    "Type 1 overwrites; Type 2 stores separate dated versions; Type 3 keeps limited previous values. Historical facts must resolve to the correct Type 2 version.",
  genie:
    "Grounding uses permitted real metadata/data, but SQL and assumptions still need review. An old sample may have no records in the current month, so a precise date range helps.",
  "nosql-models":
    "MongoDB uses documents. Wide-column stores and analytical columnar engines have different models and access patterns, despite both using the word column.",
  "documents-bson":
    "BSON is MongoDB’s binary document format and adds types such as ObjectId and dates. In the basic shell workflow, a database/collection is created on its first write.",
  "embed-reference":
    "Embed bounded owned data often read together. Reference data that grows without bound or is shared. A dot-path $set updates that nested field, not the whole document.",
  "mongo-crud":
    "The One/Many method name controls write scope. An upsert updates a match or inserts when no match exists; uniqueness needs its own suitable rule.",
  "mongo-queries":
    "$elemMatch binds all its conditions to one array element. Projection selects returned fields and does not remove them from stored documents.",
  "indexes-search":
    "A MongoDB $text query needs a text index first. Indexes improve suitable reads but occupy storage and require maintenance during writes.",
  aggregation:
    "Stages transform the prior stage’s output. $unwind expands arrays, $lookup attaches matching arrays while preserving inputs, and $out/$merge terminate by writing results.",
  "atlas-operations":
    "Replication copies the same data for availability; sharding partitions data. mongodump is an operating-system command-line tool, separate from mongosh.",
  performance:
    "Latency is time for one operation; throughput is operations per unit time. Network distance can cost more than the in-memory lookup itself.",
  "cache-aside":
    "Average cost is the weighted cost of hits and misses: .95×.5 + .05×4 = .675 ms in the example. A changed source value can make a cached copy stale, so invalidate or refresh it.",
  "redis-architecture":
    "Redis commands have costs determined by their data structures and output size. Pipelining reduces network round trips but does not make several commands an atomic transaction.",
  "redis-strings":
    "INCR on a missing key creates the counter at 1. SCAN iterates with a cursor; KEYS scans the keyspace in one potentially blocking operation.",
  "redis-structures":
    "A set contains unique members. A sorted set associates members with numeric scores; ZREVRANGE reads highest-first and ZRANK is ascending and zero-based.",
  sessions:
    "A shared session store lets any app server read the same login state. Refreshing EXPIRE after activity creates a sliding inactivity window.",
  "redis-json":
    'Native JSONPath reads can return an array of matches, such as ["Manama"]. Redis Search uses an index created with FT.CREATE before FT.SEARCH.',
  persistence:
    "RDB saves periodic snapshots; AOF logs writes. Persistence supports recovery after restart, while normal reads and writes still use memory.",
  "redis-cloud":
    "Redis Cloud assigns a database-specific endpoint and port. ioredis is the Node.js client library that sends commands to Redis.",
};
q(
  "cloud-basics",
  "You close pgAdmin. What happens to your Supabase database?",
  "It keeps running remotely",
  [
    ["It is deleted", "Closing a client does not delete server data."],
    ["It becomes a local file", "The server is still hosted remotely."],
  ],
);
q(
  "cloud-basics",
  "Who still chooses who may access your managed database?",
  "You, through users and permissions",
  [
    ["Nobody; cloud data is public", "Hosting does not imply public access."],
    [
      "Only the laptop manufacturer",
      "Device hardware does not define database access.",
    ],
  ],
  "Medium",
  "Scenario",
);
q(
  "service-models",
  "You install PostgreSQL on a rented VM. Which service model describes the VM?",
  "IaaS",
  [
    ["DBaaS", "You are still installing and maintaining the engine."],
    [
      "PaaS application runtime",
      "The example gives a VM, not a managed application runtime.",
    ],
  ],
);
q(
  "service-models",
  "A provider adds capacity during a demand spike. What is this?",
  "Elasticity",
  [
    ["Referential integrity", "That validates relationships between records."],
    [
      "Multi-tenancy",
      "That describes shared infrastructure and tenant isolation.",
    ],
  ],
);
q(
  "postgres-supabase",
  "Which component actually executes PostgreSQL SQL?",
  "The PostgreSQL engine",
  [
    ["The pgAdmin master password", "A password is not an execution engine."],
    [
      "The Table Editor grid itself",
      "The grid sends requests to the underlying engine.",
    ],
  ],
);
q(
  "postgres-supabase",
  "What does NOT NULL require for title?",
  "A non-NULL value",
  [
    ["A unique title", "NOT NULL does not impose uniqueness."],
    ["Exactly 10 characters", "text has no such fixed-length limit."],
  ],
  "Easy",
  "Code interpretation",
  "title text NOT NULL",
);
q(
  "connection-security",
  "Which port is Supabase’s transaction pooler normally shown with?",
  "6543",
  [
    [
      "5432 for every mode",
      "5432 is direct/session pooling; do not mix modes.",
    ],
    ["6379", "That is Redis’s conventional local port."],
  ],
);
q(
  "connection-security",
  "The password is correct but your Atlas IP is not allowed. Can it still block connection?",
  "True",
  [["False", "A network allowlist is checked separately from authentication."]],
  "Medium",
  "True / false",
);
q(
  "first-project",
  "A nearby region usually helps reduce which cost?",
  "Network latency",
  [
    ["SQL column count", "Region does not change the table schema."],
    [
      "Primary-key uniqueness",
      "A constraint, not geography, enforces uniqueness.",
    ],
  ],
);
q(
  "first-project",
  "Do you use pgAdmin’s master password to authenticate to Supabase PostgreSQL?",
  "False",
  [
    [
      "True",
      "The database password is separate; the master password protects pgAdmin.",
    ],
  ],
  "Easy",
  "True / false",
);
q(
  "relational-model",
  "Which PostgreSQL hierarchy is correct?",
  "Cluster → database → schema → table",
  [
    [
      "Table → cluster → schema → database",
      "A table is an object inside a schema.",
    ],
    [
      "Role → row → database",
      "Roles are identities, not containers of database rows.",
    ],
  ],
);
q(
  "relational-model",
  "In PostgreSQL, a schema is always the same object as a user.",
  "False",
  [
    [
      "True",
      "Schemas and roles are independent, unlike the common Oracle association.",
    ],
  ],
  "Medium",
  "True / false",
);
q(
  "keys-integrity",
  "Which property is guaranteed by a primary key?",
  "Unique and non-NULL row identity",
  [
    ["Every name is unique", "Only the key columns are constrained."],
    [
      "All rows have an author",
      "A primary key does not require an unrelated foreign key.",
    ],
  ],
);
q(
  "keys-integrity",
  "A nullable author_id REFERENCES authors(id) is set to a nonexistent ID. What happens?",
  "The write is rejected",
  [
    [
      "An author is created automatically",
      "Foreign keys do not create parent records.",
    ],
    [
      "The ID is silently changed to NULL",
      "PostgreSQL rejects the invalid reference.",
    ],
  ],
  "Medium",
  "Predict the output",
);
q(
  "types-constraints",
  "Choose a type for exact decimal money in PostgreSQL.",
  "numeric",
  [
    ["boolean", "Boolean holds true/false."],
    [
      "float for guaranteed exact cents",
      "Binary floating point can introduce representation errors.",
    ],
  ],
);
q(
  "types-constraints",
  "UNIQUE alone always forbids NULL in PostgreSQL.",
  "False",
  [
    [
      "True",
      "Add NOT NULL when a value is required; default uniqueness permits NULLs.",
    ],
  ],
  "Medium",
  "True / false",
);
q(
  "evolve-schema",
  "After adding a nullable author_id, how do you find unfilled rows?",
  "WHERE author_id IS NULL",
  [
    ["WHERE author_id = NULL", "Equality with NULL is not true; use IS NULL."],
    ["WHERE author_id = 0", "Zero is a value, not the missing-value marker."],
  ],
  "Medium",
  "Code interpretation",
);
q(
  "evolve-schema",
  "What is backfilling?",
  "Populating new fields for existing records",
  [
    ["Dropping the old table", "Backfilling retains existing rows."],
    [
      "Creating an automatic backup",
      "It is a data-population task, not backup.",
    ],
  ],
);
q(
  "sql-joins",
  "A book has author_id NULL. What does an INNER JOIN to authors return for it?",
  "No output row",
  [
    ["One row with author name NULL", "That describes an unmatched LEFT JOIN."],
    ["Every author row", "NULL does not match each ID."],
  ],
  "Medium",
  "Predict the output",
);
q(
  "sql-joins",
  "One left row matches three right rows. How many output rows can LEFT JOIN produce for it?",
  "3",
  [
    [
      "1",
      "LEFT JOIN preserves left rows but does not collapse multiple matches.",
    ],
    ["0", "Matching rows are returned."],
  ],
  "Hard",
  "Predict the output",
);
q(
  "dvdrental",
  "Which original sample object is queried with SELECT and returns inventory availability?",
  "film_in_stock function",
  [
    [
      "rent_film original procedure",
      "rent_film is a course addition requiring Script 04.",
    ],
    ["A cloud project password", "Credentials are not database functions."],
  ],
);
q(
  "dvdrental",
  "Why might a restored dump need “No owner”?",
  "The dump references a role absent from your server",
  [
    [
      "The table has no primary key",
      "Restore ownership and table keys are different issues.",
    ],
    [
      "All restore tools need paid accounts",
      "The error concerns roles, not payment.",
    ],
  ],
  "Medium",
  "Scenario",
);
q("oltp-olap", "Which task is OLAP?", "Revenue by month across several years", [
  ["Change one customer email", "This is an operational update."],
  ["Insert one new rental", "This records a transaction."],
]);
q(
  "oltp-olap",
  "A warehouse keeps prior periods for comparisons. Which property is this?",
  "Time-variant",
  [
    [
      "Integrated",
      "Integration concerns consistent data from different sources.",
    ],
    ["Subject-oriented", "That concerns organization by business subject."],
  ],
);
q(
  "lake-warehouse",
  "When is schema commonly applied in a raw data lake?",
  "On read",
  [
    [
      "Only by a primary key",
      "A primary key is not a schema-on-read mechanism.",
    ],
    ["Never, even in analysis", "Analysis still needs structure and meaning."],
  ],
);
q(
  "lake-warehouse",
  "In the course pipeline, stg_rental belongs to which layer?",
  "Silver",
  [
    ["Bronze", "Bronze holds the raw uploaded source."],
    ["Gold", "Gold contains the final dimensions and fact."],
  ],
);
q(
  "etl-extract",
  "Which tool understands the backslash command \\copy?",
  "psql / pgAdmin PSQL Tool",
  [
    ["Ordinary SQL Query Tool", "It accepts SQL, not psql meta-commands."],
    ["Redis Insight", "That is a Redis client."],
  ],
);
q(
  "etl-extract",
  "Which six tables are extracted?",
  "customer, staff, film, inventory, rental, payment",
  [
    [
      "Only customer, staff, payment",
      "That omits the film/rental path used by the final model.",
    ],
    ["authors, books, city only", "Those are not the six exported tables."],
  ],
  "Medium",
);
q(
  "databricks-compute",
  "Which compute is purpose-built for SQL analytics and BI?",
  "SQL Warehouse",
  [
    ["CSV header", "A header is data, not compute."],
    ["pgAdmin master password", "A password is not compute."],
  ],
);
q(
  "databricks-compute",
  "Notebook default language and compute type are the same setting.",
  "False",
  [
    [
      "True",
      "A language selects syntax; compute supplies execution resources.",
    ],
  ],
  "Medium",
  "True / false",
);
q(
  "staging-transform",
  "What does CAST(amount AS DOUBLE) do?",
  "Converts the expression to a numeric floating-point type",
  [
    [
      "Deletes all failed rows automatically",
      "CAST alone does not inherently filter rows.",
    ],
    [
      "Creates a foreign key",
      "A type conversion is not a relationship constraint.",
    ],
  ],
  "Medium",
  "Code interpretation",
);
q(
  "staging-transform",
  "Equal row counts prove every transformed value is correct.",
  "False",
  [
    [
      "True",
      "Values or types can still be wrong; inspect NULLs and conversion behavior.",
    ],
  ],
  "Medium",
  "True / false",
);
q(
  "columnar-storage",
  "A query reads 1 of 50 columns across many rows. Which layout often helps?",
  "Column-oriented",
  [
    ["Row-oriented always", "Row layout may read interleaved unneeded fields."],
    ["Neither can skip columns", "Columnar readers can skip unused chunks."],
  ],
);
q(
  "columnar-storage",
  "Why can same-type column values compress well?",
  "Adjacent values often repeat or have similar patterns",
  [
    [
      "Columnar storage removes the schema",
      "Parquet retains typed schema metadata.",
    ],
    ["All values become zero", "Compression preserves the data’s meaning."],
  ],
  "Medium",
);
q(
  "parquet-delta",
  "A Delta table adds what over Parquet data files?",
  "A transaction log",
  [
    [
      "A pgAdmin password",
      "Client credentials do not create transactional table state.",
    ],
    ["Only a CSV header", "The log is more than text column names."],
  ],
);
q(
  "parquet-delta",
  "The course guide guarantees plain Parquet table creation works on its free setup.",
  "False",
  [["True", "Part C explicitly notes its external-storage limitation."]],
  "Medium",
  "True / false",
);
q(
  "grain-star",
  "Which design decision comes before choosing dimensions and measures?",
  "Declare the grain",
  [
    ["Choose chart colors", "Presentation does not define a fact row."],
    ["Create arbitrary aggregate rows", "Aggregates require a known grain."],
  ],
);
q(
  "grain-star",
  "In fact_rental, one row should represent what?",
  "One rental event",
  [
    ["One customer lifetime", "That combines many rentals."],
    ["One physical film copy forever", "A copy can be rented repeatedly."],
  ],
);
q(
  "load-star",
  "Why LEFT JOIN payments?",
  "Keep rentals without a matching payment",
  [
    [
      "Guarantee there can never be duplicates",
      "Several payments per rental can still multiply rows.",
    ],
    [
      "Replace unpaid amounts with zero automatically",
      "Unmatched values are NULL, not automatically zero.",
    ],
  ],
  "Medium",
);
q(
  "load-star",
  "Which validates the intended fact grain most directly?",
  "Compare counts and check duplicate rental_id values",
  [
    [
      "Only inspect the first row",
      "That cannot reveal all missing or duplicate rentals.",
    ],
    ["Check the table name", "Naming does not validate contents."],
  ],
  "Hard",
  "Scenario",
);
q(
  "analytical-sql",
  "Why group by year AND month?",
  "Avoid combining the same month across years",
  [
    [
      "GROUP BY accepts exactly two columns",
      "It can group by other numbers of expressions.",
    ],
    [
      "Month numbers are never integers",
      "Calendar month can be represented as an integer.",
    ],
  ],
);
q(
  "analytical-sql",
  "Most rented always means highest revenue.",
  "False",
  [
    [
      "True",
      "Different prices and payment amounts can produce different rankings.",
    ],
  ],
  "Medium",
  "True / false",
);
q(
  "slowly-changing",
  "Which SCD type retains full versions as separate rows?",
  "Type 2",
  [
    ["Type 1", "Type 1 overwrites the prior value."],
    ["Type 3", "Type 3 keeps limited previous values in extra columns."],
  ],
);
q(
  "slowly-changing",
  "What else is needed after adding SCD2 version rows?",
  "Resolve facts to the version valid at event time",
  [
    [
      "Join only on current=true for all history",
      "That would give old events the current attributes.",
    ],
    ["Delete every older version", "That defeats historical retention."],
  ],
  "Hard",
  "Scenario",
);
q(
  "genie",
  "What is grounding in this course’s Genie example?",
  "Using real permitted metadata and data as context",
  [
    ["Inventing plausible tables", "That is ungrounded generation."],
    ["Hiding the SQL", "Reviewing SQL helps verify the result."],
  ],
);
q(
  "genie",
  "Why might “last month” need clarification for dvdrental?",
  "The dataset may contain only older dates",
  [
    [
      "The word month is not allowed",
      "The issue is ambiguous or absent data, not vocabulary.",
    ],
    ["SQL can never filter by time", "SQL can filter dates."],
  ],
  "Medium",
  "Scenario",
);
q(
  "nosql-models",
  "Which database is a document model in these weeks?",
  "MongoDB",
  [
    [
      "Redis core key-value model",
      "Redis is introduced for keyed structures and caching.",
    ],
    ["Neo4j graph model", "Neo4j emphasizes graph relationships."],
  ],
);
q(
  "nosql-models",
  "Analytical columnar and wide-column/column-family are identical categories.",
  "False",
  [["True", "They describe different storage/access models."]],
  "Hard",
  "True / false",
);
q(
  "documents-bson",
  "Which storage format adds ObjectId and date types beyond plain JSON?",
  "BSON",
  [
    ["CSV", "CSV is delimited text with no native ObjectId type."],
    ["HTML", "HTML is page markup."],
  ],
);
q(
  "documents-bson",
  "When is a new MongoDB database actually created in this basic workflow?",
  "On its first write",
  [
    ["Only by CREATE DATABASE SQL", "That is not this mongosh workflow."],
    [
      "Every time Compass starts",
      "Launching a client does not create a database.",
    ],
  ],
  "Medium",
);
q(
  "embed-reference",
  "Which data is a strong candidate for referencing?",
  "An unbounded order history",
  [
    [
      "A small address read with one customer",
      "That is a common embedding candidate.",
    ],
    [
      "A fixed two-field owned preference object",
      "A bounded owned object often embeds well.",
    ],
  ],
  "Medium",
  "Scenario",
);
q(
  "embed-reference",
  "What does $set on address.street change?",
  "The nested street field",
  [
    ["Every customer field is removed", "That would be replacement semantics."],
    ["It creates a PostgreSQL schema", "This is a MongoDB nested update."],
  ],
  "Medium",
  "Code interpretation",
);
q(
  "mongo-crud",
  "Which method can change all matching customers?",
  "updateMany",
  [
    ["updateOne", "That targets one matching document."],
    ["find", "find reads without performing this update."],
  ],
);
q(
  "mongo-crud",
  "What does upsert:true do when there is no match?",
  "Inserts a new document",
  [
    ["Always deletes the collection", "Upsert is insert-or-update behavior."],
    [
      "Automatically creates a unique index",
      "That must be configured separately.",
    ],
  ],
  "Medium",
);
q(
  "mongo-queries",
  "What ensures USD and balance>=100 apply to the SAME account element?",
  "$elemMatch",
  [
    [
      "Separate unconstrained dot-path conditions",
      "Those can match different array elements.",
    ],
    ["$size:100", "That checks array length, not balance."],
  ],
  "Hard",
  "Code interpretation",
);
q(
  "mongo-queries",
  "What does {_id:0, first_name:1} do in a projection?",
  "Returns first_name and suppresses _id",
  [
    ["Deletes _id permanently", "Projection changes output only."],
    ["Sorts by first name", "sort(), not projection, controls ordering."],
  ],
  "Medium",
);
q(
  "indexes-search",
  "What must exist before the course’s $text query?",
  "A text index",
  [
    ["An SQL foreign key", "That is not required for MongoDB text search."],
    ["A Redis TTL", "Redis expiry is unrelated."],
  ],
);
q(
  "indexes-search",
  "What is an index trade-off?",
  "Extra space and write maintenance",
  [
    ["No storage cost ever", "Indexes occupy storage."],
    [
      "Every query must become O(1)",
      "Index usefulness depends on the query and structure.",
    ],
  ],
  "Medium",
);
q(
  "aggregation",
  "Which stage turns account array elements into separate pipeline inputs?",
  "$unwind",
  [
    ["$sort", "Sorting reorders inputs."],
    ["$out", "That writes the final results."],
  ],
);
q(
  "aggregation",
  "A $lookup returns no foreign matches. What is attached to that left input?",
  "An empty array",
  [
    ["The input is always deleted", "Basic $lookup keeps the input document."],
    ["A random foreign row", "Matches follow the specified fields."],
  ],
  "Medium",
  "Predict the output",
);
q(
  "aggregation",
  "Where may $merge appear in the course pipeline?",
  "As the terminal output stage",
  [
    [
      "Before $group with more stages after it",
      "Output stages must terminate the pipeline.",
    ],
    ["Inside every $lookup pipeline", "$out/$merge are not permitted there."],
  ],
  "Hard",
);
q(
  "atlas-operations",
  "Replication and sharding differ how?",
  "Replication copies; sharding partitions",
  [
    ["Both only make backups", "Neither alone is a historical backup."],
    [
      "Sharding copies every row to every shard",
      "That describes copying rather than partitioning.",
    ],
  ],
);
q(
  "atlas-operations",
  "Where do you run mongodump?",
  "An operating-system terminal",
  [
    ["Inside an SQL SELECT", "It is a command-line tool, not SQL."],
    ["As a mongosh helper", "Database Tools run outside mongosh."],
  ],
);
q("performance", "Time taken by one operation is called what?", "Latency", [
  ["Throughput", "Throughput is operations per unit time."],
  ["Grain", "Grain defines a fact row."],
]);
q(
  "performance",
  "A distant region can dominate Redis request time.",
  "True",
  [["False", "Network travel can exceed the in-memory command time."]],
  "Medium",
  "True / false",
);
q(
  "cache-aside",
  "At 95% hits, hit=0.5 ms and miss=4 ms, what is average latency?",
  "0.675 ms",
  [
    ["4 ms", "That is the miss path, not the weighted average."],
    ["3 ms", "That is the sample uncached database cost."],
  ],
  "Hard",
  "Predict the output",
);
q(
  "cache-aside",
  "Data changes in the source. What may need invalidation?",
  "Its stale cached copy",
  [
    [
      "The primary key definition",
      "Changing a value does not require dropping identity rules.",
    ],
    [
      "The entire PostgreSQL engine",
      "Restarting is not the cache consistency operation.",
    ],
  ],
  "Medium",
);
q(
  "redis-architecture",
  "Which statement about complexity is correct?",
  "Different commands have different costs",
  [
    [
      "Every Redis command is O(1)",
      "Scans and large outputs require more work.",
    ],
    ["All commands always read disk", "Normal data access is memory-first."],
  ],
);
q(
  "redis-architecture",
  "Does pipelining make several commands one atomic transaction?",
  "False",
  [
    [
      "True",
      "Pipelining reduces round trips; it does not provide transaction semantics.",
    ],
  ],
  "Hard",
  "True / false",
);
q(
  "redis-strings",
  "What does this return for a previously absent key?",
  "1",
  [
    ["0", "INCR creates the counter at 1."],
    ["PONG", "That is PING’s default reply."],
  ],
  "Easy",
  "Predict the output",
  "INCR pageviews:7",
);
q(
  "redis-strings",
  "Which is preferred for incremental iteration at scale?",
  "SCAN",
  [
    [
      "KEYS over millions of keys",
      "KEYS walks the keyspace in a blocking command.",
    ],
    ["GET without a key", "GET requires a named key."],
  ],
);
q("redis-structures", "Which structure fits unique visitors?", "Set", [
  ["List", "Lists allow duplicates."],
  [
    "String only",
    "A single string does not provide native set membership/intersection.",
  ],
]);
q(
  "redis-structures",
  "Which command reads the top three scores highest-first?",
  "ZREVRANGE leaderboard 0 2 WITHSCORES",
  [
    ["ZRANK leaderboard ahmed", "ZRANK returns one ascending rank."],
    ["SADD leaderboard ahmed", "A set has no numeric ranking scores."],
  ],
  "Medium",
  "Code interpretation",
);
q("ttl-temporary", "What does TTL return if the key does not exist?", "-2", [
  ["-1", "-1 means an existing key with no expiry."],
  ["0 always", "0 can describe an existing key very near expiry."],
]);
q(
  "ttl-temporary",
  "What happens to an existing TTL after plain SET without options?",
  "It is removed",
  [
    ["It is always extended by 60 seconds", "There is no such default."],
    ["The SET is always rejected", "SET can overwrite the value."],
  ],
  "Medium",
  "Predict the output",
);
q(
  "sessions",
  "What lets different web servers access the same login state?",
  "A shared Redis session record",
  [
    ["Only one server’s private RAM", "Other servers cannot see that memory."],
    [
      "A predictable username as secret ID",
      "A session identifier must be unpredictable.",
    ],
  ],
);
q(
  "sessions",
  "Refreshing EXPIRE on each valid request implements what?",
  "Sliding expiration",
  [
    ["A permanent session", "It still expires after inactivity."],
    ["A database JOIN", "This is a TTL update."],
  ],
  "Medium",
);
q(
  "redis-json",
  "What does JSON.GET key $.city commonly return for Manama?",
  '["Manama"]',
  [
    ["A PostgreSQL table", "This is a JSONPath response."],
    ["PONG", "That is a PING response."],
  ],
  "Medium",
  "Predict the output",
);
q("redis-json", "Which must precede FT.SEARCH?", "A suitable FT.CREATE index", [
  [
    "An arbitrary SQL CREATE TABLE",
    "Redis Search does not use PostgreSQL tables.",
  ],
  ["A mongodump backup", "That is an unrelated MongoDB tool."],
]);
q("persistence", "Which mode saves periodic point-in-time files?", "RDB", [
  ["No persistence", "There is no recovery file in that mode."],
  [
    "AOF only",
    "AOF records a stream of writes rather than only periodic snapshots.",
  ],
]);
q(
  "persistence",
  "Does AOF change normal GET into a disk read?",
  "False",
  [["True", "Persistence is for recovery; normal operations access memory."]],
  "Medium",
  "True / false",
);
q(
  "redis-cloud",
  "Which port should you use for your Redis Cloud lab?",
  "The port shown for that database",
  [
    [
      "Always 6379",
      "6379 is a local convention, not the assigned cloud endpoint.",
    ],
    ["Always 5432", "That is a PostgreSQL connection convention."],
  ],
);
q("redis-cloud", "What is ioredis?", "A Node.js Redis client library", [
  [
    "The JavaScript language",
    "JavaScript is the language; ioredis is a library.",
  ],
  ["A separate Redis server engine", "It communicates with the Redis server."],
]);
function fill(
  id: string,
  prompt: string,
  answer: string,
  explanation: string,
  difficulty: Difficulty = "Easy",
  code?: string,
) {
  const l = lessons.find((x) => x.id === id)!;
  bank.push({
    id: `${id}-fill`,
    lessonId: id,
    week: l.week,
    type: "Fill in the blank",
    difficulty,
    prompt,
    answer,
    explanation,
    code,
  });
}
fill(
  "connection-security",
  "Encryption in transit uses SSL / ____.",
  "TLS",
  "TLS encrypts traffic between client and server.",
);
fill(
  "keys-integrity",
  "The SQL keyword creating this parent reference is ____.",
  "REFERENCES",
  "REFERENCES declares the foreign-key relationship.",
  "Easy",
  "author_id bigint ____ authors(id)",
);
fill(
  "staging-transform",
  "The SQL function used to change an expression’s type is ____.",
  "CAST",
  "CAST(expression AS type) converts an expression.",
);
fill(
  "grain-star",
  "The exact meaning of one fact row is called the ____.",
  "grain",
  "Declare grain before selecting dimensions and measures.",
);
fill(
  "documents-bson",
  "MongoDB’s binary document format is ____.",
  "BSON",
  "BSON adds types beyond plain JSON.",
);
fill(
  "ttl-temporary",
  "Which SET option preserves an existing expiry?",
  "KEEPTTL",
  "Without KEEPTTL or a new expiry option, SET removes an existing TTL.",
  "Medium",
);
const matching: [string, [string, string][]][] = [
  [
    "service-models",
    [
      ["IaaS", "Managed infrastructure / VM"],
      ["PaaS", "Managed application platform"],
      ["DBaaS", "Managed database engine"],
    ],
  ],
  [
    "dvdrental",
    [
      ["View", "Stored query definition"],
      ["Sequence", "Number generator"],
      ["Trigger", "Automatic response to an event"],
    ],
  ],
  [
    "lake-warehouse",
    [
      ["Bronze", "Raw source uploads"],
      ["Silver", "Typed staging data"],
      ["Gold", "Analytical facts and dimensions"],
    ],
  ],
  [
    "slowly-changing",
    [
      ["Type 1", "Overwrite"],
      ["Type 2", "Version rows"],
      ["Type 3", "Limited previous-value columns"],
    ],
  ],
  [
    "atlas-operations",
    [
      ["Replication", "Copies of the same data"],
      ["Sharding", "Partitioned data"],
      ["Backup", "Recoverable past copy"],
    ],
  ],
  [
    "persistence",
    [
      ["None", "No persisted recovery data"],
      ["RDB", "Periodic snapshots"],
      ["AOF", "Append-only write log"],
    ],
  ],
];
for (const [lessonId, pairs] of matching) {
  bank.push({
    id: `${lessonId}-match`,
    lessonId,
    week: lessons.find((x) => x.id === lessonId)!.week,
    type: "Matching",
    difficulty: "Medium",
    prompt: "Match each term to its meaning.",
    pairs,
    answer: pairs.map((p) => p[1]).join("|"),
    explanation: pairs.map((p) => `${p[0]}: ${p[1]}.`).join(" "),
  });
}
export const questions = bank;
export function isCorrect(q: Question, answer: string) {
  const norm = (s: string) =>
    s
      .trim()
      .toLowerCase()
      .replace(/[.!?]+$/, "")
      .replace(/\s+/g, " ");
  return norm(answer) === norm(q.answer);
}
