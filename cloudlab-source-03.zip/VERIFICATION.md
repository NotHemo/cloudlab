# Verification — 2 November 2026

## Passing automated checks

- `npm run build`: production compilation and strict TypeScript checks pass; all application routes export successfully.
- `npm test`: 9 tests pass, covering the 12-source / 156-slide inventory, all 41 lessons and their assessments, real PostgreSQL keys/JOINs/aggregates, MongoDB filters and pipelines, Redis expiry/types/JSON/search, grading normalization, backup validation, dark-default behavior and saved-theme restoration without altering study data.
- `node scripts/check-links.mjs`: 57 exported HTML files, 2,495 local asset/link references, zero missing targets.
- Frontend skill lint and browser inspection: zero failing findings. Advisory design warnings and their trade-offs are recorded in DESIGN.md.

## Passing live browser checks

The QA session used port 3010 so test completions/notes did not populate the main port-3000 study profile.

- Navigation opens a complete lesson and the week/module routes are present in the export.
- Bookmark, personal note and lesson completion persist after a browser refresh; dashboard progress updates.
- Knowledge checks return immediate correct/incorrect guidance and related-lesson links.
- Matching questions accept the complete mapping; fill-in answers are case-insensitive.
- A one-minute mock exam counted down, automatically completed, scored a saved answer 1/1, and showed its review/explanation.
- Flashcards flip, record Need Practice and filter back to the marked concept.
- SQL starts real PostgreSQL WebAssembly locally, returns the four-book teaching dataset, rejects a nonexistent author foreign key and returns the expected monthly teaching revenues.
- MongoDB practice returns only the two customers satisfying the same-element account filter and correctly groups the purchase-order teaching data.
- Redis practice shows a key’s countdown and returns nil after its actual expiry.
- ETL practice blocks an invalid amount, accepts a corrected number, preserves the three teaching events and loads the final shape.
- Course search finds the Parquet lesson; source images load, and original lab text is readable.
- Desktop (1440px), tablet (820px) and phone (390px) layouts were visually inspected. Tablet/phone DOM checks show no page-level horizontal overflow. Mobile navigation opens/closes and the dark theme renders correctly.
- The inspected QA tabs reported no browser console errors.

## Explicit verification limits

No real Supabase, Databricks, Atlas or Redis Cloud account was created or queried. The app requires none. Browser-local practice and real-service instructions are clearly separated. The separately referenced DVD Rental archive and companion scripts were not provided, so their actual object counts/results and account-specific execution cannot be independently verified here. Course-author claims, corrections and these boundaries are explained at the relevant lesson/lab and in Sources.

## Readability refresh verification

- Production build, TypeScript, all 9 tests and all 2,495 exported local references pass after the refresh.
- `npm run check:contrast` verifies 88 semantic color combinations across both themes. Minimum normal-text ratio: 4.647:1. Minimum tested meaningful-boundary/progress ratio: 3.010:1. Full results: `artifacts/ui-refresh/contrast-report.json`.
- Live DOM audits cover all six module pages, representative lesson pages, guided labs, quizzes/mock-exam configuration, flashcards, revision, notebook and sources. Both themes pass the audited rendered-text contrast checks.
- Desktop screenshots reviewed at 1920px and 1440px; mobile at 390px. No page-level horizontal overflow on the audited mobile routes or any of the ten playgrounds. The mobile Redis grid was corrected after testing exposed its minimum-width overflow.
- SQL SELECT, MongoDB find and Redis PING still produce their expected teaching results. Existing quiz, lab and visualization behavior is retained.
- Previously saved QA lesson completion, bookmark, note, answers and scores remain visible. Light and dark selections survive refresh. Fresh profiles default to dark; saved explicit theme choices are restored before paint. The storage key and progress fields are unchanged.
- Keyboard navigation displays a 3px teal focus outline. Mobile drawer focus moves into navigation, Tab reaches the links, and Escape closes the drawer and returns focus to its trigger. Browser console audit returned no errors.
- Final dashboard screenshots and design-inspector report: `artifacts/ui-refresh/inspect/`. Design trade-offs are documented in DESIGN.md.
