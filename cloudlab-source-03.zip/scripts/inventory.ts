import fs from "node:fs";
import path from "node:path";
import { lessons, modules } from "../content/course";
import { labs } from "../content/labs";
import { questions } from "../content/questions";
const raw = JSON.parse(
  fs
    .readFileSync("content/source-inventory.json", "utf8")
    .replace(/^\uFEFF/, ""),
);
const sources = raw.map((s: any) => ({
  ...s,
  sections: s.sections.map((section: any) => ({
    ...section,
    paragraphs: section.paragraphs.map((p: string) =>
      p.replace(
        /(mongodb(?:\+srv)?:\/\/)[^\s/@]+:[^\s/@]+@/g,
        "$1USER:PASSWORD@",
      ),
    ),
  })),
}));
fs.writeFileSync("content/sources.json", JSON.stringify(sources));
const missing: string[] = [];
let md =
  "# IT8417 content coverage inventory\n\nPrimary sources: six lecture PPTX files and six DOCX lab guides. Generated examples are explicitly teaching datasets, not results from the actual cloud accounts or restored dvdrental archive.\n\n";
for (const m of modules) {
  const source = sources.find(
    (s: any) => s.week === m.week && s.type === ".pptx",
  );
  md += `## Week ${m.week} — ${m.title}\n\n${source.sections.length} slides; ${m.lessonIds.length} lessons; ${labs[m.week - 1].steps.length} guided lab steps.\n\n| Source slide | Original heading | Website lessons |\n|---|---|---|\n`;
  for (const slide of source.sections) {
    const mapped = lessons.filter(
      (l) => l.week === m.week && l.slides.includes(slide.number),
    );
    if (!mapped.length) missing.push(`Week ${m.week} slide ${slide.number}`);
    md += `| ${slide.number} | ${slide.paragraphs.slice(0, 3).join(" — ").replace(/\|/g, "/")} | ${mapped.map((l) => l.title).join("; ") || "UNMAPPED"} |\n`;
  }
  md += "\n### Lab activity map\n\n";
  for (const step of labs[m.week - 1].steps)
    md += `- ${step.title}: ${step.instruction}\n`;
  md += "\n### Lesson and assessment map\n\n";
  for (const l of lessons.filter((l) => l.week === m.week))
    md += `- **${l.title}** (${l.id}): ${l.concepts.map((c) => c.term).join("; ")}. ${questions.filter((q) => q.lessonId === l.id).length} scored questions. Lab parts: ${l.labParts.join(", ")}.\n`;
  md += "\n";
}
md +=
  "## Source corrections and missing companion assets\n\n- Week 1 mixes transaction-pooler 6543 and port 5432. Copy the complete selected mode, explained in connection-security.\n- Week 2 dvdrental.tar, its SQL scripts and optional RLS guide were not uploaded. Object counts are attributed to the lab author, not independently verified.\n- Week 3 has outdated references to three tables; all six tables are mapped. CSV inference may assign types; CAST alone does not silently drop rows. COPY server-file privileges differ from COPY TO STDOUT.\n- Week 4 grain preservation depends on lookup uniqueness/payment cardinality. Free-plan plain Parquet restriction is retained. SCD teaching SQL fixes unbound email, explains Delta constraints and requires historical baseline plus fact version resolution.\n- Week 5 analytical columnar differs from wide-column/column-family storage. Right-preserving lookup must start on the intended preserved side. Embedded credential-looking URIs are masked in the readable source text; original files remain unchanged for local download. Referenced JS scripts are absent.\n- Week 6 uses Redis Cloud, although Week 1 previews Upstash. Price/limit/version claims are source context, not current guarantees. Atomic command vs multi-command sequences, expiry vs cleanup, primary-store vs cache roles and client code runtime are distinguished. Referenced shell/JS scripts are absent.\n\n## Verification scope\n\nEvery source slide is mapped above. Original lab guide paragraphs and extracted course images remain accessible in the Sources view, alongside the unchanged original Office files. Browser practice is labeled and runs without cloud credentials. Simulators document unsupported commands.\n";
fs.writeFileSync("CONTENT_INVENTORY.md", md);
fs.mkdirSync("public/practice", { recursive: true });
for (const lab of labs) {
  const script = lab.steps
    .filter((s) => s.code)
    .map((s) => `## ${s.title}\n\n${s.code}`)
    .join("\n\n");
  fs.writeFileSync(
    `public/practice/week-${lab.week}-teaching-examples.txt`,
    `IT8417 Week ${lab.week} — teaching examples\nDerived from the uploaded guide. These are not the separately referenced original course scripts.\nCheck each block’s stated environment before running it.\n\n${script}`,
  );
}
console.log(
  JSON.stringify(
    {
      files: sources.length,
      slides: sources
        .filter((s: any) => s.type === ".pptx")
        .reduce((n: number, s: any) => n + s.sections.length, 0),
      lessons: lessons.length,
      concepts: lessons.reduce((n, l) => n + l.concepts.length, 0),
      questions: questions.length,
      labSteps: labs.reduce((n, l) => n + l.steps.length, 0),
      unmapped: missing,
    },
    null,
    2,
  ),
);
if (missing.length) process.exitCode = 1;
