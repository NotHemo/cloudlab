import fs from "node:fs";
import path from "node:path";
const root = path.resolve("out");
const html = [];
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(p);
    else if (p.endsWith(".html")) html.push(p);
  }
}
walk(root);
const missing = [];
let links = 0;
for (const file of html) {
  const text = fs.readFileSync(file, "utf8");
  for (const m of text.matchAll(/(?:href|src)="(\/[^"]*)"/g)) {
    const url = m[1].split(/[?#]/)[0];
    if (!url) continue;
    links++;
    let target = path.resolve(root, "." + decodeURIComponent(url));
    if (fs.existsSync(target) && fs.statSync(target).isDirectory())
      target = path.join(target, "index.html");
    if (!fs.existsSync(target))
      missing.push({ page: path.relative(root, file), link: url });
  }
}
console.log(
  JSON.stringify(
    { pages: html.length, localReferences: links, missing },
    null,
    2,
  ),
);
if (missing.length) process.exitCode = 1;
