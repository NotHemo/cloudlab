Add-Type -AssemblyName System.IO.Compression.FileSystem
$root = (Get-Location).Path
New-Item -ItemType Directory -Force -Path "$root/content/sources", "$root/public/sources" | Out-Null
$files = @(Get-ChildItem -LiteralPath $root -Filter *.pptx) + @(Get-ChildItem -LiteralPath "$root/Labs" -Filter *.docx)
$inventory = @()
foreach ($file in $files) {
  $zip = [IO.Compression.ZipFile]::OpenRead($file.FullName)
  $sections = @()
  $parts = if ($file.Extension -eq '.pptx') { @($zip.Entries | Where-Object FullName -Match '^ppt/slides/slide\d+\.xml$' | Sort-Object { [int]($_.Name -replace '\D','') }) } else { @($zip.GetEntry('word/document.xml')) }
  foreach ($part in $parts) {
    $reader = [IO.StreamReader]::new($part.Open())
    [xml]$xml = $reader.ReadToEnd()
    $reader.Dispose()
    $paragraphs = @()
    foreach ($p in $xml.SelectNodes("//*[local-name()='p']")) {
      $s = ($p.SelectNodes(".//*[local-name()='t']") | ForEach-Object InnerText) -join ''
      if ($s.Trim()) { $paragraphs += $s }
    }
    $relPart = if ($file.Extension -eq '.pptx') { $zip.GetEntry("ppt/slides/_rels/$($part.Name).rels") } else { $zip.GetEntry('word/_rels/document.xml.rels') }
    $imagePaths = @()
    if ($relPart) {
      $rr = [IO.StreamReader]::new($relPart.Open()); [xml]$rels = $rr.ReadToEnd(); $rr.Dispose()
      foreach ($blip in $xml.SelectNodes("//*[local-name()='blip']")) {
        $embed = $blip.GetAttribute('embed','http://schemas.openxmlformats.org/officeDocument/2006/relationships')
        $target = $rels.SelectNodes("//*[local-name()='Relationship']") | Where-Object Id -EQ $embed | Select-Object -ExpandProperty Target
        if ($target -and $target -match 'media/') { $imagePaths += "/sources/$($file.BaseName)/$([IO.Path]::GetFileName($target))" }
      }
    }
    $sections += @{ number = $sections.Count + 1; paragraphs = $paragraphs; images = $imagePaths; }
  }
  $media = @()
  foreach ($entry in $zip.Entries | Where-Object FullName -Match '^(ppt|word)/media/') {
    $dest = "$root/public/sources/$($file.BaseName)"
    New-Item -ItemType Directory -Force -Path $dest | Out-Null
    [IO.Compression.ZipFileExtensions]::ExtractToFile($entry, "$dest/$($entry.Name)", $true)
    $media += "/sources/$($file.BaseName)/$($entry.Name)"
  }
  $zip.Dispose()
  Copy-Item -LiteralPath $file.FullName -Destination "$root/public/sources/$($file.Name)"
  $item = @{ file = $file.Name; week = [int]([regex]::Match($file.Name,'Week(\d+)').Groups[1].Value); type = $file.Extension; sections = $sections; media = $media }
  $item | ConvertTo-Json -Depth 30 | Set-Content -Encoding utf8 "$root/content/sources/$($file.BaseName).json"
  $inventory += $item
}
$inventory | ConvertTo-Json -Depth 30 | Set-Content -Encoding utf8 "$root/content/source-inventory.json"
$inventory | ForEach-Object { "$($_.file): $($_.sections.Count) sections; $($_.media.Count) media assets; $(($_.sections.paragraphs | Measure-Object).Count) paragraphs" }
