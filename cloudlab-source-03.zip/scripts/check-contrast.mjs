import fs from "node:fs";
import assert from "node:assert/strict";
export function contrast(a, b) {
  const luminance = (hex) => {
    let s = hex.replace("#", "");
    if (s.length === 3)
      s = s
        .split("")
        .map((x) => x + x)
        .join("");
    const rgb = s
      .match(/../g)
      .map((x) => parseInt(x, 16) / 255)
      .map((v) => (v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4));
    return 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2];
  };
  const x = luminance(a),
    y = luminance(b);
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
}
export function auditThemes() {
  const css = fs.readFileSync("app/globals.css", "utf8");
  const read = (selector) =>
    Object.fromEntries(
      [
        ...css
          .match(new RegExp(selector + "\\s*\\{([^}]+)"))[1]
          .matchAll(/--([\w-]+):\s*(#[\da-f]+)/gi),
      ].map((m) => [m[1], m[2]]),
    );
  const light = read(":root"),
    dark = { ...light, ...read(':root\\[data-theme="dark"\\]') };
  const checks = [];
  for (const [theme, t] of Object.entries({ light, dark })) {
    for (const bg of [
      "ground",
      "sidebar-bg",
      "surface",
      "raised",
      "code-bg",
      "active",
    ])
      for (const fg of ["text", "muted", "metadata", "accent"])
        checks.push({
          theme,
          pair: `${fg} on ${bg}`,
          ratio: contrast(t[fg], t[bg]),
          minimum: 4.5,
        });
    checks.push({
      theme,
      pair: "progress fill on track",
      ratio: contrast(t["progress-fill"], t["progress-track"]),
      minimum: 3,
    });
    checks.push({
      theme,
      pair: "progress track on card",
      ratio: contrast(t["progress-track"], t["surface"]),
      minimum: 3,
    });
    checks.push({
      theme,
      pair: "primary button text",
      ratio: contrast(t["on-accent"], t.accent),
      minimum: 4.5,
    });
    for (const bg of ["ground", "surface", "raised", "code-bg"])
      for (const fg of ["control", "card-border"])
        checks.push({
          theme,
          pair: `${fg} on ${bg}`,
          ratio: contrast(t[fg], t[bg]),
          minimum: 3,
        });
    for (const fg of ["positive", "negative", "warning"])
      for (const bg of ["surface", "raised", "accent-soft"])
        checks.push({
          theme,
          pair: `${fg} on ${bg}`,
          ratio: contrast(t[fg], t[bg]),
          minimum: 4.5,
        });
  }
  return checks.map((c) => ({ ...c, pass: c.ratio >= c.minimum }));
}
if (process.argv[1]?.endsWith("check-contrast.mjs")) {
  const checks = auditThemes();
  const failures = checks.filter((c) => !c.pass);
  console.log(
    JSON.stringify(
      {
        checks: checks.length,
        minimumTextRatio: Math.min(
          ...checks.filter((c) => c.minimum === 4.5).map((c) => c.ratio),
        ),
        minimumBoundaryRatio: Math.min(
          ...checks.filter((c) => c.minimum === 3).map((c) => c.ratio),
        ),
        failures,
      },
      null,
      2,
    ),
  );
  fs.mkdirSync("artifacts/ui-refresh", { recursive: true });
  fs.writeFileSync(
    "artifacts/ui-refresh/contrast-report.json",
    JSON.stringify(checks, null, 2),
  );
  assert.equal(failures.length, 0, "Theme contrast requirements must pass.");
}
