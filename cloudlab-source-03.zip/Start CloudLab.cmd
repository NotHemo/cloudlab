@echo off
cd /d "%~dp0"
if not exist "node_modules\next" (
  echo Installing dependencies...
  call npm install
  if errorlevel 1 goto failed
)
if not exist "out\index.html" (
  echo Building CloudLab...
  call npm run build
  if errorlevel 1 goto failed
)
node scripts\serve.mjs --open
goto end
:failed
echo CloudLab could not start. Read the error above.
pause
:end
