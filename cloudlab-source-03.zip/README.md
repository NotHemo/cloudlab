# CloudLab — IT8417 Advanced Cloud Databases

A complete local learning application built from the 12 Office files in this workspace. It uses Next.js, TypeScript, Tailwind CSS, shadcn-style accessible Button primitives, Lucide and Motion.

## Open the app

Double-click **Start CloudLab.cmd** in this folder. It serves the production build at **http://127.0.0.1:3000**. Keep its terminal open while studying. Stop it with Ctrl+C. If port 3000 is already serving CloudLab, open that URL instead of starting a second copy.

The dependencies and production export are already built in this workspace. A fresh source checkout needs Node.js 20.9+ and these commands:

```powershell
npm install
npm run build
npm start
```

For development, use `npm run dev`. Rebuild after editing source before using `npm start`, because the production server serves `out/`.

## Included

- Six modules, 41 lessons and 86 explained concepts, with analogies, technical examples, steps, knowledge checks and summaries.
- Six guided labs with 45 tracked steps, expected behavior, hints and troubleshooting.
- Real browser-local PostgreSQL through PGlite; small teaching data, not the full dvdrental archive.
- Documented MongoDB and Redis simulation subsets. Unknown/unsupported commands return errors rather than simulated success.
- Functional JOIN, ETL, star schema, storage, SCD, model comparison and cache-aside visualizations.
- 95 questions across seven formats and three difficulty levels; configurable timed mock exams with answer review.
- 86 flashcards with mastery/practice filters; quick revision comparisons and command sheets.
- Local progress, scores, study streak, bookmarks and notes, with JSON export/import backups.
- Light/dark themes, keyboard controls and responsive desktop/tablet/mobile layouts.
- A slide-to-lesson map, readable source text, extracted visuals and all unchanged original Office files.

## Source fidelity and boundaries

See **CONTENT_INVENTORY.md** for a complete slide/activity map and corrections. All 156 slides map to lessons. Course examples were rewritten for teaching; small local datasets are clearly labeled and are not fabricated cloud results.

The 12 uploaded files reference companion assets that were not present: dvdrental.tar, SQL Script 04, an optional RLS guide, and Week 5/6 shell/JavaScript scripts. The relevant labs explain this. Downloadable teaching extracts are derived from the guides; they do not claim to be the missing original scripts.

Important source inconsistencies are explicitly explained: Supabase pooler ports, COPY file access, CSV typing/CAST behavior, warehouse join multiplicity, the free-setup Parquet restriction, SCD history/Delta syntax, analytical columnar vs wide-column, MongoDB join direction, and Redis atomicity/recovery distinctions. Links to primary technical documentation appear in Sources. Plan limits are presented as course context rather than current guarantees.

Practice does not connect to Supabase, Databricks, Atlas or Redis Cloud. Real-service setup and administrative tasks require the student to follow the original guide in their own account. This app needs no credentials or paid APIs. Fonts and PostgreSQL assets are served locally. Progress stays in LocalStorage for this origin; export a backup before clearing browser data or switching devices. Playground data is temporary.

## Project organization

| Location                 | Purpose                                                                   |
| ------------------------ | ------------------------------------------------------------------------- |
| `content/course.ts`      | Modules, lessons, concept teaching and source references                  |
| `content/labs.ts`        | Guided lab steps and command examples                                     |
| `content/questions.ts`   | Question bank, explanations and grading                                   |
| `content/sources.json`   | Generated readable source content; credential-looking example URIs masked |
| `components/`            | Reusable learning interfaces, playgrounds and visualizations              |
| `lib/`                   | Types, progress validation, seed data and pure simulation engines         |
| `app/`                   | Next.js routes, global layout and responsive styles                       |
| `public/sources/`        | Original files and extracted course visuals                               |
| `public/engine/`         | Locally served PostgreSQL WebAssembly/data assets                         |
| `scripts/extract.ps1`    | Read-only Office XML extraction, preserving original files                |
| `scripts/inventory.ts`   | Coverage audit and teaching command extract generation                    |
| `scripts/serve.mjs`      | Loopback-only static production server                                    |
| `tests/learning.test.ts` | Coverage, quiz, SQL, simulation and persistence-data checks               |

## Verification

```powershell
npm run check
npm test
npm run build
```

The automated checks cover all-source mapping, per-lesson assessments, question metadata, PostgreSQL constraints/JOINs/aggregation, MongoDB array and pipeline behavior, Redis types/expiry/JSON/search, and progress-backup validation. Browser checks cover navigation, persistence across refreshes, local database commands, ETL quality gates, flashcard filters, timed exam auto-finish, search and responsive layouts. Real cloud accounts and the missing companion archive/scripts are not executed or independently verified.

To regenerate source extraction and the inventory after replacing input files:

```powershell
./scripts/extract.ps1
npx tsx scripts/inventory.ts
```

Keep the originals in their current locations. Source extraction is a development operation; it is not needed to run the app.
