import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";
import { DEFAULT_THEME, savedTheme, themeBootstrapScript } from "../lib/theme";
test("dark default and pre-paint theme restore preserve existing study data", () => {
  assert.equal(DEFAULT_THEME, "dark");
  assert.equal(savedTheme(null), "dark");
  const progress = {
    theme: "light",
    completed: ["cloud-basics"],
    notes: { "cloud-basics": "My own note" },
    scores: [{ score: 9, total: 10 }],
  };
  const serialized = JSON.stringify(progress);
  let writes = 0;
  const document = { documentElement: { dataset: { theme: "dark" } } };
  vm.runInNewContext(themeBootstrapScript, {
    document,
    localStorage: { getItem: () => serialized, setItem: () => writes++ },
  });
  assert.equal(document.documentElement.dataset.theme, "light");
  assert.equal(writes, 0);
  assert.equal(JSON.stringify(progress), serialized);
  assert.equal(savedTheme(progress), "light");
  assert.equal(savedTheme({ ...progress, theme: "dark" }), "dark");
  vm.runInNewContext(themeBootstrapScript, {
    document,
    localStorage: {
      getItem: () => {
        throw new Error("blocked");
      },
    },
  });
  assert.equal(document.documentElement.dataset.theme, "light");
});
test("central typography leaves the learning content and storage key intact", () => {
  const css = fs.readFileSync("app/globals.css", "utf8");
  assert.match(css, /--type-body:\s*16px/);
  assert.match(css, /--type-meta:\s*13px/);
  assert.match(css, /--sidebar:\s*256px/);
  assert.match(css, /max-width:\s*1360px/);
  assert.match(
    fs.readFileSync("components/progress-provider.tsx", "utf8"),
    /it8417-progress-v1/,
  );
});
