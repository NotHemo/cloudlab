import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { PGlite } from "@electric-sql/pglite";
import { lessons, modules } from "../content/course";
import { questions, isCorrect } from "../content/questions";
import { labs } from "../content/labs";
import { matches, mongoSeed, runMongo } from "../lib/mongo-engine";
import { redisSeed, runRedis, liveRedis } from "../lib/redis-engine";
import { sqlSeed } from "../lib/sql-seed";
import { parseProgressBackup } from "../lib/progress";
import { studyStreak } from "../lib/utils";
test("all 156 slides, 6 labs and every lesson have coverage and assessments", () => {
  const sources = JSON.parse(fs.readFileSync("content/sources.json", "utf8"));
  assert.equal(sources.length, 12);
  assert.equal(modules.length, 6);
  assert.equal(labs.length, 6);
  for (const source of sources.filter((s: any) => s.type === ".pptx"))
    for (const slide of source.sections)
      assert.ok(
        lessons.some(
          (l) => l.week === source.week && l.slides.includes(slide.number),
        ),
        `Week ${source.week} slide ${slide.number}`,
      );
  assert.equal(new Set(lessons.map((l) => l.id)).size, lessons.length);
  for (const l of lessons) {
    assert.ok(l.concepts.length >= 2);
    assert.ok(questions.filter((q) => q.lessonId === l.id).length >= 2, l.id);
    assert.ok(l.takeaways.length && l.mistakes.length);
    for (const c of l.concepts)
      for (const field of [
        "term",
        "explanation",
        "why",
        "analogy",
        "check",
        "answer",
      ] as const)
        assert.ok(c[field].length > 5);
  }
  for (const q of questions) {
    assert.ok(lessons.some((l) => l.id === q.lessonId));
    assert.ok(q.explanation);
    if (q.options) {
      assert.ok(q.options.includes(q.answer));
      assert.equal(new Set(q.options).size, q.options.length);
      for (const wrong of q.options.filter((o) => o !== q.answer))
        assert.ok(q.wrong?.[wrong]);
    }
  }
  assert.equal(new Set(questions.map((q) => q.type)).size, 7);
  assert.equal(new Set(questions.map((q) => q.difficulty)).size, 3);
});
test("actual PostgreSQL enforces keys, keeps unmatched left rows and computes the teaching revenue", async () => {
  const db = new PGlite();
  try {
    await db.exec(sqlSeed);
    assert.equal(
      (
        await db.query(
          "SELECT * FROM books b JOIN authors a ON b.author_id=a.id",
        )
      ).rows.length,
      3,
    );
    assert.equal(
      (
        await db.query(
          "SELECT * FROM books b LEFT JOIN authors a ON b.author_id=a.id",
        )
      ).rows.length,
      4,
    );
    await assert.rejects(
      db.query("INSERT INTO books(title,author_id) VALUES ('bad',999)"),
      /foreign key/,
    );
    await db.exec(
      "CREATE TABLE students(id int PRIMARY KEY,name text); INSERT INTO students VALUES(1,'Mary');",
    );
    await assert.rejects(
      db.query("INSERT INTO students VALUES(1,'Other')"),
      /duplicate key/,
    );
    const r = await db.query<{ total: number; n: number }>(
      "SELECT SUM(amount) AS total,COUNT(*)::int AS n FROM fact_rental",
    );
    assert.equal(r.rows[0].n, 4);
    assert.ok(Math.abs(r.rows[0].total - 12.97) < 0.00001);
  } finally {
    await db.close();
  }
});
test("Mongo array filters bind to the same element and changes do not mutate the old state", () => {
  const state = mongoSeed();
  assert.equal(
    matches(state.collections.customers[0], {
      account: { $elemMatch: { currency: "USD", balance: { $gte: 100 } } },
    }),
    false,
  );
  const r = runMongo(
    state,
    'db.customers.find({account:{$elemMatch:{currency:"USD",balance:{$gte:100}}}},{_id:0,first_name:1})',
  );
  assert.deepEqual(r.output, [
    { first_name: "Hassan" },
    { first_name: "Mariam" },
  ]);
  const u = runMongo(
    state,
    'db.customers.updateOne({first_name:"Ahmed"},{$inc:{age:1}})',
  );
  assert.equal(u.state.collections.customers[0].age, 31);
  assert.equal(state.collections.customers[0].age, 30);
  assert.throws(
    () => runMongo(state, "db.customers.find({}).map(alert)"),
    /Arguments|Unsupported/,
  );
  assert.throws(
    () => runMongo(state, "db.customers.find({}); alert(1)"),
    /Unexpected/,
  );
});
test("Mongo aggregation, outer joins, text-index gate and materialization have correct shapes", () => {
  let state = mongoSeed();
  assert.throws(
    () => runMongo(state, 'db.articles.find({$text:{$search:"coffee"}})'),
    /index required/,
  );
  state = runMongo(state, 'db.articles.createIndex({subject:"text"})').state;
  assert.equal(
    runMongo(state, 'db.articles.find({$text:{$search:"coffee"}})').output
      .length,
    1,
  );
  const sum = runMongo(
    state,
    'db.purchase_orders.aggregate([{$group:{_id:"$product",total:{$sum:"$total"}}},{$sort:{total:-1}}])',
  );
  assert.deepEqual(sum.output, [
    { _id: "Book", total: 20 },
    { _id: "Pen", total: 3 },
  ]);
  const join = runMongo(
    state,
    'db.clients.aggregate([{$lookup:{from:"orders",localField:"_id",foreignField:"user_id",as:"orders"}}])',
  );
  assert.equal(join.output.length, 2);
  assert.equal(join.output[1].orders.length, 0);
  const out = runMongo(
    state,
    'db.purchase_orders.aggregate([{$group:{_id:"$product",total:{$sum:"$total"}}},{$out:"totals"}])',
  );
  assert.equal(out.state.collections.totals.length, 2);
  assert.throws(
    () => runMongo(state, 'db.customers.aggregate([{$out:"x"},{$match:{}}])'),
    /last stage/,
  );
});
test("Redis expiration, KEEPTTL, NX and GETDEL follow time and ownership-independent key semantics", () => {
  let state = redisSeed();
  state = runRedis(state, "SET temp hello EX 10", 1000).state;
  assert.equal(runRedis(state, "TTL temp", 1000).output, 10);
  assert.equal(runRedis(state, "GET temp", 11000).output, null);
  assert.equal(runRedis(state, "TTL temp", 11000).output, -2);
  state = runRedis(state, "SET temp updated KEEPTTL", 2000).state;
  assert.equal(state.keys.temp.expiresAt, 11000);
  state = runRedis(state, "SET temp permanent", 3000).state;
  assert.equal(runRedis(state, "TTL temp", 3000).output, -1);
  assert.equal(runRedis(state, "SET temp blocked NX", 3000).output, null);
  const consume = runRedis(state, "GETDEL temp", 3000);
  assert.equal(consume.output, "permanent");
  assert.equal(runRedis(consume.state, "GETDEL temp", 3000).output, null);
  assert.throws(() => runRedis(state, "INCR course"), /integer/);
  assert.throws(() => runRedis(state, "HSET course a b"), /WRONGTYPE/);
  assert.throws(() => runRedis(state, "GET course extra"), /Wrong number/);
  assert.throws(() => runRedis(state, 'JSON.SET course $ "{}"'), /WRONGTYPE/);
});
test("Redis types, sorted ranks, JSON paths and indexed TAG search", () => {
  let state = redisSeed();
  assert.deepEqual(
    runRedis(state, "ZREVRANGE leaderboard 0 2 WITHSCORES").output,
    ["yousef", "500", "ahmed", "420", "omar", "275"],
  );
  assert.equal(runRedis(state, "ZRANK leaderboard omar").output, 0);
  state = runRedis(state, "SADD visitors ahmed ahmed mariam").state;
  assert.equal(runRedis(state, "SCARD visitors").output, 2);
  state = runRedis(
    state,
    `JSON.SET customer:json:ahmed $ '{"city":"Manama","orders":[{"total":120.5}]}'`,
  ).state;
  assert.deepEqual(
    runRedis(state, "JSON.GET customer:json:ahmed $.city").output,
    ["Manama"],
  );
  state = runRedis(
    state,
    "JSON.NUMINCRBY customer:json:ahmed $.orders[0].total 10",
  ).state;
  assert.equal(state.keys["customer:json:ahmed"].value.orders[0].total, 130.5);
  state = runRedis(
    state,
    "FT.CREATE idx ON JSON PREFIX 1 customer:json: SCHEMA $.city AS city TAG",
  ).state;
  assert.equal(
    runRedis(state, 'FT.SEARCH idx "@city:{Manama}"').output.total,
    1,
  );
  assert.throws(() => runRedis(state, "FAKE command"), /Unsupported/);
});
test("quiz normalization, backup validation and Bahrain study streak", () => {
  const fill = questions.find(
    (q) => q.answer === "CAST" && q.type === "Fill in the blank",
  )!;
  assert.ok(isCorrect(fill, " cast. "));
  assert.throws(
    () => parseProgressBackup('{"completed":["not-real"]}'),
    /Invalid/,
  );
  assert.throws(
    () => parseProgressBackup('{"completed":[],"notes":{"x":42}}'),
    /Notes/,
  );
  assert.deepEqual(
    parseProgressBackup(
      '{"completed":["cloud-basics"],"notes":{"cloud-basics":"My note"}}',
    ).completed,
    ["cloud-basics"],
  );
  assert.equal(
    studyStreak(
      ["2026-10-31", "2026-11-01", "2026-11-02"],
      new Date("2026-11-02T12:00:00Z"),
    ),
    3,
  );
});
