# IT8417 content coverage inventory

Primary sources: six lecture PPTX files and six DOCX lab guides. Generated examples are explicitly teaching datasets, not results from the actual cloud accounts or restored dvdrental archive.

## Week 1 — Cloud database fundamentals

20 slides; 5 lessons; 6 guided lab steps.

| Source slide | Original heading | Website lessons |
|---|---|---|
| 1 | WEEK 1  ·  SESSIONS 1 & 2 — Cloud Database Fundamentals — Welcome to IT8417 · Deployment Models · Getting Started with Supabase | A database beyond your laptop |
| 2 | WEEK 1 — Today’s Plan — 90 Minutes, Two Sessions — SESSION 1 · THEORY/TUTORIAL | A database beyond your laptop |
| 3 | SESSION 1 · CONCEPTS — What Is a Cloud Database, Really? — A database that runs on infrastructure you don't own or manage — provisioned in minutes, accessed over the internet, and (usually) maintained by someone else so you can focus on your data, not your hardware. | A database beyond your laptop |
| 4 | SESSION 1 · CONCEPTS — Deployment Models: IaaS, PaaS, and DBaaS — Cloud services sit on a spectrum of how much you manage yourself versus how much the provider handles for you. | Who manages which layer? |
| 5 | SESSION 1 · CONCEPTS — Two Ideas Behind Every Cloud Database — Multi-Tenancy | Who manages which layer? |
| 6 | SESSION 1 · COURSE OVERVIEW — This Course’s Platforms — and One Strict Rule — Every platform used this semester must require no credit or debit card at sign-up | Who manages which layer? |
| 7 | SESSION 1 · THIS WEEK’S PLATFORM — Introducing PostgreSQL & Supabase — PostgreSQL | Meet PostgreSQL and Supabase |
| 8 | SESSION 1 · CONCEPTS — Connection Security Basics — Before today's lab, three ideas you'll meet immediately when connecting to any cloud database — not just Supabase. | Connect safely |
| 9 | MOVING TO SESSION 2 — Enough Theory. — Get a Live Database. | A database beyond your laptop |
| 10 | SESSION 2 · LAB 1A — Walkthrough: Sign Up for Supabase — 1 | Your first project, end to end |
| 11 | SESSION 2 · LAB 1B — Exploring the Dashboard: Table Editor — Table Editor | Meet PostgreSQL and Supabase |
| 12 | SESSION 2 · LAB 1B — Exploring the Dashboard: SQL Editor — SQL Editor | Meet PostgreSQL and Supabase |
| 13 | SESSION 2 · LAB 1B — Find Your Connection Details — Everything an external tool like pgAdmin needs to reach your database lives in one place: Project Settings → Database. | Connect safely |
| 14 | SESSION 2 · LAB 1C — Install pgAdmin — Supabase's own SQL Editor is enough for basic work — but a dedicated desktop tool gives you a persistent, feature-rich workspace, and it's exactly the same idea you'll meet again in Week 10 with DBeaver. | Meet PostgreSQL and Supabase |
| 15 | SESSION 2 · LAB 1D (optional) — IT8417  ·  Week 1  ·  Cloud Database Fundamentals — 12 | Your first project, end to end |
| 16 | SESSION 2 · LAB 1C — Connect pgAdmin to Your Supabase Database — Register — Server | Connect safely |
| 17 | SESSION 2 · LAB 1C — Same Data, Two Windows — In pgAdmin, expand your new server → Databases → postgres → Schemas → public → Tables. Right-click books → View/Edit Data → All Rows. | Meet PostgreSQL and Supabase |
| 18 | WRAP-UP — Today’s Lab Checklist — ✓ | Your first project, end to end |
| 19 | WRAP-UP — Common Pitfalls & Troubleshooting — Supabase asks for payment info | Connect safely |
| 20 | A Live Database, Reachable Two Ways — ✓  A cloud database, IaaS/PaaS/DBaaS explained — ✓  A live Supabase project, with a table you built | A database beyond your laptop |

### Lab activity map

- A · Provision it8417-db: Follow the course signup flow at Supabase. Create an organization, choose the intended free plan, name the project it8417-db, save a strong database password privately and choose a nearby region. Wait for provisioning.
- B1 · Create books in Table Editor: Create books with title (text), published (int4), and an identity primary key id. Insert one row visually. If using SQL instead, run this once.
- B2 · Insert and read from SQL Editor: Run the insert and SELECT. Supabase’s default SQL Editor workflow autocommits.
- C1 · Copy one complete connection configuration: Open the project Connect/settings dialog. Choose a supported direct or session-pooler configuration for a persistent desktop client and your network. Copy host, port, database, user and password fields from that same mode.
- C2 · Install and register in pgAdmin: Install the desktop application from pgadmin.org. Set its separate master password. Right-click Servers → Register → Server. General name is a label; Connection uses copied settings. Use the supported TLS/SSL setting.
- C3 · Verify the same data in two windows: In pgAdmin open books → View/Edit Data → All Rows, or use Query Tool. Refresh the Supabase table and compare.

### Lesson and assessment map

- **A database beyond your laptop** (cloud-basics): Cloud database; Self-hosted vs cloud-managed. 2 scored questions. Lab parts: A.
- **Who manages which layer?** (service-models): IaaS / PaaS / DBaaS; Multi-tenancy and elasticity. 3 scored questions. Lab parts: A.
- **Meet PostgreSQL and Supabase** (postgres-supabase): PostgreSQL engine and Supabase platform; Table Editor, SQL Editor and pgAdmin. 2 scored questions. Lab parts: B, C.
- **Connect safely** (connection-security): Connection string and TLS; Direct connection vs pooler. 3 scored questions. Lab parts: C.
- **Your first project, end to end** (first-project): Provisioning and region; Roles and Row Level Security (optional context). 2 scored questions. Lab parts: A, B, C.

## Week 2 — PostgreSQL & relational databases

18 slides; 6 lessons; 6 guided lab steps.

| Source slide | Original heading | Website lessons |
|---|---|---|
| 1 | WEEK 2  ·  SESSIONS 1 & 2 — PostgreSQL & Supabase Deep-Dive — The Relational Model in Depth · Primary & Foreign Keys · Joins | Give your data structure |
| 2 | WEEK 2 — Today’s Plan — 90 Minutes, Two Sessions — SESSION 1 · THEORY/TUTORIAL | Give your data structure |
| 3 | SESSION 1 · RECAP — What You Built Last Week — A live Supabase project | Give your data structure |
| 4 | SESSION 1 · CONCEPTS — The Relational Model, Properly This Time — A relational database organizes data into tables — and the real power comes from how those tables relate to each other, not just from storing rows. | Give your data structure |
| 5 | SESSION 1 · CONCEPTS — Primary Keys: What Makes a Row Unique — A primary key is a column (or set of columns) guaranteed to uniquely identify every row in a table — no two rows can ever share one. | Keys that protect relationships |
| 6 | SESSION 1 · CONCEPTS — Foreign Keys: Connecting Tables Together — A foreign key is a column in one table that points to a primary key in another — it's how PostgreSQL enforces that a relationship actually makes sense. | Keys that protect relationships |
| 7 | SESSION 1 · CONCEPTS — Data Types & Constraints in PostgreSQL — Type / Constraint | Types and rules for clean data |
| 8 | SESSION 1 · CONCEPTS — SQL Standards Compliance & the Extensions Ecosystem — Standards Compliance | Types and rules for clean data |
| 9 | SESSION 1 · ARCHITECTURE — PostgreSQL’s Architecture, From the Inside — What you saw in pgAdmin's tree last week wasn't arbitrary — it's PostgreSQL's actual object hierarchy, top to bottom. | Give your data structure; Explore the DVD Rental database |
| 10 | SESSION 1 · ARCHITECTURE — PostgreSQL vs. Oracle: Architecture Compared — If you've worked with Oracle before, some of these terms will sound familiar — but map differently than you might expect. | Give your data structure |
| 11 | MOVING TO SESSION 2 — Enough Theory. — Build the Relationship. | Give your data structure |
| 12 | SESSION 2 · LAB 2A — Design: Authors + Books Schema — One author can write many books. One book has exactly one author, in this simple design. That's a one-to-many relationship — the most common pattern in relational design. | Keys that protect relationships |
| 13 | SESSION 2 · LAB 2B — Create the authors Table — SQL Editor | Build and backfill a relationship |
| 14 | SESSION 2 · LAB 2B — Link books to authors with a Foreign Key — SQL Editor | Build and backfill a relationship |
| 15 | SESSION 2 · LAB 2C — Your First JOIN Query — SQL Editor | Make two tables answer together |
| 16 | WRAP-UP — Today’s Lab Checklist — ✓ | Build and backfill a relationship; Explore the DVD Rental database |
| 17 | WRAP-UP — Common Pitfalls & Troubleshooting — “violates foreign key constraint” | Build and backfill a relationship; Make two tables answer together |
| 18 | A Real Relational Schema, Built by You — ✓  Primary and foreign keys, hands-on — ✓  A one-to-many relationship, enforced by the database itself | Give your data structure; Explore the DVD Rental database |

### Lab activity map

- A · Sketch the schema: authors has id/name. books has id/title/published/author_id. Put the foreign key on the many side: books.
- B1 · Create and inspect authors: Create the parent table and insert two names. Note your actual generated IDs.
- B2 · Link and backfill books: Run ALTER once in your Week 1 schema. Adjust IDs in UPDATE to match your authors. If the Grace Hopper title was not inserted in Week 1, insert it before updating it.
- C · Run the JOIN: Read titles, publication years and author names. Run the same query in pgAdmin if desired.
- D1 · Restore dvdrental (recommended): Obtain the separate course dvdrental.tar. In pgAdmin right-click postgres → Restore, choose Custom/tar, select the archive and start Restore. Refresh public.Tables.
- D2 · Test each object type (recommended): Try a table join, view, sequence, trigger and function. Read actor.last_update before and after UPDATE. Only call rent_film after creating it with the separate Script 04.

### Lesson and assessment map

- **Give your data structure** (relational-model): Table, row, column and schema; Cluster-wide roles and tablespaces. 2 scored questions. Lab parts: A.
- **Keys that protect relationships** (keys-integrity): Primary key and identity; Foreign key and referential integrity. 3 scored questions. Lab parts: A, B.
- **Types and rules for clean data** (types-constraints): Data types; Constraints and extensions. 2 scored questions. Lab parts: B.
- **Build and backfill a relationship** (evolve-schema): ALTER TABLE and backfill; Diagnosing relationship errors. 2 scored questions. Lab parts: B.
- **Make two tables answer together** (sql-joins): INNER JOIN and ON; LEFT JOIN and cardinality. 2 scored questions. Lab parts: C, D.
- **Explore the DVD Rental database** (dvdrental): dvdrental and the ER diagram; Views, sequences, triggers, functions and procedures. 3 scored questions. Lab parts: D.

## Week 3 — Data warehousing & ETL

19 slides; 5 lessons; 6 guided lab steps.

| Source slide | Original heading | Website lessons |
|---|---|---|
| 1 | WEEK 3  ·  SESSIONS 1 & 2 — Data Warehousing: Extract & Transform — A Real ETL Pipeline · From Supabase's dvdrental to Databricks | Run the business or analyze it? |
| 2 | WEEK 3 — Today’s Plan — 90 Minutes, Two Sessions — SESSION 1 · THEORY/TUTORIAL | Run the business or analyze it? |
| 3 | SESSION 1 · RECAP — What You Built So Far — A relational schema | Run the business or analyze it? |
| 4 | Session 1 ·  FUNDAMENTALS — OLTP runs the business; OLAP analyses it — Aspect | Run the business or analyze it? |
| 5 | SESSION 1 · CONCEPTS — Data Warehouse, Data Lake, and Lakehouse — Three ways to store data at scale, with sharply different trade-offs — and today's lab builds a real example of the middle one. | Lake, warehouse, lakehouse |
| 6 | SESSION 1 · DATA WAREHOUSE — A curated, structured store built for analysis — Bill Inmon's classic definition names four properties: | Run the business or analyze it? |
| 7 | SESSION 1 · CONCEPTS — The ETL Pattern, Properly: Extract, Transform, Load — Three distinct steps, each with one job. Today covers the first two, hands-on; next week finishes with the third. | Extract six real tables |
| 8 | SESSION 1 · CONCEPTS — Star Schema Design: Facts & Dimensions — Warehouses are typically modelled as a star: one central fact table, surrounded by dimension tables that describe it. This is exactly what we'll load next week. | Lake, warehouse, lakehouse |
| 9 | SESSION 1 · ARCHITECTURE — Compute in Databricks: Two Different Jobs — Databricks separates “running your code” from “running your queries” — two compute types, each optimised for a different job. | Choose the right compute |
| 10 | SESSION 1 · THIS WEEK’S PLATFORM — Introducing Databricks Free Edition — Databricks popularised the term “lakehouse” — but underneath, it's a genuine data warehousing platform: notebooks, SQL, and serverless compute, with no card required. | Lake, warehouse, lakehouse; Choose the right compute |
| 11 | MOVING TO SESSION 2 — Enough Theory. — Move Some Real Data. | Extract six real tables |
| 12 | SESSION 2 · LAB 3A — Walkthrough: Sign Up for Databricks Free Edition — 1 | Choose the right compute |
| 13 | SESSION 2 · THE SCENARIO — From dvdrental to a Real Warehouse — A genuine two-week ETL project, using data you already have. | Extract six real tables |
| 14 | SESSION 2 · LAB 3B — Extract, Step 1: Export Tables as CSV — psql — pgAdmin PSQL Tool | Extract six real tables |
| 15 | SESSION 2 · LAB 3B — Extract, Step 2: Upload CSVs into Databricks — 1 | Choose the right compute |
| 16 | SESSION 2 · LAB 3C — Transform: Clean and Reshape into Staging Tables — it8417-warehouse (SQL) | Turn raw strings into typed data |
| 17 | WRAP-UP — Today’s Lab Checklist — ✓ | Turn raw strings into typed data |
| 18 | WRAP-UP — Common Pitfalls & Troubleshooting — PSQL Tool is greyed out or missing | Turn raw strings into typed data |
| 19 | Two-Thirds of a Real ETL Pipeline — ✓  Extract: 6 real tables, out of Supabase, via psql \copy — ✓  Extract: those CSVs, uploaded into Databricks | Turn raw strings into typed data |

### Lab activity map

- A · Create the workspace and notebook: Use the course Free Edition signup path, verify email, open the workspace and create it8417-warehouse with default language SQL. Check actual account plan and compute availability.
- B1 · Export all six CSVs: Open the pgAdmin PSQL Tool connected to your restored project. Run each line separately. Change output names to full local paths for a folder you have created if needed.
- B2 · Create six bronze tables: In Databricks use Add/upload data → create/modify table. Import each CSV into bronze_customer, bronze_staff, bronze_film, bronze_inventory, bronze_rental and bronze_payment in your selected catalog/schema.
- C1 · Transform all six tables: Run the six CTAS statements. The guide uses DOUBLE for amounts/rates; exact financial systems often need an explicit DECIMAL design.
- C2 · Verify counts, types and values: Compare each bronze/staging pair and inspect conversions. This check covers all six pairs.
- Checkpoint · Keep your silver tables: Explain Extract vs Transform and \copy vs COPY in your own words. Save the workspace for Week 4.

### Lesson and assessment map

- **Run the business or analyze it?** (oltp-olap): OLTP and OLAP; Four warehouse properties. 2 scored questions. Lab parts: A.
- **Lake, warehouse, lakehouse** (lake-warehouse): Data lake and warehouse; Lakehouse and medallion layers. 3 scored questions. Lab parts: A.
- **Extract six real tables** (etl-extract): ETL and extraction; COPY vs psql \copy. 2 scored questions. Lab parts: B.
- **Choose the right compute** (databricks-compute): Notebook and serverless compute; SQL Warehouse and Unity Catalog. 2 scored questions. Lab parts: A, B.
- **Turn raw strings into typed data** (staging-transform): CAST and staging; Validate counts and failed conversions. 3 scored questions. Lab parts: C.

## Week 4 — Columnar storage & Parquet

25 slides; 7 lessons; 8 guided lab steps.

| Source slide | Original heading | Website lessons |
|---|---|---|
| 1 | WEEK 4  ·  SESSIONS 1 & 2 — Data Warehousing: Load & Parquet — Finishing the ETL Pipeline · A Real Star Schema · Columnar Storage & Parquet | Read only the columns you need |
| 2 | WEEK 4 — Today’s Plan — 90 Minutes, Two Sessions — SESSION 1 · THEORY/TUTORIAL | Read only the columns you need |
| 3 | SESSION 1 · RECAP — What You Built Last Week — Extract, done | Read only the columns you need |
| 4 | SESSION 1 · CONCEPTS — Row-Based vs. Columnar Storage — Same table, two different ways to physically arrange it on disk — and it changes everything about which queries are fast. | Read only the columns you need |
| 5 | SESSION 1 · CONCEPTS — Why Columnar Wins for Analytical Workloads — None of this makes columnar storage “better” in general — it makes it better at a specific job: scanning and aggregating many rows across few columns. | Read only the columns you need |
| 6 | SESSION 1 · CONCEPTS — Introducing the Apache Parquet File Format — Parquet is the file format that makes columnar storage a practical, portable reality — not just a theoretical idea. | Parquet underneath, Delta on top |
| 7 | SESSION 1 · CONCEPTS — Completing the Pattern: What Load Actually Does — Last week ended with six clean, correctly-typed staging tables — sitting unconnected. Load is what turns them into a real warehouse. | Design the star before loading |
| 8 | SESSION 1 · CONCEPTS — Why Not Just Copy the Tables? — Everything so far could, in principle, be run as one query straight against Supabase. There's one problem a live copy can never solve, no matter how it's hosted: it only ever remembers “now.” | Keep history when a customer changes |
| 9 | Slowly changing dimensions (SCD) — Type — When customer 1042 moves city | Keep history when a customer changes |
| 10 | Kimball's four steps: grain comes first — 1 — Pick the business process | Design the star before loading |
| 11 | SESSION 1 · CONCEPTS — Why Create Fact and Dimension Tables? — OPERATIONAL COPY | Design the star before loading |
| 12 | SESSION 1 · CONCEPTS — Fact Table = Analytics-Ready Rental Event — The operational rental table already has one row per rental. The fact table does not invent the event — it reshapes it for analysis. | Design the star before loading |
| 13 | SESSION 1 · CONCEPTS — Dimensions = Context, Consistency, and History — The fact stores keys and measures. Dimensions explain the keys: who, what, when, and sometimes what was true historically. | Design the star before loading |
| 14 | SESSION 1 · CONCEPTS — Advantages in dvdrental — What improves after warehousing? | Design the star before loading |
| 15 | MOVING TO SESSION 2 — Enough Theory. — Finish the Warehouse. | Design the star before loading |
| 16 | SESSION 2 · LAB 4A — Load, Step 1: Build the Dimension Tables — it8417-warehouse (SQL) | Load four dimensions and a fact |
| 17 | SESSION 2 · LAB 4A — Load, Step 2: Build the Fact Table — it8417-warehouse (SQL) | Load four dimensions and a fact |
| 18 | SESSION 2 · LAB 4B — Query the Warehouse: Real Business Questions — it8417-warehouse (SQL) | Ask business questions with SQL |
| 19 | SESSION 2 · LAB 4C — Export and Inspect Real Parquet Files — it8417-warehouse (SQL) | Parquet underneath, Delta on top |
| 20 | SESSION 2 · LAB 4D (OPTIONAL) — See a Slowly Changing Dimension Break — and Fix It — it8417-warehouse (SQL) | Keep history when a customer changes |
| 21 | SESSION 2 · LAB 4E (OPTIONAL) — Ask Your Warehouse Questions in Plain English — fact_rental and its dimensions now exist. Genie Agents let anyone — not just people who write SQL — ask that warehouse questions directly, in ordinary language. | Ask in plain English, inspect the SQL |
| 22 | SESSION 2 · LAB 4E (OPTIONAL) — Prompt-Based Querying: The Key Terms — Prompt | Ask in plain English, inspect the SQL |
| 23 | WRAP-UP — Today’s Lab Checklist — ✓ | Load four dimensions and a fact |
| 24 | WRAP-UP — Common Pitfalls & Troubleshooting — fact_rental has fewer rows than stg_rental | Load four dimensions and a fact |
| 25 | A Complete ETL Pipeline, Built by You — ✓  Extract, Transform, and Load — all three, hands-on — ✓  A real 4-dimension star schema, from real dvdrental data | Load four dimensions and a fact |

### Lab activity map

- A1 · Build dimensions: Copy the three clean entity dimensions and derive distinct rental dates with a surrogate date_id. Databricks SQL below uses YEAR and MONTH.
- A2 · Check join cardinality before the fact: Check duplicate payments and inventory keys before assuming one output per rental.
- A3 · Load and validate fact_rental: Use the source join path. If cardinality checks found multiple payments, replace p with a subquery grouped by rental_id. Validate rental IDs, missing lookups and NULL amounts.
- B · Answer all four business questions: Run revenue by film, revenue by staff, revenue by rental year/month, and most-rented films. Explain why the two film rankings can differ.
- C · Inspect Delta and the Parquet limitation: Inspect metadata. The original guide explicitly says plain Parquet creation and comparison do not run in its free setup because external storage is needed. Treat the following export as environment-dependent.
- D1 · Observe a Type 1 overwrite (optional): View customer 1’s rental history and surname. Change staging surname to Al-Rashid, rebuild dim_customer and query again.
- D2 · Build a Type 2 teaching dimension (optional): Use a fresh teaching table. This Delta-oriented version avoids the guide’s unbound email in VALUES. A real historical implementation needs a justified initial validity date and event-time fact-key resolution.
- E · Optional Genie inquiry: Create a Genie space/agent from the fact and four dimensions. Add business definitions, attach supported SQL Warehouse compute, ask a question and inspect its generated SQL. Specify a month in the actual dataset.

### Lesson and assessment map

- **Read only the columns you need** (columnar-storage): Row-oriented and column-oriented layout; Compression and vectorized processing. 2 scored questions. Lab parts: C.
- **Parquet underneath, Delta on top** (parquet-delta): Apache Parquet; Delta table. 2 scored questions. Lab parts: C.
- **Design the star before loading** (grain-star): Kimball’s four steps and grain; Facts, dimensions and purposeful denormalization. 3 scored questions. Lab parts: A.
- **Load four dimensions and a fact** (load-star): Derived date dimension and surrogate key; Load fact_rental and validate grain. 2 scored questions. Lab parts: A.
- **Ask business questions with SQL** (analytical-sql): GROUP BY, SUM and COUNT; Consistent staff and monthly reporting. 2 scored questions. Lab parts: B.
- **Keep history when a customer changes** (slowly-changing): SCD Type 1 and Type 3; SCD Type 2. 3 scored questions. Lab parts: D.
- **Ask in plain English, inspect the SQL** (genie): Genie and text-to-SQL; Grounding, hallucination, compound AI and RAG. 2 scored questions. Lab parts: E.

## Week 5 — MongoDB & document databases

29 slides; 8 lessons; 9 guided lab steps.

| Source slide | Original heading | Website lessons |
|---|---|---|
| 1 | WEEK 5  ·  LECTURE + LAB — Document Databases: MongoDB & Atlas — One Lecture, One Lab · From SQL to Documents, Aggregation, Replication & Sharding | Choose a data model |
| 2 | WEEK'S PLAN — Two Sessions, Four Hours Total — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Choose a data model |
| 3 | LECTURE · RECAP — Everything So Far Has Been Relational — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Choose a data model |
| 4 | LECTURE · WHY SOMETHING DIFFERENT — SQL vs NoSQL: The Trade-offs — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Choose a data model |
| 5 | LECTURE · THE LANDSCAPE — Five NoSQL Data Models, Briefly — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Choose a data model |
| 6 | LECTURE · THIS WEEK'S DATABASE — MongoDB in Three Pieces — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Think in documents |
| 7 | LECTURE · STORAGE FORMAT — JSON vs BSON — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Think in documents |
| 8 | LECTURE · CORE VOCABULARY — Documents & Collections — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Think in documents |
| 9 | LECTURE · SCHEMA DESIGN — Embedding vs. Referencing — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Embed or reference? |
| 10 | LECTURE · THIS WEEK'S PLATFORM — MongoDB Atlas: The Managed Service — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Keep Atlas available and recoverable |
| 11 | LECTURE · ARCHITECTURE — Two Ways In: Compass (GUI) and mongosh (JavaScript-based CLI) — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Think in documents |
| 12 | LECTURE · REFERENCE — CRUD & Query Operators, At a Glance — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Create, read, update, delete; Filter nested data precisely |
| 13 | LECTURE · SEARCH — Indexes, Including Text Indexes — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Find faster, search text |
| 14 | LECTURE · ANALYTICS INSIDE MONGODB — The Aggregation Pipeline — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Assemble an aggregation pipeline |
| 15 | LECTURE · HIGH AVAILABILITY — Replication: Staying Up When a Server Fails — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Keep Atlas available and recoverable |
| 16 | LECTURE · HIGH PERFORMANCE — Sharding: Scaling Past One Server's Limits — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Keep Atlas available and recoverable |
| 17 | LECTURE · DATA SAFETY — Backup, Restore, and Export/Import — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Keep Atlas available and recoverable |
| 18 | LECTURE · SUMMARY — What's Waiting in the Lab — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Choose a data model |
| 19 | MOVING TO THE LAB — Enough Theory. Build a Cluster. | Choose a data model |
| 20 | LAB PART A — Sign Up and Create a Free Cluster — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Keep Atlas available and recoverable |
| 21 | LAB PART B — Connect, Then CRUD Basics — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Create, read, update, delete |
| 22 | LAB PART C — Embedded Documents & Arrays — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Embed or reference?; Filter nested data precisely |
| 23 | LAB PART D — Text Indexes & Full-Text Search — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Find faster, search text |
| 24 | LAB PART E — Aggregation Pipeline Basics — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Assemble an aggregation pipeline |
| 25 | LAB PART F — Materialized Views ($out, $merge) and Joins ($lookup) — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Assemble an aggregation pipeline |
| 26 | LAB PART G — Replication, Backup & Restore — For Real — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Keep Atlas available and recoverable |
| 27 | WRAP-UP — Today's Lab Checklist — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Keep Atlas available and recoverable |
| 28 | WRAP-UP — Common Pitfalls & Troubleshooting — IT8417  ·  Week 5  ·  Document Databases: MongoDB & Atlas | Keep Atlas available and recoverable |
| 29 | LOOKING AHEAD — Your First Step Outside the Relational World — Next week: key-value database Redis for improved database performace | Choose a data model |

### Lab activity map

- A · Create and secure a cluster: Create the course Atlas project it8417-mongo and intended free cluster option. Choose a nearby region, create a database user and add only the necessary current IP through Network Access.
- B1 · Connect two clients: Install Compass and mongosh. Copy each connection from Atlas’s Connect dialog, substitute values privately, then connect. The password-prompt form avoids embedding a password in the command shown here.
- B2 · CRUD and write scope: Create a small teaching customers collection. Practice insertOne/insertMany, updateOne/updateMany, $set/$inc/$mul/$rename, replaceOne, upsert, bulkWrite and deleteOne/deleteMany. Preview filters first.
- C · Nested objects, arrays and precise filters: Add Hassan’s embedded address and accounts. Update a dot path. Use $elemMatch, projection, sort/limit/skip, $eq/$gt/$gte/$in/$nin/$ne, $and/$or/$not, $all/$size, $expr and regex.
- D · Text index before text search: Create a tiny teaching articles dataset, then build the text index and query with textScore. The simulator demonstrates basic token matching, not MongoDB’s real ranking implementation.
- E · Group and unwind: Practice purchase-order totals and account balances by currency. Also use distinct() and countDocuments() when a full pipeline is unnecessary.
- F · Materialize and join: Practice terminal $out and $merge. Run a left lookup, an inner pattern filtering non-empty arrays, and reverse the starting collection for a right-preserving pattern. getSiblingDB chooses a database handle; it is not an automatic cross-database join.
- G1 · Observe replication, study sharding: Run the allowed replica status command or inspect Atlas monitoring. The course expects a primary and two secondaries. Study mongos/config servers/shards without claiming to deploy a free sharded cluster.
- G2 · Back up and restore in the OS terminal: Install Database Tools. Back up the collection, verify the BSON file and restore deliberately. Cloud-managed snapshots are a separate plan-dependent feature.

### Lesson and assessment map

- **Choose a data model** (nosql-models): SQL and NoSQL; ACID transactions; Model families. 2 scored questions. Lab parts: A.
- **Think in documents** (documents-bson): Document, collection and BSON; Compass, mongosh and MQL. 3 scored questions. Lab parts: B, C.
- **Embed or reference?** (embed-reference): Embedding and dot notation; References and bounded arrays. 2 scored questions. Lab parts: C.
- **Create, read, update, delete** (mongo-crud): CRUD and one vs many; Update operators, replacement and upsert. 2 scored questions. Lab parts: B.
- **Filter nested data precisely** (mongo-queries): Filters, projection and paging; $all, $size and $elemMatch. 2 scored questions. Lab parts: C.
- **Find faster, search text** (indexes-search): Index and text index; Index trade-offs and search vocabulary. 2 scored questions. Lab parts: D.
- **Assemble an aggregation pipeline** (aggregation): Aggregation stages; $lookup and join patterns; $out, $merge and materialized views. 3 scored questions. Lab parts: E, F.
- **Keep Atlas available and recoverable** (atlas-operations): Atlas setup and replication; Sharding vs replication; Backup, restore, export and import. 3 scored questions. Lab parts: A, G.

## Week 6 — Redis & key-value databases

45 slides; 10 lessons; 10 guided lab steps.

| Source slide | Original heading | Website lessons |
|---|---|---|
| 1 | WEEK 6  ·  LECTURE + LAB — Key-Value Databases: Redis & Redis Cloud — Speed, caching, data structures, expiration, sessions, persistence — then a hands-on lab on a free Redis Cloud database | Understand the cost of a lookup |
| 2 | TODAY'S PLAN — Two Sessions, Just Over Four Hours — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Understand the cost of a lookup |
| 3 | LECTURE 1 · PERFORMANCE — Why Data-Access Performance Matters — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Understand the cost of a lookup |
| 4 | LECTURE 1 · PERFORMANCE — How Long Does One Access Take? — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Understand the cost of a lookup |
| 5 | LECTURE 1 · PERFORMANCE — Three Observations — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Understand the cost of a lookup |
| 6 |  | Understand the cost of a lookup |
| 7 | LECTURE 2 · CACHING — Caching Happens at Two Levels — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Build a cache-aside flow |
| 8 | LECTURE 2 · ENGINE CACHES — Caching in Conventional DBMSs (Overview Only) — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Build a cache-aside flow |
| 9 | LECTURE 2 · WHY ADD ANOTHER CACHE? — Conventional Engine Caches Have Limits — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Build a cache-aside flow |
| 10 | LECTURE 2 · PATTERN — The solution: Application-Level Caching or Cache-Aside — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Build a cache-aside flow |
| 11 | LECTURE 2 · PATTERN — Welcome to REDIS, the key-value database:  — The Hit Ratio Is Everything | Build a cache-aside flow |
| 12 | LECTURE 3 · REDIS — Why Redis Is Faster for Certain Workloads — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Why Redis can be fast |
| 13 | LECTURE 3 · REDIS — Three Simple Examples — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Why Redis can be fast |
| 14 | LECTURE 3 · REDIS — Fast Does Not Mean Better at Everything — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Why Redis can be fast |
| 15 | LECTURE 4 · EXPIRATION — A Database That Forgets On Purpose — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | A database that forgets on purpose |
| 16 | LECTURE 4 · RATE LIMITING — Example: Expiry Plus an Atomic Counter — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | A database that forgets on purpose |
| 17 | LECTURE 4 · SESSIONS — Another Example: Where to Keep a Web Session — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Share sessions across app servers |
| 18 | LECTURE 4 · SESSIONS — The Session Flow — and Why Redis Is Everywhere — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Share sessions across app servers |
| 19 | LECTURE 5  ·  DATA STRUCTURES — Redis Data Types: What They Store — Choose a type based on the way your application needs to organize data. | Pick the right data structure |
| 20 | LECTURE 5  ·  DATA STRUCTURES — How Redis Implements Its Data Types — Redis chooses an internal structure to balance memory efficiency and fast operations. | Why Redis can be fast; Pick the right data structure |
| 21 | LECTURE 6 · JSON — JSON as a Value in Redis — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Edit and search JSON by path |
| 22 | LECTURE 7 · TEMPORARY DATA — Where Redis Fits Well: Typical Use Cases, Redis Data Types, and Expiration Strategies — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Build a cache-aside flow; A database that forgets on purpose |
| 23 | Search Complexity in Redis: O(1), O(log n), O(n) — Redis demonstrates how choosing the right data structure affects search performance: — O(1) — Hash Tables: Redis uses hashing for fast key lookups (GET, HGET). Average lookup time remains nearly constant as data grows. | Why Redis can be fast |
| 24 |  | Why Redis can be fast |
| 25 | LECTURE 8 · PERSISTENCE — Memory First, Disk for Recovery — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Why Redis can be fast; Decide what can survive a restart |
| 26 | LECTURE 8 · PERSISTENCE — Three Approaches — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Decide what can survive a restart |
| 27 | LECTURE 8 · PERSISTENCE — Comparing the Approaches — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Decide what can survive a restart |
| 28 | LECTURE 9 · PRACTICAL ASPECTS — Cloud Redis: Redis Cloud vs. Upstash — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Connect to Redis Cloud three ways |
| 29 | LECTURE 9 · PRACTICAL ASPECTS — The Redis Cloud Free Tier, Briefly — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Connect to Redis Cloud three ways |
| 30 | LECTURE 9 · PRACTICAL ASPECTS — Local Redis with Docker (Overview Only) — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Connect to Redis Cloud three ways |
| 31 | LECTURE 9 · PRACTICAL ASPECTS — Client Tools: redis-cli and Redis Insight — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Connect to Redis Cloud three ways |
| 32 | LECTURE 9 · PRACTICAL ASPECTS — The Classic First Rally: PING → PONG — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Keys, values and atomic counters; Connect to Redis Cloud three ways |
| 33 | LECTURE 10 · SUMMARY — What's Waiting in the Lab — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Connect to Redis Cloud three ways |
| 34 | MOVING TO THE LAB — Enough Theory. Create a Database. | Connect to Redis Cloud three ways |
| 35 | LAB PART A — Sign Up and Create a Free Redis Database — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Connect to Redis Cloud three ways |
| 36 | LAB PART B — Connect, Then Say PING — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Connect to Redis Cloud three ways |
| 37 | LAB PART C — Key-Value Basics — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Keys, values and atomic counters |
| 38 | LAB PART D — Data Types — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Pick the right data structure |
| 39 | LAB PART E — Expiration and Temporary Data — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | A database that forgets on purpose |
| 40 | LAB PART F — JSON Values — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Edit and search JSON by path |
| 41 | LAB PART G — Persistence Check and Reflection — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Decide what can survive a restart |
| 42 | JavaScript + ioredis — Minimal example (Node.js) — const Redis = require('ioredis'); | Connect to Redis Cloud three ways |
| 43 | WRAP-UP — Today's Lab Checklist — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Connect to Redis Cloud three ways |
| 44 | WRAP-UP — Common Pitfalls & Troubleshooting — IT8417  ·  Week 6  ·  Key-Value Databases: Redis & Redis Cloud | Connect to Redis Cloud three ways |
| 45 | LOOKING AHEAD — Midterm Exam in 2 Weeks. Good Luck  — Next: Getting closer to AI: Vector Databases | Connect to Redis Cloud three ways |

### Lab activity map

- A · Create the database: Use the course signup path, name it it8417-redis, select a version/features supporting JSON and Query Engine, choose the nearest region and wait for ready status. Locate host, database-specific port, default username and password.
- B1 · CLI and Insight: Install redis-cli with the course’s OS-specific instructions: brew install redis (macOS), apt install redis-tools (Ubuntu/WSL), or use a lab machine. Connect using actual host/port and password prompt; add the same database in Insight.
- B2 · Connect from Node.js: Install ioredis in your separate lab project and run a client using environment variables. The code below is a runnable async wrapper; add provider-required TLS settings.
- C · Basic keys, NX, counters and scanning: Predict each reply, then execute. Compare KEYS to incremental SCAN on this tiny dataset; use SCAN for scale. Measure real network latency separately with redis-cli --latency and stop it with Ctrl-C.
- D1 · All five core types: Create a string, hash, list, set and sorted set. Check each TYPE and inspect them in Insight.
- D2 · Encodings and optional extras: Try OBJECT ENCODING when permitted. Review bitmap, HyperLogLog, geospatial and stream examples in the lesson; their low-level implementation is overview material.
- E1 · Watch expiry and SET behavior: Set a 10-second value, inspect TTL, wait and read again. Repeat with PTTL, PERSIST and SET KEEPTTL. Then demonstrate that plain SET clears expiry.
- E2 · Six temporary-data uses: Exercise an OTP, single-use reset token, sliding session, cached API response, cart and lock. Use teaching values only.
- F · JSON and indexed search (optional): Compare plain-string JSON with native JSON commands. Create an index before search. Search for the current city after editing it.
- G · Inspect persistence and justify choices: Inspect permitted metadata, then write one sentence each for pure API cache, sessions and a valued leaderboard. State acceptable data loss; there is no universal one-word answer.

### Lesson and assessment map

- **Understand the cost of a lookup** (performance): Latency and throughput; Cache locality and hierarchy. 2 scored questions. Lab parts: A, C.
- **Build a cache-aside flow** (cache-aside): Engine caches vs external caches; Cache-aside and hit ratio. 2 scored questions. Lab parts: C, E.
- **Why Redis can be fast** (redis-architecture): RAM, RESP and atomic commands; Big O and internal structures; Cache role and primary-store role. 2 scored questions. Lab parts: D, G.
- **Keys, values and atomic counters** (redis-strings): Strings and key naming; KEYS vs SCAN. 2 scored questions. Lab parts: B, C.
- **Pick the right data structure** (redis-structures): Hash, list and set; Sorted set and specialized structures. 2 scored questions. Lab parts: D.
- **A database that forgets on purpose** (ttl-temporary): EX, TTL, PTTL, PERSIST and KEEPTTL; Tokens, carts, locks and rate limiting. 3 scored questions. Lab parts: E.
- **Share sessions across app servers** (sessions): Session and stateless application servers; Session alternatives and cookies. 2 scored questions. Lab parts: E.
- **Edit and search JSON by path** (redis-json): JSON string vs native Redis JSON; Search index and MongoDB comparison. 2 scored questions. Lab parts: F.
- **Decide what can survive a restart** (persistence): None, RDB and AOF; Durability, availability and backups. 3 scored questions. Lab parts: G.
- **Connect to Redis Cloud three ways** (redis-cloud): Redis Cloud, Upstash and connection tools; Application code and local Docker. 2 scored questions. Lab parts: A, B, G.

## Source corrections and missing companion assets

- Week 1 mixes transaction-pooler 6543 and port 5432. Copy the complete selected mode, explained in connection-security.
- Week 2 dvdrental.tar, its SQL scripts and optional RLS guide were not uploaded. Object counts are attributed to the lab author, not independently verified.
- Week 3 has outdated references to three tables; all six tables are mapped. CSV inference may assign types; CAST alone does not silently drop rows. COPY server-file privileges differ from COPY TO STDOUT.
- Week 4 grain preservation depends on lookup uniqueness/payment cardinality. Free-plan plain Parquet restriction is retained. SCD teaching SQL fixes unbound email, explains Delta constraints and requires historical baseline plus fact version resolution.
- Week 5 analytical columnar differs from wide-column/column-family storage. Right-preserving lookup must start on the intended preserved side. Embedded credential-looking URIs are masked in the readable source text; original files remain unchanged for local download. Referenced JS scripts are absent.
- Week 6 uses Redis Cloud, although Week 1 previews Upstash. Price/limit/version claims are source context, not current guarantees. Atomic command vs multi-command sequences, expiry vs cleanup, primary-store vs cache roles and client code runtime are distinguished. Referenced shell/JS scripts are absent.

## Verification scope

Every source slide is mapped above. Original lab guide paragraphs and extracted course images remain accessible in the Sources view, alongside the unchanged original Office files. Browser practice is labeled and runs without cloud credentials. Simulators document unsupported commands.
